# -*- coding: utf-8 -*-
"""Цифровая модель рельефа (ЦМР) по отметкам топоплана, профилям А-А, Б-Б и урезу."""
import json, os
import numpy as np
from scipy.interpolate import LinearNDInterpolator, NearestNDInterpolator
from scipy.ndimage import gaussian_filter
from data import (SPOTS_PLATEAU, SPOTS_SLOPE, PROFILE_AA, PROFILE_BB, LINE_AA, LINE_BB, line_xy,
                  WL_LOW, RIVER_BED)

HERE = os.path.dirname(os.path.abspath(__file__))
RIVER_EDGES = json.load(open(os.path.join(HERE, '..', 'river_edges.json')))   # (y, x_west, x_east)

# сетка ЦМР
GX = np.arange(10.0, 112.01, 0.5)
GY = np.arange(-14.0, 112.01, 0.5)


def water_edge_x(y):
    """x уреза (западная граница реки) по топоплану, линейная экстраполяция за пределы съёмки"""
    e = np.array(RIVER_EDGES)
    e = e[np.argsort(e[:, 0])]
    e = e[(e[:, 2] - e[:, 1]) > 3.0]
    ys, xw = e[:, 0], e[:, 1]
    y = np.atleast_1d(y)
    out = np.interp(y, ys, xw)
    lo = y < ys[0]; hi = y > ys[-1]
    if lo.any():
        k = (xw[5] - xw[0]) / (ys[5] - ys[0]); out[lo] = xw[0] + k * (y[lo] - ys[0])
    if hi.any():
        k = (xw[-1] - xw[-6]) / (ys[-1] - ys[-6]); out[hi] = xw[-1] + k * (y[hi] - ys[-1])
    return out


def points():
    pts = list(SPOTS_PLATEAU) + list(SPOTS_SLOPE)
    for line, prof in ((LINE_AA, PROFILE_AA), (LINE_BB, PROFILE_BB)):
        for pk, z in prof:
            x, y = line_xy(line, pk)
            pts.append((x, y, z))
    # урез, дно, противоположный берег, пойма
    for y in np.arange(-14, 113, 2.0):
        xw = float(water_edge_x(y)[0])
        pts += [(xw - 0.4, y, 100.15), (xw + 1.2, y, WL_LOW - 0.05), (xw + 3.6, y, RIVER_BED),
                (xw + 8.5, y, RIVER_BED), (xw + 10.5, y, WL_LOW), (xw + 14.0, y, 100.9), (xw + 24.0, y, 101.3)]
    return np.array(pts)


def build(save=True):
    P = points()
    lin = LinearNDInterpolator(P[:, :2], P[:, 2])
    nn = NearestNDInterpolator(P[:, :2], P[:, 2])
    X, Y = np.meshgrid(GX, GY)
    Z = lin(X, Y)
    m = np.isnan(Z)
    Z[m] = nn(X[m], Y[m])
    Z = gaussian_filter(Z, 0.6)
    if save:
        np.savez(os.path.join(HERE, 'dem_exist.npz'), X=X, Y=Y, Z=Z)
    return X, Y, Z


def sample(Z, x, y):
    from scipy.interpolate import RegularGridInterpolator
    f = RegularGridInterpolator((GY, GX), Z, bounds_error=False, fill_value=None)
    return f(np.c_[np.atleast_1d(y), np.atleast_1d(x)])


def profile(Z, line, L, step=0.5):
    pk = np.arange(0, L + 1e-9, step)
    x, y = line_xy(line, pk)
    return pk, sample(Z, x, y)


if __name__ == '__main__':
    X, Y, Z = build()
    from data import LINE_VV, LINE_GG
    for nm, ln in (('А-А', LINE_AA), ('Б-Б', LINE_BB), ('В-В', LINE_VV), ('Г-Г', LINE_GG)):
        pk, z = profile(Z, ln, 56)
        print(nm, ' '.join(f'{p:.0f}:{v:.2f}' for p, v in zip(pk[::4], z[::4])))
    # контроль: сравнение ЦМР с профилями
    for line, prof, nm in ((LINE_AA, PROFILE_AA, 'А-А'), (LINE_BB, PROFILE_BB, 'Б-Б')):
        d = [float(sample(Z, *line_xy(line, pk))[0] - z) for pk, z in prof]
        print('контроль', nm, 'макс. отклонение %.2f м' % max(map(abs, d)))
