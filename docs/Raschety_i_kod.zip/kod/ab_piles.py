# -*- coding: utf-8 -*-
"""Эффект винтовых свай Ø108 L=6 м (предложение АВ) на устойчивость: расчёт на критической поверхности сущ. положения."""
import json, numpy as np, sys
import sections as S
R = json.load(open('results/results.json', encoding='utf-8'))
out = {}
for key, fn, xe in [('А-А', S.sec_AA_exist, 31.9), ('Б-Б', S.sec_BB_exist, 32.7), ('В-В', S.sec_VV_exist, 27.0)]:
    e = R['exist'][key]['base']; xc, zc, Rr = e['xc'], e['zc'], e['R']
    sec = fn(); G = np.asarray(sec.surface, float); zg = float(np.interp(xe, G[:, 0], G[:, 1]))
    base = sec.bishop_circle(xc, zc, Rr)['F']
    zslip = float(np.interp(xe, e['xs'], e['zs']))
    res = dict(F0=round(base, 3), z_ground=round(zg, 2), z_slip_at_edge=round(zslip, 2), depth=round(zg - zslip, 1))
    for nm, L, H in [('АВ: L=6 м, 20 шт на 40 м', 6.0, 7.5), ('если бы L=12 м', 12.0, 7.5), ('если бы 20 шт на 1 м (!)', 12.0, 300.0)]:
        s2 = fn(); s2.piles = [dict(x=xe, ztop=zg, ztip=zg - L, H=H)]
        res[nm] = round(s2.bishop_circle(xc, zc, Rr)['F'], 3)
    lo, hi = 0.0, 3000.0
    for _ in range(40):
        mid = (lo + hi) / 2; s2 = fn(); s2.piles = [dict(x=xe, ztop=zg, ztip=zg - 15, H=mid)]
        if s2.bishop_circle(xc, zc, Rr)['F'] < 1.15: lo = mid
        else: hi = mid
    res['H_needed_kN_per_m'] = round(hi)
    out[key] = res
    print(key, res)
json.dump(out, open('results/ab_piles.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
