# -*- coding: utf-8 -*-
"""Комплект чертежей (PDF, листы А2) и DXF. Шифр 2026-МОС40-ИЗ."""
import json, math, os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Polygon as Poly, Rectangle, Circle, FancyArrowPatch
from PIL import Image

import data
from data import (WL_LOW, WL_FLOOD, WL_ICE, RIVER_BED, BUILDINGS, WALLS_EXIST, DECK, BOREHOLES, SOILS, line_xy,
                  LINE_AA, LINE_BB, LINE_VV, LINE_GG, DRAIN_AXIS)
from design import DESIGN, JET, jet_dc, KST, KST_SP
import model3d as M

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'results')
R = json.load(open(os.path.join(OUT, 'results.json'), encoding='utf-8'))
for f in ('GOST Common.ttf', 'GOST Common Italic.ttf'):
    p = os.path.join('C:/Windows/Fonts', f)
    if os.path.exists(p):
        font_manager.fontManager.addfont(p)
plt.rcParams.update({'font.family': 'GOST Common', 'font.size': 9, 'axes.linewidth': 0.6, 'hatch.linewidth': 0.5})
# в шрифте GOST Common вместо «Ø» стоит другой знак — диаметр выводим из математического шрифта
import matplotlib.text as _mtext
_set_text0 = _mtext.Text.set_text
def _set_text(self, s):
    if isinstance(s, str) and 'Ø' in s:
        s = s.replace('Ø', r'$\O$')
    return _set_text0(self, s)
_mtext.Text.set_text = _set_text
CODE = '2026-МОС40-ИЗ'
OBJ = 'Инженерная защита склона и берегоукрепление р. Ушайки у участка по ул. Мостовая, 40, п. Заварзино, г. Томск'
MM = 1 / 25.4
W2, H2 = 594, 420
LINES = {'А-А': LINE_AA, 'Б-Б': LINE_BB, 'В-В': LINE_VV, 'Г-Г': LINE_GG}
SHEETS = []

# ---------------------------------------------------------------- рамка и штамп
def sheet(title, num, total_ref):
    fig = plt.figure(figsize=(W2 * MM, H2 * MM))
    base = fig.add_axes([0, 0, 1, 1]); base.set_xlim(0, W2); base.set_ylim(0, H2); base.axis('off')
    base.add_patch(Rectangle((20, 5), W2 - 25, H2 - 10, fill=False, lw=1.2))
    # штамп формы 3 (185×55)
    x0, y0 = W2 - 5 - 185, 5
    base.add_patch(Rectangle((x0, y0), 185, 55, fill=False, lw=1.0))
    for xx in (7, 17, 40, 55, 65):
        base.plot([x0 + xx, x0 + xx], [y0, y0 + 55], 'k-', lw=0.5 if xx < 65 else 1.0)
    for yy in range(5, 55, 5):
        base.plot([x0, x0 + 65], [y0 + yy, y0 + yy], 'k-', lw=0.35)
    base.plot([x0 + 65, x0 + 185], [y0 + 40, y0 + 40], 'k-', lw=1.0)
    base.plot([x0 + 65, x0 + 185], [y0 + 15, y0 + 15], 'k-', lw=1.0)
    base.plot([x0 + 135, x0 + 135], [y0, y0 + 40], 'k-', lw=1.0)
    base.plot([x0 + 135, x0 + 185], [y0 + 35, y0 + 35], 'k-', lw=0.5)
    base.plot([x0 + 135, x0 + 185], [y0 + 30, y0 + 30], 'k-', lw=0.5)
    for xx in (150, 165):
        base.plot([x0 + xx, x0 + xx], [y0 + 30, y0 + 40], 'k-', lw=0.5)
    t = lambda x, y, s, **k: base.text(x, y, s, va='center', **k)
    for i, s in enumerate(['Изм.', 'Кол.уч', 'Лист', '№ док.', 'Подп.', 'Дата']):
        t(x0 + [1, 8, 18, 41, 56, 59][i], y0 + 27.5, s, fontsize=6)
    for i, s in enumerate(['Разраб.', 'Пров.', 'ГИП', 'Н. контр.', 'Утв.']):
        t(x0 + 1, y0 + 22.5 - 5 * i, s, fontsize=6.5, style='italic')
    t(x0 + 18, y0 + 22.5, '', fontsize=6)
    t(x0 + 160, y0 + 47.5, CODE, fontsize=14, ha='center')
    import textwrap
    base.text(x0 + 100, y0 + 27.5, chr(10).join(textwrap.wrap(OBJ, 52)), fontsize=6.6, ha='center', va='center', linespacing=1.15)
    base.text(x0 + 100, y0 + 7.5, chr(10).join(textwrap.wrap(title, 40)), fontsize=8, ha='center', va='center', linespacing=1.15)
    t(x0 + 142.5, y0 + 37.5, 'Стадия', fontsize=6.5, ha='center'); t(x0 + 157.5, y0 + 37.5, 'Лист', fontsize=6.5, ha='center')
    t(x0 + 175, y0 + 37.5, 'Листов', fontsize=6.5, ha='center')
    t(x0 + 142.5, y0 + 32.5, 'Конц.', fontsize=6.5, ha='center'); t(x0 + 157.5, y0 + 32.5, str(num), fontsize=9, ha='center')
    total_ref.append(base.text(x0 + 175, y0 + 32.5, '', fontsize=9, ha='center', va='center'))
    base.text(x0 + 160, y0 + 21, 'Проектная организация —\nчлен СРО (заполняется\nпри выпуске)', fontsize=6.5,
              ha='center', va='center')
    base.text(20, H2 - 3, 'Черновик проектных решений. Подлежит проверке и подписанию ГИП организации — члена СРО.',
              fontsize=6.5, va='center', color='#555')
    base.text(W2 / 2, H2 / 2, 'ЧЕРНОВИК', fontsize=120, color='#c0392b', alpha=0.07, ha='center', va='center', rotation=28, zorder=0)
    return fig, base


def ax_mm(fig, x, y, w, h):
    a = fig.add_axes([x / W2, y / H2, w / W2, h / H2]); return a


# ---------------------------------------------------------------- подложка топоплана
TOPO = np.array(Image.open(os.path.join(HERE, '..', '..', 'src', 'img', 'igi_70.png')).convert('L')).astype(float)
TOPO = 255 - (255 - TOPO) * 0.45                      # осветление
TOPO_EXT = [25 - 452 / 22.68, 25 + (2382 - 452) / 22.68, 100 - (3368 - 377) / 22.68, 100 + 377 / 22.68]


def topo(ax, alpha=1.0):
    ax.imshow(TOPO, cmap='gray', vmin=0, vmax=255, extent=TOPO_EXT, origin='upper', alpha=alpha, zorder=0,
              interpolation='bilinear')


def axis_points(n_off, s_vals):
    cum = np.r_[0, np.cumsum(np.hypot(*np.diff(M.AXIS, axis=0).T))]
    out = []
    for s in s_vals:
        i = int(np.searchsorted(cum, s)) - 1; i = max(0, min(i, len(M.AXIS) - 2))
        t = (s - cum[i]) / (cum[i + 1] - cum[i]); P = M.AXIS[i] + t * (M.AXIS[i + 1] - M.AXIS[i])
        v = M.AXIS[i + 1] - M.AXIS[i]; v = v / np.hypot(*v); nrm = np.array([v[1], -v[0]])
        out.append(P + nrm * n_off)
    return np.array(out)


S_ALL = np.linspace(0, M.AXIS_LEN, 120)
cum_axis = np.r_[0, np.cumsum(np.hypot(*np.diff(M.AXIS, axis=0).T))]


def plan_frame(ax, xl=(30, 104), yl=(-10, 112), grid=True):
    ax.set_xlim(*xl); ax.set_ylim(*yl); ax.set_aspect('equal'); ax.set_xticks([]); ax.set_yticks([])
    if grid:
        for X in range(348300, 348425, 25):
            for Y in range(4334125, 4334225, 25):
                x, y = Y - data.Y0, X - data.X0
                if xl[0] < x < xl[1] and yl[0] < y < yl[1]:
                    ax.plot([x - 1.5, x + 1.5], [y, y], color='#1b7a1b', lw=0.6, zorder=8)
                    ax.plot([x, x], [y - 1.5, y + 1.5], color='#1b7a1b', lw=0.6, zorder=8)
                    ax.text(x + 0.6, y + 0.6, f'X {X}\nY {Y}', fontsize=4.5, color='#1b7a1b', zorder=8)


def north(ax, x, y):
    ax.annotate('', xy=(x, y + 6), xytext=(x, y), arrowprops=dict(arrowstyle='-|>', color='k', lw=1.0), zorder=9)
    ax.text(x, y + 7, 'С', ha='center', fontsize=9, zorder=9)


# ---------------------------------------------------------------- лист 1: общие данные
def sheet_general(pages):
    fig, b = sheet('Общие данные', 1, pages)
    b.text(30, 400, 'ОБЩИЕ ДАННЫЕ', fontsize=16)
    rows = [(1, 'Общие данные'), (2, 'План существующего положения М 1:400'), (3, 'План проектных решений М 1:400'),
            (4, 'Разрез А-А. Существующее положение и проект М 1:200'), (5, 'Разрез Б-Б М 1:200'),
            (6, 'Разрез В-В М 1:200'), (7, 'Разрез Г-Г М 1:200'),
            (8, 'Грунтоцементные контрфорсы. План, разрез, узлы'), (9, 'Габионная стена и крепление подошвы. Узлы'),
            (10, 'Дренаж и водоотвод. Профиль Д-1, узлы'), (11, 'Организация строительства. Стройгенплан, этапы'),
            (12, 'Мониторинг. Схема и критерии'), (13, '3D-модель. Виды')]
    y = 385
    b.text(30, y, 'Ведомость листов основного комплекта', fontsize=10); y -= 6
    b.add_patch(Rectangle((30, y - 6 * len(rows) - 2), 170, 6 * len(rows) + 6, fill=False, lw=0.6))
    b.text(32, y - 1, 'Лист', fontsize=7.5); b.text(50, y - 1, 'Наименование', fontsize=7.5)
    for n, s in rows:
        y -= 6; b.text(34, y - 1, str(n), fontsize=8); b.text(50, y - 1, s, fontsize=8)
    # основные показатели
    T = R['quant']['total']
    ind = [('Протяжённость защищаемого участка (по оси бермы)', f"{T['bench']:.0f} м"),
           ('Грунтоцементные контрфорсы (рёбра), шаг 2,5 м', f"{T['ribs']:.0f} шт."),
           ('Колонны струйной цементации Ø1,0 м', f"{T['cols']:.0f} шт. / {T['col_m']:.0f} п. м"),
           ('Объём грунтоцемента / цемент (оценка)', f"{T['soilcrete_m3']:.0f} м³ / {T['cement_t']:.0f} т"),
           ('Армирование трубами 146×8', f"{T['pipe_m']:.0f} м / {T['pipe_t']:.1f} т"),
           ('Габионы коробчатые', f"{T['gabion']:.0f} м³"),
           ('Матрацы Рено 0,3 м (вкл. фартук)', f"{T['reno']:.0f} м²"),
           ('Откосы срезки с объёмной георешёткой', f"{T['upper']:.0f} м²"),
           ('Срезка грунта / подсыпка', f"{T['cut']:.0f} / {T['fill']:.0f} м³"),
           ('Перехватывающий дренаж Д-1 Ø160', '≈102 м, 5 колодцев'),
           ('Горизонтальные дренажные скважины', f"{2 * int(T['ribs'])} шт. × 15–16 м"),
           ('Инклинометры / пьезометры / марки', '5 / 4 / 26')]
    y = 290
    b.text(30, y + 6, 'Основные показатели', fontsize=10)
    for k, v in ind:
        b.text(32, y, k, fontsize=8); b.text(160, y, v, fontsize=8); b.plot([30, 205], [y - 2.2, y - 2.2], 'k-', lw=0.3); y -= 6
    # коэффициенты устойчивости
    y = 205
    b.text(30, y + 6, 'Коэффициенты устойчивости (Бишоп / Спенсер), [k] = 1,15 осн., 1,09 особ.', fontsize=10)
    hdr = ['Сечение', 'Сущ. норм.', 'Сущ. расч.', 'Верховодка', 'Сейсм.', 'Проект осн.', 'Проект сейсм.', 'Сработка']
    xs = [32, 52, 72, 92, 112, 132, 152, 174]
    for x, h in zip(xs, hdr):
        b.text(x, y, h, fontsize=7)
    for key in ['А-А', 'Б-Б', 'В-В', 'Г-Г']:
        y -= 6
        e = R['exist'][key]; d = R['design'][key]
        vals = [key, e['norm']['F'], e['base']['F'], e['perched']['F'], e['seis']['F'], d['base']['F'], d['seis']['F'], d['rdd']['F']]
        for x, v in zip(xs, vals):
            b.text(x, y, v if isinstance(v, str) else f'{v:.2f}', fontsize=8,
                   color=('#b00' if (not isinstance(v, str) and v < 1.09) else 'k'))
    # общие указания
    notes = [
        'ОБЩИЕ УКАЗАНИЯ',
        '1. Проект разработан на основании: технического отчёта ИГИ 188-07/2024/ИГИ с доп. от 02.07.2025 (ООО «Сибирская Буровая Компания»),',
        '   заключения ООО «НПФ «Инженерные изыскания» (2025) об устойчивости склона, топоплана М 1:400 (лист Г.1 отчёта ИГИ).',
        '2. Система координат МСК-70, высот — Балтийская 1977 г. Локальная СК проекта: x = Y − 4 334 100, y = X − 348 300.',
        '3. Нормативная база: СП 116.13330.2012, СП 22.13330.2016, СП 24.13330.2021, СП 291.1325800.2017, СП 45.13330.2017,',
        '   СП 58.13330.2019, СП 38.13330.2018, СП 14.13330.2018, СП 381.1325800.2018, СП 32.13330.2018, СП 28.13330.2017,',
        '   ГОСТ 27751-2014, ГОСТ 31937-2024, Водный кодекс РФ (ст. 6, 11, 65), ФЗ-166 (ст. 50).',
        '4. Уровень ответственности — нормальный (КС-2), γn = 1,15. [k] = γn·ψ/γd: 1,15 (основное), 1,09 (особое, строит. период).',
        '5. Расчётная сейсмичность 7 баллов (6 баллов по карте ОСР-2015 А + 1 балл за III категорию грунтов), k_h = 0,05.',
        '6. Расчётные характеристики грунтов приняты по частным значениям прил. Е отчёта ИГИ (α = 0,95); значения прил. Ж',
        '   для ИГЭ-304 (φ = 21–24°, c = 23–34 кПа) противоречат испытаниям и не использованы.',
        '7. УСЛОВНО ПРИНЯТО до доизысканий: РУВВ 1 % = 103,00; уровень ледохода 101,50; дно у берега 99,00; толщина льда 0,8 м;',
        '   скорость 2,5 м/с; ниже отм. 94,5 (забой скважин) — ИГЭ-305. До выпуска РД обязательны доизыскания (см. ПЗ, разд. 13).',
        '8. Склон расположен вне границ ЗУ :104, :87, :72 (неразграниченные земли), в береговой полосе (20 м), прибрежной',
        '   защитной полосе (50 м) и водоохранной зоне (200 м) р. Ушайки. До начала работ — права на землю, решение о',
        '   предоставлении водного объекта в пользование, согласование Росрыболовства (ст. 50 ФЗ-166).',
        '9. Работы выполнять по ППР с захватками ≤ 10 м вдоль берега, после устройства дренажа, под геотехническим мониторингом.',
    ]
    y = 160
    for i, s in enumerate(notes):
        b.text(30, y, s, fontsize=9 if i == 0 else 7.6); y -= 5.6
    # условные обозначения (правая часть)
    lx, ly = 250, 395
    b.text(lx, ly, 'Условные обозначения', fontsize=10)
    leg = [('#9e9e9e', 'hatch', 'Грунтоцементные контрфорсы (струйная цементация Jet-2)'),
           ('#a04000', 'line3', 'Обвязочная ж/б балка 1,0×0,6 м по оголовкам контрфорсов'),
           ('#7f8c8d', 'fill', 'Габионная стена, коробки 2×1×1, 2×1,5×1, 2×3×1 м'),
           ('#566573', 'fill', 'Матрацы Рено 0,3 м на геотекстиле, фартук 3 м'),
           ('#7f9a55', 'fill', 'Откос срезки 1:1,5, объёмная георешётка h = 150 мм, посев трав'),
           ('#2e86c1', 'line2', 'Перехватывающий дренаж Д-1, труба Ø160 в щебне'),
           ('#1f618d', 'line1', 'Выпуски дренажа и ливневой канализации ПНД Ø160–200'),
           ('#5dade2', 'line1', 'Горизонтальные дренажные скважины ГДС, Ø108, L = 15–16 м'),
           ('#21618c', 'line2', 'Лоток водоотводный DN200 по бровке'),
           ('#e74c3c', 'tri', 'Инклинометрическая скважина И'),
           ('#3498db', 'circ', 'Пьезометр П'), ('#f1c40f', 'circ', 'Деформационная марка'),
           ('#c0392b', 'dash', 'Демонтируемые сооружения (аварийные)'),
           ('#000000', 'bh', 'Скважина ИГИ'), ('#c0392b', 'sec', 'Линия расчётного разреза')]
    for i, (c, kind, s) in enumerate(leg):
        yy = ly - 9 - 8.5 * i
        if kind == 'hatch':
            b.add_patch(Rectangle((lx, yy - 2), 14, 4, fc=c, ec='k', hatch='///', lw=0.5))
        elif kind == 'fill':
            b.add_patch(Rectangle((lx, yy - 2), 14, 4, fc=c, ec='k', lw=0.5))
        elif kind.startswith('line'):
            b.plot([lx, lx + 14], [yy, yy], color=c, lw=int(kind[-1]) * 0.9)
        elif kind == 'tri':
            b.plot(lx + 7, yy, '^', color=c, ms=6)
        elif kind == 'circ':
            b.plot(lx + 7, yy, 'o', color=c, ms=5, mec='k', mew=0.4)
        elif kind == 'dash':
            b.plot([lx, lx + 14], [yy, yy], color=c, lw=1.2, ls='--')
        elif kind == 'bh':
            b.plot(lx + 7, yy, 'o', mfc='white', mec='k', ms=6); b.plot(lx + 7, yy, 'o', color='k', ms=2)
        elif kind == 'sec':
            b.plot([lx, lx + 14], [yy, yy], color=c, lw=0.8, ls='-.')
        b.text(lx + 18, yy, s, fontsize=8, va='center')
    # состав проекта
    comp = ['Состав проекта (текстовая часть и модели):', '— ПЗ: пояснительная записка с расчётами (PDF);',
            '— Расчёты устойчивости: исходные модули Python, results.json, графики;',
            '— 3D-модель: веб-просмотр (HTML), OBJ/MTL; ЦМР (сущ., проект);',
            '— DXF: план проектных решений в МСК-70, разрезы;',
            '— Ведомость объёмов и укрупнённый сметный расчёт (XLSX);',
            '— Задание на доизыскания; программа мониторинга (в ПЗ).']
    y = 250
    for s in comp:
        b.text(lx, y, s, fontsize=8); y -= 5.5
    pages_add(fig)


def pages_add(fig):
    SHEETS.append(fig)


# ---------------------------------------------------------------- лист 2: план существующего положения
def sheet_plan_exist(pages):
    fig, b = sheet('План существующего положения. М 1:400', 2, pages)
    ax = ax_mm(fig, 30, 70, 148 * 1.0, 244)
    xl, yl = (30, 104), (-10, 112)
    ax.set_position([30 / W2, 75 / H2, (xl[1] - xl[0]) * 2.5 / W2, (yl[1] - yl[0]) * 2.5 / H2])
    topo(ax); plan_frame(ax, xl, yl)
    for w in WALLS_EXIST:
        P = np.array(w['pts'])
        col = '#c0392b' if w['state'] == 'аварийное' else ('#e67e22' if 'недопуст' in w['state'] else '#7f8c8d')
        ax.plot(P[:, 0], P[:, 1], color=col, lw=2.2, zorder=5)
    D = np.array(DECK['poly'] + [DECK['poly'][0]])
    ax.fill(D[:, 0], D[:, 1], fc='#c0392b', alpha=0.25, ec='#c0392b', lw=1.0, hatch='xx', zorder=5)
    ax.text(68, 58.5, 'Обзорная площадка\n(аварийная)', fontsize=6, ha='center', color='#7b241c', zorder=9)
    for key, ln in LINES.items():
        L = 52 if key in ('А-А', 'Б-Б') else 50
        x, y = line_xy(ln, np.array([0, L]))
        ax.plot(x, y, color='#c0392b', lw=0.9, ls='-.', zorder=6)
        ax.text(x[0] - 1, y[0] + 1, key, fontsize=9, color='#c0392b', zorder=9)
        ax.text(x[1] + 0.5, y[1] + 1, key, fontsize=9, color='#c0392b', zorder=9)
    for nm, (x, y, z, lay, gw) in BOREHOLES.items():
        ax.plot(x, y, 'o', mfc='white', mec='k', ms=7, zorder=9); ax.plot(x, y, 'o', color='k', ms=2.5, zorder=9)
        ax.text(x + 1.2, y - 1.8, f'{nm}\n{z:.2f}', fontsize=6, zorder=9)
    # зона потенциального оползня (сущ.): от входа критической поверхности А-А до уреза, вдоль зоны I
    for key in ('А-А', 'Г-Г', 'Б-Б', 'В-В'):
        cr = R['exist'][key]['base']
        x, y = line_xy(LINES[key], np.array([cr['x_in'], DESIGN[key]['edge']]))
        ax.plot(x, y, color='#e74c3c', lw=6, alpha=0.25, solid_capstyle='butt', zorder=4)
        ax.plot(x[0], y[0], 's', color='#e74c3c', ms=4, zorder=7)
    ax.text(48, 36, 'Граница захвата\nкритических поверхностей\nскольжения (сущ.)', fontsize=6, color='#c0392b', zorder=9)
    north(ax, 98, 96)
    # таблица состояния сооружений
    tx, ty = 345, 395
    b.text(tx, ty, 'Ведомость существующих сооружений на склоне', fontsize=10)
    rows = [(w['name'], w['state']) for w in WALLS_EXIST] + [(DECK['name'], 'аварийное'),
            ('Габионы вдоль уреза (по топоплану)', 'требует обследования'), ('Лестничные марши, дорожки, бордюры', 'ограниченно-работоспособное')]
    act = {'аварийное': 'демонтаж', 'недопустимое': 'демонтаж, замена габионами', 'требует обследования': 'обследование, решение по результатам',
           'ограниченно-работоспособное': 'ремонт/частичная замена'}
    y = ty - 8
    for nm, st in rows:
        b.text(tx, y, nm, fontsize=7.2); b.text(tx + 120, y, st, fontsize=7.2, color='#b00' if st == 'аварийное' else 'k')
        b.text(tx + 175, y, act.get(st, ''), fontsize=7.2); y -= 6.5
    b.text(tx, y - 4, 'Состояние — по заключению ООО «НПФ «Инженерные изыскания» (2025) и фотофиксации 2024–2025 гг.\n'
                      'Сооружения расположены вне границ ЗУ :104/:87/:72 (НСПД), на неразграниченных землях.', fontsize=7)
    y -= 22
    b.text(tx, y, 'Характеристика участка', fontsize=10); y -= 7
    for s in ['Склон левого берега р. Ушайки (I надпойм. терраса р. Томи), высота 10–11 м, уклоны 25–31°.',
              'Плато +110,0…+111,1; подошва +100,2…+102,0; урез 99,80 (на дату съёмки).',
              'Грунты: ИГЭ-304 (суглинок мягкопласт.) до +101,6…102,8; ИГЭ-305 (суглинок текучепласт.);',
              'ИГЭ-406 (супесь текучая) с +99,6…101,2; ИГЭ-301 (суглинок полутвёрдый) — в скв. С-2а до 3 м.',
              'УГВ (09.2024) +101,6…102,8; в нижней террасе +99,75 (05.2025); весной — верховодка.',
              'k (расч. хар-ки): А-А 0,93; Б-Б 1,01; В-В 1,00; Г-Г 0,96 < [k] = 1,15 — устойчивость не обеспечена.',
              'Замечание к ИГИ: координаты С-3 и С-4 в прил. Д расходятся с картой Г.1 на 5–18 м; принято по карте.']:
        b.text(tx, y, s, fontsize=7.2); y -= 5.5
    pages_add(fig)


# ---------------------------------------------------------------- лист 3: план проектных решений
def sheet_plan_design(pages):
    fig, b = sheet('План проектных решений. М 1:400', 3, pages)
    xl, yl = (30, 104), (-10, 112)
    ax = fig.add_axes([30 / W2, 75 / H2, (xl[1] - xl[0]) * 2.5 / W2, (yl[1] - yl[0]) * 2.5 / H2])
    topo(ax, alpha=0.55); plan_frame(ax, xl, yl)
    # берма и откосы
    L = axis_points(-2.3, S_ALL); Rr = axis_points(2.3, S_ALL)
    ax.fill(np.r_[L[:, 0], Rr[::-1, 0]], np.r_[L[:, 1], Rr[::-1, 1]], fc='#d5c7a6', ec='#7d6608', lw=0.6, zorder=3)
    G1 = axis_points(2.3, S_ALL); G2 = axis_points(5.3, S_ALL)
    ax.fill(np.r_[G1[:, 0], G2[::-1, 0]], np.r_[G1[:, 1], G2[::-1, 1]], fc='#7f8c8d', ec='k', lw=0.5, zorder=4)
    R1 = axis_points(5.3, S_ALL)
    edge = np.array([[float(M.dem.water_edge_x(p[1])[0]) + 2.5, p[1]] for p in axis_points(9.0, S_ALL)])
    ax.fill(np.r_[R1[:, 0], edge[::-1, 0]], np.r_[R1[:, 1], edge[::-1, 1]], fc='#566573', alpha=0.55, ec='k', lw=0.4, zorder=4)
    C = axis_points(-9.5, S_ALL)
    ax.fill(np.r_[C[:, 0], L[::-1, 0]], np.r_[C[:, 1], L[::-1, 1]], fc='#7f9a55', alpha=0.45, ec='#3d5a1e', lw=0.4,
            hatch='..', zorder=3)
    ax.plot(C[:, 0], C[:, 1], color='#3d5a1e', lw=1.0, zorder=5)
    # рёбра ГЦК
    for s in np.arange(2.0, M.AXIS_LEN - 1.0, JET['s_r']):
        a = axis_points(-2.3, [s])[0]; c = axis_points(4.7, [s])[0]
        ax.plot([a[0], c[0]], [a[1], c[1]], color='#424242', lw=1.6, zorder=6)
    ax.plot(*M.AXIS.T, color='#a04000', lw=2.2, zorder=7)
    # пикетаж по оси бермы
    for s in np.arange(0, M.AXIS_LEN + 0.1, 10):
        p = axis_points(-3.6, [s])[0]; q = axis_points(-2.3, [s])[0]
        ax.plot([p[0], q[0]], [p[1], q[1]], 'k-', lw=0.6, zorder=8)
        ax.text(p[0] - 0.4, p[1], f'ПК{int(s // 100)}+{int(s % 100):02d}', fontsize=5.5, ha='right', va='center', zorder=9)
    # дренаж, колодцы, выпуски, лоток
    Dr = np.array(DRAIN_AXIS)
    ax.plot(Dr[:, 0], Dr[:, 1], color='#2e86c1', lw=1.8, zorder=7)
    ax.plot(Dr[:, 0] + 2.6, Dr[:, 1], color='#21618c', lw=1.0, ls='--', zorder=7)
    wells = [Dr[0], Dr[3], Dr[6], Dr[9], Dr[-1]]
    for i, (x, y) in enumerate(wells):
        ax.add_patch(Circle((x, y), 0.9, fc='white', ec='#1b4f72', lw=1.0, zorder=8))
        ax.text(x - 1.4, y + 1.0, f'ДК-{i + 1}', fontsize=6, ha='right', zorder=9)
    for j, (x, y) in enumerate((Dr[0], Dr[6], Dr[-1])):
        s, n = M.axis_frame(np.array([x, y]))
        e = axis_points(13.5, [s])[0]
        ax.annotate('', xy=(e[0], e[1]), xytext=(x, y), arrowprops=dict(arrowstyle='->', color='#1f618d', lw=1.2), zorder=8)
        ax.text(e[0] + 0.5, e[1] + 0.8, f'Вып.-{j + 1}', fontsize=6, color='#1f618d', zorder=9)
    for s in np.arange(3.25, M.AXIS_LEN - 1.0, JET['s_r']):
        a = axis_points(-2.0, [s])[0]; c = axis_points(-14.0, [s])[0]
        ax.plot([a[0], c[0]], [a[1], c[1]], color='#5dade2', lw=0.5, zorder=6)
    # здания
    for bld in BUILDINGS:
        P = np.array(bld['poly'] + [bld['poly'][0]]); ax.plot(P[:, 0], P[:, 1], 'k-', lw=0.8, zorder=6)
    # мониторинг
    INCL = [(57.0, 30.0), (66.0, 53.0), (58.0, 52.0), (71.0, 73.0), (74.0, 86.0)]
    for i, (x, y) in enumerate(INCL):
        ax.plot(x, y, '^', color='#e74c3c', ms=7, mec='k', mew=0.4, zorder=9); ax.text(x + 1, y + 0.8, f'И-{i + 1}', fontsize=6, zorder=9)
    for i, (x, y) in enumerate([(54.0, 40.0), (55.0, 60.0), (60.0, 80.0), (64.0, 96.0)]):
        ax.plot(x, y, 'o', color='#3498db', ms=5, mec='k', mew=0.4, zorder=9); ax.text(x + 1, y - 1.8, f'П-{i + 1}', fontsize=6, zorder=9)
    # лестница
    ax.plot([63.0, 78.0], [66.6, 65.4], color='#6c3483', lw=3, zorder=8); ax.text(70, 67.5, 'лестница', fontsize=6, color='#6c3483', zorder=9)
    # зоны
    zone_s = [(0, 33, 'III'), (33, 63, 'I'), (63, 75, 'I'), (75, M.AXIS_LEN, 'II')]
    for s0, s1, nm in [(0, 33, 'Зона III'), (33, 75, 'Зона I (первоочередная)'), (75, M.AXIS_LEN, 'Зона II')]:
        p = axis_points(15.5, [0.5 * (s0 + s1)])[0]
        ax.text(p[0], p[1], nm, fontsize=8, rotation=80, ha='center', va='center', zorder=9, color='#4a235a',
                bbox=dict(fc='white', ec='#4a235a', lw=0.5, pad=1.5))
        for s in (s0, s1):
            a = axis_points(-12, [s])[0]; c = axis_points(16, [s])[0]
            ax.plot([a[0], c[0]], [a[1], c[1]], color='#4a235a', lw=0.7, ls=(0, (6, 3)), zorder=8)
    for key, ln in LINES.items():
        x, y = line_xy(ln, np.array([10, 50 if key in ('В-В', 'Г-Г') else 54]))
        ax.plot(x, y, color='#c0392b', lw=0.7, ls='-.', zorder=8); ax.text(x[0] - 1, y[0] + 1, key, fontsize=9, color='#c0392b', zorder=9)
    north(ax, 98, 98)
    # ведомость координат оси бермы
    tx, ty = 345, 395
    b.text(tx, ty, 'Ведомость координат оси бермы / обвязочной балки (МСК-70)', fontsize=10)
    y = ty - 8
    b.text(tx, y, 'Точка', fontsize=7.5); b.text(tx + 20, y, 'ПК', fontsize=7.5); b.text(tx + 45, y, 'X', fontsize=7.5)
    b.text(tx + 80, y, 'Y', fontsize=7.5); b.text(tx + 115, y, 'Отм. бермы', fontsize=7.5)
    for i, (x, yv) in enumerate(M.AXIS):
        y -= 5.5
        s = cum_axis[i]; X, Y = data.to_msk(x, yv)
        zb = float(M.fE([[yv, x]])[0]) if False else None
        b.text(tx, y, f'Т{i + 1}', fontsize=7.5); b.text(tx + 20, y, f'{int(s // 100)}+{s % 100:05.2f}', fontsize=7.5)
        b.text(tx + 45, y, f'{X:.2f}', fontsize=7.5); b.text(tx + 80, y, f'{Y:.2f}', fontsize=7.5)
        b.text(tx + 115, y, '105,00' if 30 < s < 75 else '104,40', fontsize=7.5)
    y -= 12
    b.text(tx, y, 'Ведомость участков', fontsize=10); y -= 7
    for z in R['quant']['zones']:
        b.text(tx, y, f"Зона {z['zone']}: L = {z['L']:.0f} м, сеч. {z['key']}, рёбер {z['nribs']}, колонн {z['nribs'] * z['ncol']}, "
                      f"глубина {z['jet_depth']:.1f} м", fontsize=7.2); y -= 5.5
    y -= 6
    for s in ['ПРИМЕЧАНИЯ', '1. Оси контрфорсов — перпендикулярно оси бермы, шаг 2,5 м; первое ребро — ПК0+02,0.',
              '2. ГДС выполняются между рёбрами (ПК0+03,25 с шагом 2,5 м) в 2 яруса: с бермы и с нижней террасы.',
              '3. Перехватывающий дренаж Д-1 — по плато в 3–4 м от бровки срезки, уклон ≥ 0,005 к колодцам ДК-1, ДК-3, ДК-5;',
              '   выпуски Вып.-1…3 — закрытые, ПНД Ø160 (дренаж) и Ø200 (ливневой сток), оголовки в креплении Рено.',
              '4. Лоток DN200 по бровке собирает сток с плато и кровель (водосточные трубы зданий подключить).',
              '5. Демонтажу подлежат: обзорная площадка, стены W2, W3, W4, бордюры и лестница в зоне I.',
              '6. Привязка — от пунктов съёмочного обоснования топоплана; разбивку выполнить геодезически.']:
        b.text(tx, y, s, fontsize=7.2 if not s.startswith('ПРИМ') else 9); y -= 5.5
    pages_add(fig)


# ---------------------------------------------------------------- разрезы
HATCH = {'304': '///', '305': '\\\\\\', '406': '...', '301': 'xx', 'stone': 'oo'}
COLS = {'304': '#ead8b5', '305': '#cfe0cc', '406': '#c9d8ea', '301': '#d9b98f'}


def draw_profile(ax, key, state, res_list, xl, yl):
    d = DESIGN[key]
    sec = d['exist']('design') if state == 'exist' else __import__('design').sec_design(key)
    surf = np.asarray(sec.surface)
    xs = np.linspace(xl[0], xl[1], 500)
    g = np.interp(xs, surf[:, 0], surf[:, 1])
    tops = []
    for name, top in sec.layers:
        zt = g if top is None else np.minimum(np.interp(xs, np.asarray(top)[:, 0], np.asarray(top)[:, 1]), g)
        tops.append((name, zt))
    for i, (name, zt) in enumerate(tops):
        zb = tops[i + 1][1] if i + 1 < len(tops) else np.full_like(xs, yl[0])
        zb = np.minimum(zb, zt)
        ax.fill_between(xs, zb, zt, facecolor=COLS[name], edgecolor='#7a6a55', hatch=HATCH[name], lw=0, zorder=1)
        if i > 0:
            ax.plot(xs, zt, color='#5d4e37', lw=0.5, ls='--', zorder=2)
            j = np.argmin(abs(xs - (xl[0] + 6)))
            ax.text(xs[j], zt[j] - 1.1, f'ИГЭ-{name}', fontsize=7, zorder=9, bbox=dict(fc='white', ec='none', pad=0.5))
    ax.text(xl[0] + 6, g[np.argmin(abs(xs - (xl[0] + 6)))] - 1.6, 'ИГЭ-304', fontsize=7, zorder=9, bbox=dict(fc='white', ec='none', pad=0.5))
    ax.fill_between(xs, g, WL_LOW, where=g < WL_LOW, color='#aed6f1', zorder=2)
    gw = np.asarray(sec.water)
    ax.plot(gw[:, 0], np.minimum(gw[:, 1], np.interp(gw[:, 0], surf[:, 0], surf[:, 1])), color='#1f77b4', lw=0.9,
            ls=(0, (8, 2, 2, 2)), zorder=3)
    def lvl(z, txt, x):
        ax.plot([x - 0.6, x + 0.6, x, x - 0.6], [z + 0.6, z + 0.6, z, z + 0.6], color='#1f77b4', lw=0.8, zorder=9)
        ax.plot([x - 2.5, x + 2.5], [z, z], color='#1f77b4', lw=0.8, zorder=9)
        ax.text(x + 2.8, z + 0.1, txt, fontsize=6.5, color='#1f4e79', zorder=9)
    e = d['edge']
    lvl(WL_LOW, f'Урез {WL_LOW:.2f}', e + 4); lvl(WL_FLOOD, f'РУВВ 1% {WL_FLOOD:.2f} (прин.)', e + 4)
    lvl(WL_ICE, f'УВЛ {WL_ICE:.2f}', e + 9)
    j = np.argmin(abs(gw[:, 0] - (xl[0] + 15)))
    ax.text(xl[0] + 15, float(np.interp(xl[0] + 15, gw[:, 0], gw[:, 1])) + 0.3, 'УГВ', fontsize=6.5, color='#1f4e79', zorder=9)
    if state == 'exist':
        ax.plot(surf[:, 0], surf[:, 1], 'k-', lw=1.4, zorder=6)
    else:
        es = np.asarray(d['exist_surf'])
        ax.plot(es[:, 0], es[:, 1], color='#555', lw=0.8, ls='--', zorder=5)
        ax.plot(surf[:, 0], surf[:, 1], 'k-', lw=1.5, zorder=6)
        x1, x2, zb = d['jet']
        gz = lambda x: float(np.interp(x, surf[:, 0], surf[:, 1]))
        ax.add_patch(Poly([(x1, gz(x1) - 0.55), (x2, min(gz(x2), 102.0) - 0.1), (x2, zb), (x1, zb)], closed=True,
                          fc='#bdbdbd', ec='k', hatch='xxx', lw=0.8, zorder=4))
        ax.text(0.5 * (x1 + x2), zb + 3.5, f'ГЦК\nJet-2\nØ1,0\nдо {zb:.1f}', fontsize=6.5, ha='center', zorder=9,
                bbox=dict(fc='white', ec='k', lw=0.4, pad=1))
        ax.add_patch(Poly(d['gabion'], closed=True, fc='#95a5a6', ec='k', hatch='oo', lw=0.8, zorder=7))
        ax.add_patch(Poly(d['toe'], closed=True, fc='#566573', ec='k', lw=0.5, zorder=7))
        b0, b1, bz = d['bench']
        ax.add_patch(Rectangle((b0, bz - 0.6), b1 - b0 - 0.2, 0.6, fc='#a04000', ec='k', lw=0.6, zorder=8))
        # откосы, отметки
        cr = d['crest']
        ax.annotate(f'1:1,5', xy=(0.5 * (cr + b0), 0.5 * (gz(cr) + bz) + 0.6), fontsize=7.5, rotation=-33, zorder=9)
        for xx, lab in ((cr, None), (b0, None), (b1, None), (d['gabion'][1][0], None), (d['edge'], None)):
            ax.plot([xx, xx], [gz(xx), gz(xx) + 1.0], 'k-', lw=0.4, zorder=9)
            ax.text(xx, gz(xx) + 1.15, f'{gz(xx):.2f}', fontsize=6.5, rotation=90, ha='center', va='bottom', zorder=9)
        ax.text(0.5 * (b0 + b1), bz + 1.8, f'берма {b1 - b0:.1f} м', fontsize=6.8, ha='center', zorder=9)
        # дренаж
        dx = cr - 4.0
        ax.add_patch(Rectangle((dx - 0.4, gz(dx) - 3.2), 0.8, 3.2, fc='#d6eaf8', ec='#1f618d', lw=0.6, zorder=8))
        ax.add_patch(Circle((dx, gz(dx) - 2.95), 0.18, fc='#2e86c1', ec='k', lw=0.4, zorder=9))
        ax.text(dx - 0.6, gz(dx) - 3.9, 'Д-1', fontsize=6.5, ha='right', zorder=9)
        for z0, xx0 in ((bz - 0.7, b1 - 0.3), (101.9, d['gabion'][1][0] + 0.1)):
            ax.plot([xx0, xx0 - 15.5], [z0, z0 + 15.5 * math.tan(math.radians(4))], color='#2874a6', lw=0.9, zorder=8)
        ax.text(b1 - 9, bz + 0.0, 'ГДС i = 4°', fontsize=6, color='#1f4e79', zorder=9)
    for res, col, lab in res_list:
        ax.plot(res['xs'], res['zs'], color=col, lw=1.3, zorder=10)
        k = np.argmin(res['zs']); ax.text(res['xs'][k], res['zs'][k] - 1.0, lab, fontsize=7, color=col, ha='center', zorder=10,
                                          bbox=dict(fc='white', ec='none', pad=0.5))
    ax.set_xlim(*xl); ax.set_ylim(*yl); ax.set_aspect('equal')
    ax.set_xticks([]); ax.tick_params(axis='y', labelsize=6.5)
    ax.set_yticks(np.arange(math.ceil(yl[0]), yl[1] + 0.1, 2))
    for sp in ('top', 'right', 'bottom'):
        ax.spines[sp].set_visible(False)


def profile_table(fig, ax_rect, key, xl):
    d = DESIGN[key]
    es = np.asarray(d['exist_surf']); ds = np.asarray(d['surf'])
    a = fig.add_axes(ax_rect); a.set_xlim(*xl); a.set_ylim(0, 3); a.axis('off')
    for yy in (0, 1, 2, 3):
        a.plot(xl, [yy, yy], 'k-', lw=0.5)
    a.text(xl[0] - 0.5, 2.5, 'Отм. сущ., м', ha='right', va='center', fontsize=6.5)
    a.text(xl[0] - 0.5, 1.5, 'Отм. проект., м', ha='right', va='center', fontsize=6.5)
    a.text(xl[0] - 0.5, 0.5, 'Пикет, м', ha='right', va='center', fontsize=6.5)
    pts = sorted(set([round(p, 1) for p in np.r_[np.arange(xl[0], xl[1] + 0.1, 5.0), ds[(ds[:, 0] > xl[0]) & (ds[:, 0] < xl[1]), 0]]]))
    last = -1e9
    for p in pts:
        if p - last < 1.4:
            continue
        last = p
        a.plot([p, p], [0, 3], 'k-', lw=0.25)
        a.text(p, 2.5, f'{np.interp(p, es[:, 0], es[:, 1]):.2f}', rotation=90, ha='center', va='center', fontsize=5.5)
        a.text(p, 1.5, f'{np.interp(p, ds[:, 0], ds[:, 1]):.2f}', rotation=90, ha='center', va='center', fontsize=5.5)
        a.text(p, 0.5, f'{p:.1f}', rotation=90, ha='center', va='center', fontsize=5.5)


def sheet_section(pages, key, num):
    fig, b = sheet(f'Разрез {key}. Существующее положение и проект. М 1:200', num, pages)
    d = DESIGN[key]
    es = np.asarray(d['exist_surf'])
    xl = (max(es[0, 0], d['crest'] - 26), d['edge'] + 12)
    yl = (89.0, 113.0)
    wmm = (xl[1] - xl[0]) * 5; hmm = (yl[1] - yl[0]) * 5
    ex = R['exist'][key]; de = R['design'][key]
    a1 = fig.add_axes([45 / W2, 262 / H2, wmm / W2, hmm / H2])
    draw_profile(a1, key, 'exist', [(ex['base'], '#c0392b', f"k = {ex['base']['F']:.2f} (расч.)"),
                                    (ex['seis'], '#8e44ad', '')], xl, yl)
    b.text(45, 262 + hmm + 6, f'Разрез {key}. Существующее положение (М 1:200)', fontsize=11)
    a2 = fig.add_axes([45 / W2, 92 / H2, wmm / W2, hmm / H2])
    draw_profile(a2, key, 'design', [(de['base'], '#c0392b', f"k = {de['base']['F']:.2f} ≥ 1,15"),
                                     (de['seis'], '#8e44ad', f"сейсм. {de['seis']['F']:.2f} ≥ 1,09")], xl, yl)
    b.text(45, 92 + hmm + 6, f'Разрез {key}. Проект (М 1:200)', fontsize=11)
    profile_table(fig, [45 / W2, 72 / H2, wmm / W2, 15 / H2], key, xl)
    # таблица результатов справа
    tx = 45 + wmm + 18; ty = 395
    b.text(tx, ty, 'Результаты расчёта устойчивости', fontsize=10)
    rows = [('Сущ.: нормативные характеристики', ex['norm']), ('Сущ.: расчётные (α = 0,95), УГВ 09.2024', ex['base']),
            ('Сущ.: весенняя верховодка', ex['perched']), ('Сущ.: сейсмика 7 баллов', ex['seis']),
            ('Проект: основное сочетание', de['base']), ('Проект: сейсмика 7 баллов', de['seis']),
            ('Проект: сработка после паводка', de['rdd']), ('Проект: отказ дренажа (УГВ 09.2024)', de['nodrain']),
            ('Проект без ГЦК (для сравнения)', de['nojet']), ('Строит. период, без ГЦК, расч.', de['constr']),
            ('Строит. период, без ГЦК, норм.', de['constr_n']), ('Проект: откос срезки (локально)', de['upper']),
            ('Проект: нижняя часть (локально)', de['lower'])]
    y = ty - 8
    b.text(tx, y, 'Расчётный случай', fontsize=7); b.text(tx + 70, y, 'Бишоп', fontsize=7); b.text(tx + 85, y, 'Спенсер', fontsize=7)
    b.text(tx + 102, y, '[k]', fontsize=7)
    for nm, r in rows:
        y -= 5.6
        need = 1.09 if any(s in nm for s in ('сейсм', 'Сработ', 'отказ', 'Строит')) else 1.15
        b.text(tx, y, nm, fontsize=6.8)
        b.text(tx + 70, y, f"{r['F']:.3f}", fontsize=6.8, color='#b00' if r['F'] < need else '#145a32')
        b.text(tx + 85, y, f"{r['Fsp']:.3f}", fontsize=6.8)
        b.text(tx + 102, y, f'{need:.2f}', fontsize=6.8)
    y -= 10
    th = de['thrust']; jt = R['jet'][key]
    for s in ['Оползневое давление (метод передачи сил, k = 1,15):',
              f"  на входе в зону ГЦК E_h = {th['Eh_at']:.0f} кН/м; без ГЦК на выходе E = {jt['осн']['E_exit_nojet']:.0f} кН/м (дефицит);",
              f"  с ГЦК на выходе E = {jt['осн']['E_exit_jet']:.0f} кН/м — устойчивость обеспечена;",
              f"  сейсмика: дефицит {jt['сейсм']['E_exit_nojet']:.0f} кН/м, с ГЦК {jt['сейсм']['E_exit_jet']:.0f} кН/м с ГЦК.",
              f"Сопротивление рёбер ГЦК по поверхности скольжения: ΔR = Δc·L = {jet_dc():.0f}·{jt['осн']['L_slip']:.1f} = {jt['осн']['dR']:.0f} кН/м",
              f"  (одно ребро {jt['осн']['T_rib']:.0f} кН, τ_sc = {JET['tau']:.0f} кПа, t = {JET['t']} м, шаг {JET['s_r']} м)."]:
        b.text(tx, y, s, fontsize=6.8); y -= 5.4
    y -= 6
    b.text(tx, y, 'Расчётные характеристики грунтов (I группа)', fontsize=9); y -= 6
    for k2 in ('304', '305', '406', '301'):
        s = SOILS[k2]
        b.text(tx, y, f"ИГЭ-{k2}: γ = {s['g']:.1f}/{s['gs']:.1f} кН/м³, φ = {s['phi']:.0f}° ({s['phi_s']:.0f}° водонас.), "
                      f"c = {s['c']:.0f} ({s['c_s']:.0f}) кПа", fontsize=6.6); y -= 5
    y -= 4
    for s in ['Примечания: 1. Поверхности скольжения: красная — основное сочетание, фиолетовая — сейсмика.',
              '2. Расчёт: метод Бишопа (поиск по сетке центров), проверка методом Спенсера,',
              '   пригрузка плато 10 кПа, бермы 5 кПа; внешняя вода — по урезу 99,80.',
              '3. Под зоной ГЦК прочность учтена как Δc = t·τ_sc/s = ' + f'{jet_dc():.0f} кПа (СП 291.1325800.2017).']:
        b.text(tx, y, s, fontsize=6.6); y -= 5
    pages_add(fig)


# ---------------------------------------------------------------- лист 8: ГЦК
def sheet_jet(pages):
    fig, b = sheet('Грунтоцементные контрфорсы. План, разрез, узлы', 8, pages)
    # фрагмент плана (М 1:100): 3 ребра
    a = fig.add_axes([30 / W2, 245 / H2, 160 / W2, 140 / H2]); a.set_aspect('equal'); a.axis('off')
    a.set_xlim(-1.5, 9.5); a.set_ylim(-1.0, 8.5)
    for r_ in range(3):
        yy = 1.0 + r_ * JET['s_r']
        for c_ in range(11):
            xx = c_ * JET['step']
            reinforced = c_ % 2 == 0
            a.add_patch(Circle((xx, yy), JET['D'] / 2, fc='#d5d8dc', ec='k', lw=0.6, alpha=0.9))
            if reinforced:
                a.add_patch(Circle((xx, yy), 0.073, fc='k'))
        if r_ < 2:
            a.plot([-1.2, 9.0], [yy + 1.25, yy + 1.25], color='#5dade2', lw=1.0, ls='--')
    a.add_patch(Rectangle((-0.5, -0.6), 1.0, 7.2, fc='#a04000', alpha=0.35, ec='#a04000'))
    a.annotate('', xy=(0, 8.0), xytext=(JET['step'], 8.0), arrowprops=dict(arrowstyle='<->', lw=0.6))
    a.text(JET['step'] / 2, 8.15, '750', ha='center', fontsize=7)
    a.annotate('', xy=(8.8, 1.0), xytext=(8.8, 3.5), arrowprops=dict(arrowstyle='<->', lw=0.6))
    a.text(9.0, 2.25, '2500', fontsize=7, rotation=90, va='center')
    a.text(-1.4, 7.8, 'Фрагмент плана контрфорсов (М 1:100)', fontsize=10)
    a.text(3.5, -0.8, 'к реке >>  (ось ребра перпендикулярна оси бермы)', fontsize=7)
    a.text(-1.3, 6.9, 'обвязочная\nбалка', fontsize=6.5, color='#a04000')
    a.text(4.0, 2.3, 'ГДС между рёбрами', fontsize=6.5, color='#1f618d')
    # разрез по ребру (М 1:100) — на основе А-А
    d = DESIGN['А-А']; x1, x2, zb = d['jet']
    a2 = fig.add_axes([215 / W2, 120 / H2, 160 / W2, 270 / H2]); a2.set_aspect('equal')
    surf = np.array(d['surf'])
    xs = np.linspace(34, 52, 200); g = np.interp(xs, surf[:, 0], surf[:, 1])
    a2.fill_between(xs, 88.5, g, color='#ead8b5', hatch='///', lw=0)
    for c_ in range(int((x2 - x1) / JET['step']) + 1):
        xx = x1 + 0.5 + c_ * JET['step']
        top = min(float(np.interp(xx, surf[:, 0], surf[:, 1])), 102.0 if xx > 43 else 105.0) - (0.6 if xx < 43 else 0.1)
        a2.add_patch(Rectangle((xx - 0.5, zb), 1.0, top - zb, fc='#d5d8dc', ec='k', lw=0.4, alpha=0.95))
        if c_ % 2 == 0:
            a2.plot([xx, xx], [zb + 0.3, top], 'k-', lw=1.2)
    a2.add_patch(Poly(d['gabion'], closed=True, fc='#95a5a6', ec='k', hatch='oo', lw=0.6))
    a2.add_patch(Rectangle((38.4, 104.4), 4.4, 0.6, fc='#a04000', ec='k'))
    a2.plot(xs, g, 'k-', lw=1.2)
    cr = R['design']['А-А']['nojet']
    a2.plot(cr['xs'], cr['zs'], color='#c0392b', lw=1.0)
    a2.text(40.0, 96.0, 'поверхность\nскольжения\n(без ГЦК)', fontsize=6.5, color='#c0392b')
    a2.set_xlim(34, 52); a2.set_ylim(88.5, 112)
    a2.set_yticks(np.arange(89, 112, 1)); a2.tick_params(labelsize=6); a2.set_xticks([])
    for zz, lab in ((105.0, '105,00 (берма)'), (102.0, '102,00'), (zb, f'{zb:.2f} низ ГЦК')):
        a2.plot([51.0, 52.0], [zz, zz], 'k-', lw=0.5); a2.text(51.0, zz + 0.2, lab, fontsize=6.5, ha='right')
    a2.set_title('Разрез по ребру контрфорса (сеч. А-А, М 1:100)', fontsize=10)
    # узлы и технические требования
    tx, ty = 395, 395
    b.text(tx, ty, 'Технические требования к ГЦК', fontsize=10)
    req = [
        '1. Технология — струйная цементация по двухкомпонентной схеме (Jet-2: раствор + воздух).',
        '2. Колонны Ø1,0 м (контроль по пробным колоннам), шаг в ребре 0,75 м, перекрытие ≥ 0,25 м.',
        '3. Порядок: первичные колонны через одну, вторичные — не ранее 24 ч и не позднее 72 ч.',
        '4. Ориентировочные параметры (уточняются по пробным колоннам): давление раствора 40–45 МПа,',
        '   воздуха 0,8–1,2 МПа; В/Ц = 0,8–1,0; подъём 15–25 см/мин; вращение 8–15 об/мин; расход',
        '   цемента ЦЕМ I 42,5Н 350–450 кг на 1 м³ грунтоцемента.',
        '5. Требуемая прочность грунтоцемента в 28 сут: R_сж ≥ 1,5 МПа (обеспеченность 0,95),',
        '   модуль E ≥ 300 МПа. Расчётное сопротивление срезу τ_sc = 150 кПа.',
        '6. Армирование — стальная труба 146×8 (ГОСТ 8732, ст. 09Г2С) в каждой второй колонне на всю',
        '   длину, погружение в свежий грунтоцемент; верх — с выпуском 0,5 м в обвязочную балку.',
        '7. Обвязочная балка 1,0×0,6 м, бетон B30 F150 W6, арматура А500С: 4Ø20 верх/низ, хомуты Ø10 шаг 200.',
        '8. Контроль качества (СП 45.13330.2017, СП 291.1325800.2017): пробные колонны — 3 шт. до начала',
        '   работ с отрывкой и кернением; керн из 2 % колонн на всю глубину; испытания кубов/кернов',
        '   на сжатие; контроль давления, расхода и скорости подъёма по каждому метру; акты освидетельствования.',
        '9. При прочности ниже требуемой — уменьшение шага рёбер до 2,0 м по расчёту.',
        '10. Отметки низа ГЦК — 90,00 (при выявлении доизысканиями прочных грунтов выше — корректировать).']
    y = ty - 8
    for s in req:
        b.text(tx, y, s, fontsize=7); y -= 5.4
    y -= 6
    T = R['quant']['total']
    b.text(tx, y, 'Спецификация (весь участок)', fontsize=10); y -= 7
    for nm, v in [('Рёбра ГЦК', f"{T['ribs']:.0f} шт."), ('Колонны Ø1,0 м', f"{T['cols']:.0f} шт."),
                  ('Длина колонн', f"{T['col_m']:.0f} п. м"), ('Грунтоцемент', f"{T['soilcrete_m3']:.0f} м³"),
                  ('Цемент ЦЕМ I 42,5Н (оценка)', f"{T['cement_t']:.0f} т"), ('Труба 146×8', f"{T['pipe_m']:.0f} м / {T['pipe_t']:.1f} т"),
                  ('Обвязочная балка B30', f"{T['bench'] * 0.6:.0f} м³"), ('Пробные колонны', '3 шт.')]:
        b.text(tx, y, nm, fontsize=7.5); b.text(tx + 90, y, v, fontsize=7.5); y -= 5.6
    pages_add(fig)


# ---------------------------------------------------------------- лист 9: габионы и крепление
def sheet_gabion(pages):
    fig, b = sheet('Габионная стена и крепление подошвы. Поперечник, узлы', 9, pages)
    a = fig.add_axes([30 / W2, 150 / H2, 300 / W2, 230 / H2]); a.set_aspect('equal')
    # схема в локальных координатах (м): ось x от тыла габиона
    gz = 101.6
    a.fill_between([-3, 13], 97.5, [101.6, 101.6], color='#cfe0cc', hatch='\\\\', lw=0)
    a.fill_between([-3, 0], 101.6, 105.0, color='#ead8b5', hatch='///', lw=0)
    tiers = [(0, 3.0, 101.6, 102.6), (0, 2.5, 102.6, 103.6), (0, 2.0, 103.6, 104.6)]
    for x0, w, z0, z1 in tiers:
        for k in np.arange(x0, x0 + w - 0.01, 1.0 if w <= 2 else 1.5):
            a.add_patch(Rectangle((k, z0), min(1.0 if w <= 2 else 1.5, x0 + w - k), z1 - z0, fc='#aab7b8', ec='k', hatch='oo', lw=0.6))
    a.add_patch(Rectangle((0, 104.6), 0.0, 0.4, fc='k'))
    a.plot([-0.25, -0.25], [101.4, 104.8], color='#1f618d', lw=2.5)
    a.text(-0.6, 103.0, 'щебень 20–40\nв геотекстиле\nδ = 0,3 м', fontsize=6.5, ha='right')
    a.add_patch(Circle((-0.25, 101.85), 0.12, fc='#2e86c1', ec='k'))
    a.text(-0.5, 101.4, 'дрена Ø110', fontsize=6.5, ha='right')
    a.add_patch(Rectangle((-0.3, 101.4), 3.6, 0.2, fc='#bfc9ca', ec='k', lw=0.5))
    a.text(1.5, 101.15, 'подушка — щебень 40–70, 0,2 м, на геотекстиле', fontsize=6.5, ha='center')
    # матрац Рено и фартук
    pts = np.array([[3.0, 101.6], [4.6, 101.55], [7.8, 100.0], [9.9, 99.0], [12.9, 99.0]])
    a.plot(pts[:, 0], pts[:, 1] + 0.3, 'k-', lw=0.8); a.plot(pts[:, 0], pts[:, 1], 'k-', lw=0.8)
    for i in range(len(pts) - 1):
        a.fill_between(pts[i:i + 2, 0], pts[i:i + 2, 1], pts[i:i + 2, 1] + 0.3, color='#7b8a8b', hatch='..', lw=0)
    a.fill_between([7.0, 14], [99.8, 99.8], [99.0, 99.0], color='#aed6f1', alpha=0.6)
    a.text(8.6, 100.6, 'матрац Рено 6×2×0,3 м\nна геотекстиле 300 г/м²', fontsize=6.5)
    a.text(10.0, 98.6, 'фартук 3,0 м (самоукладывающийся)', fontsize=6.5)
    a.plot([6, 13], [WL_LOW, WL_LOW], color='#1f77b4', lw=0.8); a.text(12.9, WL_LOW + 0.1, f'урез {WL_LOW:.2f}', fontsize=6.5, ha='right')
    a.plot([-3, 13], [WL_FLOOD, WL_FLOOD], color='#1f77b4', lw=0.8, ls=':'); a.text(12.9, WL_FLOOD + 0.1, f'РУВВ 1% {WL_FLOOD:.2f}', fontsize=6.5, ha='right')
    a.plot([-3, 13], [WL_ICE, WL_ICE], color='#1f77b4', lw=0.6, ls='--'); a.text(12.9, WL_ICE + 0.1, f'УВЛ {WL_ICE:.2f}', fontsize=6.5, ha='right')
    for x0, w, z0, z1 in tiers:
        a.text(x0 + w + 0.1, (z0 + z1) / 2, f'{w:.1f}', fontsize=6.5)
    a.text(1.0, 104.95, 'берма 105,00 (обвязочная балка ГЦК — за тылом)', fontsize=6.5)
    a.set_xlim(-3, 13.5); a.set_ylim(97.5, 106); a.set_xticks([]); a.tick_params(labelsize=6)
    a.set_title('Поперечник габионной стены h = 3,0 м и крепления подошвы (М 1:50)', fontsize=10)
    tx, ty = 345, 395
    gb = R['gabion']; rv = R['revet']
    b.text(tx, ty, 'Расчёт габионной стены (СП 381.1325800.2018)', fontsize=10)
    y = ty - 8
    for s in [f"Активное давление (Ренкин, φ = 7°, c = 10 кПа, q = 5 кПа): Ka = {gb['h30']['Ka']}, Ea = {gb['h30']['Ea']} кН/м",
              f"Вес стены W = {gb['h30']['W']} кН/м (γ_габ = 17 кН/м³)",
              f"Сдвиг: γlc·F = {gb['h30']['cond_slide']} ≤ γc·R/γn = {gb['h30']['cond_slide_R']} кН/м — обеспечено",
              f"Опрокидывание: k = {gb['h30']['k_overturn']} > 1,5; эксцентриситет e = {gb['h30']['e']} м",
              f"Давление под подошвой p_max/p_min = {gb['h30']['pmax']}/{gb['h30']['pmin']} кПа < R = {gb['h30']['R0_305']} кПа",
              'Общая устойчивость — в составе расчёта склона (листы 4–7).']:
        b.text(tx, y, s, fontsize=7); y -= 5.6
    y -= 6
    b.text(tx, y, 'Крепление подошвы и гидравлические проверки', fontsize=10); y -= 8
    for s in [f"Расчётная скорость V = {rv['V']} м/с (принята), глубина у берега в паводок h = {rv['h0']} м",
              f"Крупность камня наброски по Избашу d = {rv['d_isbash']} м; матрац Рено 0,3 м (камень 70–150 мм)",
              f"  допускаемая скорость {rv['Vadm_reno']} м/с > {rv['V']} м/с — устойчив",
              f"Глубина местного размыва (оценка) h_s = {rv['hs']} м; фартук L = 3,0 м ≥ {rv['L_apron']} м",
              f"Ледовая нагрузка на откосное крепление (оценка) q ≈ {rv['q_ice']:.0f} кН/м — воспринимается габионами",
              'Верх крепления подошвы — 102,0; габионы до 104,6–105,0 > РУВВ 1% + 0,5 = 103,5.',
              'Сетка двойного кручения 8×10, проволока 2,7 мм Zn-Al (Галфан) + ПВХ 3,7 мм; камень',
              'габионов 100–250 мм, морозостойкость F100, прочность ≥ 60 МПа (ГОСТ 8267).']:
        b.text(tx, y, s, fontsize=7); y -= 5.6
    y -= 6
    b.text(tx, y, 'Спецификация (весь участок)', fontsize=10); y -= 8
    T = R['quant']['total']
    for nm, v in [('Габионы коробчатые (объём)', f"{T['gabion']:.0f} м³"), ('Матрацы Рено 0,3 м', f"{T['reno']:.0f} м²"),
                  ('Геотекстиль 300 г/м² (Рено, габионы)', f"{T['reno'] * 1.15 + T['gabion'] * 1.2:.0f} м²"),
                  ('Камень для габионов и матрацев', f"{T['gabion'] * 1.05 + T['reno'] * 0.3 * 1.05:.0f} м³"),
                  ('Щебень 20–40 дренирующий за габионами', f"{T['bench'] * 1.0:.0f} м³"),
                  ('Дрена Ø110 за габионами', f"{T['bench']:.0f} м")]:
        b.text(tx, y, nm, fontsize=7.5); b.text(tx + 110, y, v, fontsize=7.5); y -= 5.6
    pages_add(fig)


# ---------------------------------------------------------------- лист 10: дренаж
def sheet_drain(pages):
    fig, b = sheet('Дренаж и водоотвод. Продольный профиль Д-1, узлы', 10, pages)
    Dr = np.array(DRAIN_AXIS)
    s = np.r_[0, np.cumsum(np.hypot(*np.diff(Dr, axis=0).T))]
    ss = np.linspace(0, s[-1], 300)
    xs = np.interp(ss, s, Dr[:, 0]); ys = np.interp(ss, s, Dr[:, 1])
    zg = np.array([float(M.fE([[y, x]])[0]) for x, y in zip(xs, ys)])
    wells_s = [s[0], s[3], s[6], s[9], s[-1]]
    inv = np.zeros_like(ss)
    # лоток: от вершин к выпускам ДК-1 (юг), ДК-3, ДК-5 (север) с уклоном ≥ 0,005 и глубиной ≥ 3,0 м
    for i, x in enumerate(ss):
        inv[i] = float(np.interp(x, ss, zg)) - 3.2
    a = fig.add_axes([40 / W2, 250 / H2, (s[-1] * 3.5) / W2, 120 / H2])
    a.plot(ss, zg, 'k-', lw=1.0, label='поверхность плато'); a.plot(ss, inv, color='#2e86c1', lw=1.6, label='лоток трубы Д-1')
    for k, w in enumerate(wells_s):
        zi = float(np.interp(w, ss, zg))
        a.add_patch(Rectangle((w - 0.5, zi - 3.6), 1.0, 3.75, fc='white', ec='#1b4f72', lw=0.8))
        a.text(w, zi + 0.5, f'ДК-{k + 1}', ha='center', fontsize=7)
    a.set_ylim(105.5, 111.5); a.set_xlim(-2, s[-1] + 2); a.grid(alpha=0.3); a.tick_params(labelsize=6.5)
    a.set_xlabel('Расстояние по оси Д-1, м', fontsize=7); a.set_ylabel('Отметка, м', fontsize=7)
    a.legend(fontsize=7, loc='lower right'); a.set_title('Продольный профиль перехватывающего дренажа Д-1 (М гор. 1:500, верт. 1:50)', fontsize=10)
    # узел траншеи
    t = fig.add_axes([40 / W2, 85 / H2, 110 / W2, 140 / H2]); t.set_aspect('equal'); t.axis('off')
    t.add_patch(Rectangle((0, 0), 0.8, 3.2, fc='#d5d8dc', ec='k', hatch='..', lw=0.6))
    t.add_patch(Rectangle((-0.05, -0.05), 0.9, 3.0, fill=False, ec='#1f618d', lw=1.2, ls='--'))
    t.add_patch(Circle((0.4, 0.3), 0.08, fc='#2e86c1', ec='k'))
    t.add_patch(Rectangle((0, 2.9), 0.8, 0.3, fc='#a0522d', ec='k', lw=0.5))
    t.fill_between([-1, 1.8], -0.4, 3.2, color='#ead8b5', hatch='///', lw=0, zorder=0)
    t.set_xlim(-1.2, 2.4); t.set_ylim(-0.6, 3.6)
    for yy, s_ in ((3.05, 'глиняный замок 0,3 м'), (2.0, 'щебень 20–40 (ГОСТ 8267)'), (1.0, 'геотекстиль 200 г/м²'),
                   (0.3, 'труба ПВХ гофр. перф. Ø160 SN8\nв фильтре, i ≥ 0,005')):
        t.text(0.95, yy, s_, fontsize=6.5, va='center')
    t.text(-1.1, 3.45, 'Узел 1. Траншея Д-1 (М 1:25)', fontsize=9)
    t.text(0.4, -0.5, '800', ha='center', fontsize=6.5); t.text(-0.3, 1.6, '3200', rotation=90, fontsize=6.5, va='center')
    # узел ГДС и колодца — текст
    tx, ty = 175, 225
    b.text(tx, ty, 'Узел 2. Горизонтальная дренажная скважина (ГДС)', fontsize=9); y = ty - 7
    for s_ in ['Бурение Ø108 мм с уклоном 3–5° к устью, L = 15–16 м, между рёбрами ГЦК;',
               'фильтр — труба ПВХ Ø63 с перфорацией (щель 1,5 мм), в оболочке геотекстиля 150 г/м²;',
               'устье — глухая труба 1,5 м с тампоном (цемент-бентонит), выпуск в дренирующий щебень',
               'за габионами / в лоток бермы; 2 яруса: с бермы (отм. ≈104,3) и с нижней террасы (≈102,3).',
               'Промывка после устройства и 1 раз в 2 года.']:
        b.text(tx, y, s_, fontsize=7); y -= 5.3
    y -= 4; b.text(tx, y, 'Узел 3. Колодец ДК Ø1000 (полимерный, ГОСТ 32972)', fontsize=9); y -= 7
    for s_ in ['Глубина 3,6 м, отстойная часть 0,4 м, люк лёгкого типа с утеплением; лестница-скобы;',
               'выпуск из ДК-1, ДК-3, ДК-5 — ПНД Ø160 SN8 в утеплённой траншее до отм. 105, далее по откосу',
               'в обойме из щебня на анкерах; оголовок — бетонный с обратным клапаном, в матраце Рено,',
               'низ выпуска 100,30 (выше межени), гаситель — каменная рисберма 1,5×2,0 м.']:
        b.text(tx, y, s_, fontsize=7); y -= 5.3
    dr = R['drain']
    tx2, ty2 = 360, 225
    b.text(tx2, ty2, 'Гидравлические расчёты', fontsize=10); y = ty2 - 8
    for s_ in [f"Приток подземных вод к Д-1 (Дюпюи, k = {dr['k']} м/сут, H = 2,0 м, R = 20 м):",
               f"  q = {dr['q1']} м³/сут на 1 м, Q = {dr['Qgw_m3d']} м³/сут на {dr['Ld']:.0f} м — мал;",
               '  диаметр Ø160 принят по условиям эксплуатации (промывка, ревизия).',
               f"  Пропускная способность Ø160 при i = 0,005, h/D = 0,6: {dr['Q_drain160']} л/с.",
               f"Ливневой сток с плато F = {dr['F_ha']} га, ψ = {dr['psi']}, q20 = 80 л/(с·га), P = 2 года:",
               f"  q_t = {dr['q_t']} л/(с·га), Q = {dr['Q_rain']} л/с (СП 32.13330.2018, метод пред. интенсивностей);",
               f"  выпуск ПНД Ø200, i = 0,01: Q_проп = {dr['Q_pipe200']} л/с > {dr['Q_rain']} л/с.",
               'Лоток DN200 по бровке, уклон 0,005, решётки класса A15/B125.',
               'Водосточные трубы домов, гаража, бани подключить к лотку (выпуск на откос запрещается).',
               'Плато спланировать с уклоном от бровки ≥ 0,01 к лотку на ширине 5 м.']:
        b.text(tx2, y, s_, fontsize=7); y -= 5.4
    pages_add(fig)


# ---------------------------------------------------------------- лист 11: ПОС
def sheet_pos(pages):
    fig, b = sheet('Организация строительства. Стройгенплан, этапы', 11, pages)
    xl, yl = (30, 104), (-10, 112)
    ax = fig.add_axes([30 / W2, 75 / H2, (xl[1] - xl[0]) * 2.5 / W2, (yl[1] - yl[0]) * 2.5 / H2])
    topo(ax, alpha=0.5); plan_frame(ax, xl, yl, grid=False)
    L = axis_points(-2.3, S_ALL); Rr = axis_points(2.3, S_ALL)
    ax.fill(np.r_[L[:, 0], Rr[::-1, 0]], np.r_[L[:, 1], Rr[::-1, 1]], fc='#f5cba7', ec='#ba4a00', lw=0.6, zorder=3)
    ax.add_patch(Rectangle((33, 20), 12, 10, fc='#fad7a0', ec='k', lw=0.6, zorder=5)); ax.text(39, 25, 'Растворный узел\nJet, силос 40 т,\nкомпрессор', fontsize=6, ha='center', va='center', zorder=6)
    ax.add_patch(Rectangle((52, 92), 10, 12, fc='#d6eaf8', ec='k', lw=0.6, zorder=5)); ax.text(57, 98, 'Склад габионов,\nкамня, геотекстиля', fontsize=6, ha='center', va='center', zorder=6)
    ax.add_patch(Rectangle((20, 34), 9, 8, fc='#e8daef', ec='k', lw=0.6, zorder=5)); ax.text(24.5, 38, 'Бытовки', fontsize=6, ha='center', va='center', zorder=6)
    ax.plot([18, 33, 52, 60, 66], [26, 26, 27, 73, 80], color='#784212', lw=2.5, ls='--', zorder=6)
    ax.text(45, 29, 'временный проезд (плиты)', fontsize=6, zorder=7)
    ramp = np.array([[60.5, 92.0], [66.0, 88.0], [72.0, 82.0], [75.5, 78.0]])
    ax.plot(ramp[:, 0], ramp[:, 1], color='#ba4a00', lw=4, alpha=0.7, zorder=6); ax.text(68, 91, 'временный пандус\nна берму, i ≤ 15 %', fontsize=6, zorder=7)
    ax.add_patch(Circle((58, 60), 14, fill=False, ec='#c0392b', ls='--', lw=0.8, zorder=6)); ax.text(46, 74, 'зона действия\nавтокрана 25 т', fontsize=6, color='#c0392b', zorder=7)
    ax.plot([33, 60], [25, 50], color='#2e86c1', lw=1, ls=':', zorder=6); ax.text(42, 42, 'рукава высокого\nдавления', fontsize=6, color='#1f618d', zorder=7)
    for i, (s0, s1) in enumerate([(33, 43), (43, 53), (53, 63), (63, 75)]):
        p = axis_points(0, [0.5 * (s0 + s1)])[0]
        ax.text(p[0] + 0.5, p[1], f'З{i + 1}', fontsize=7, fontweight='bold', color='#7b241c', zorder=8,
                bbox=dict(fc='white', ec='#7b241c', lw=0.5, pad=1))
    ax.plot([25, 102, 102, 25, 25], [-6, -6, 108, 108, -6], color='#c0392b', lw=0.8, ls=(0, (8, 4)), zorder=6)
    ax.text(26, 106, 'граница стройплощадки / опасная зона', fontsize=6, color='#c0392b', zorder=7)
    north(ax, 98, 96)
    tx, ty = 345, 395
    b.text(tx, ty, 'Последовательность работ (этапы)', fontsize=10)
    stages = [
        ('0', 'Противоаварийные: ограждение и запрет доступа на склон; разгрузка бровки; временный водоотвод;', '2–3 нед.'),
        ('', 'установка инклинометров И-1…И-3 и марок; доизыскания (см. ПЗ).', ''),
        ('1', 'Демонтаж обзорной площадки, стен W2–W4, бордюров (сверху вниз, без техники на склоне).', '3–4 нед.'),
        ('2', 'Перехватывающий дренаж Д-1 с колодцами и выпусками; лоток; подключение водостоков.', '3 нед.'),
        ('3', 'ГДС верхнего яруса с существующей террасы; пробные колонны ГЦК (3 шт.), испытания.', '3 нед.'),
        ('4', 'Устройство бермы +105,0 и ГЦК захватками З1…З4 по 10 м (зона I), затем зоны II и III.', '10–14 нед.'),
        ('', 'Срезка верхнего откоса — только после набора ГЦК 70 % прочности на захватке.', ''),
        ('5', 'Обвязочная балка; ГДС нижнего яруса; габионная стена; матрацы Рено и фартук (межень).', '6–8 нед.'),
        ('6', 'Георешётка, растительный грунт, посев, кустарник; лестница; благоустройство.', '3–4 нед.'),
        ('7', 'Мониторинг 2 года после окончания работ; исполнительная документация.', '24 мес.')]
    y = ty - 8
    for n, s_, t_ in stages:
        b.text(tx, y, n, fontsize=7.5); b.text(tx + 6, y, s_, fontsize=7); b.text(tx + 200, y, t_, fontsize=7); y -= 5.6
    y -= 6
    b.text(tx, y, 'Основные машины и механизмы', fontsize=10); y -= 7
    for s_ in ['Установка струйной цементации на гусеничном ходу массой ≤ 15 т (типа Casagrande C6 / Soilmec SM-8);',
               'растворный узел с силосом цемента, насос высокого давления до 50 МПа, компрессор 10–12 м³/мин;',
               'экскаватор 0,25–0,5 м³ (обратная лопата) с длинной стрелой — работа с плато и бермы;',
               'автокран 25 т; буровая установка для ГДС (горизонтальное бурение Ø108);',
               'миниэкскаватор 1,5–3 т; виброплита; автосамосвалы 10 т; поливомоечная машина.']:
        b.text(tx, y, s_, fontsize=7); y -= 5.4
    y -= 6
    b.text(tx, y, 'Требования безопасности и охраны среды', fontsize=10); y -= 7
    for s_ in ['Нагрузка от техники на берме — не более 30 кПа; работы вести захватками ≤ 10 м;',
               'остановка работ при скорости смещений по инклинометрам > 5 мм/сут или трещинах на плато;',
               'работы в русле — только в межень (июль–сентябрь), с илоулавливающим экраном;',
               'шлам струйной цементации — в отстойники с вывозом, сброс в реку запрещён;',
               'заправка техники — вне водоохранной зоны (200 м); биотуалеты; мойка колёс на выезде;',
               'сохранение деревьев вне зоны работ; компенсационная посадка — ива, кизильник, спирея.']:
        b.text(tx, y, s_, fontsize=7); y -= 5.4
    y -= 4; b.text(tx, y, 'Ориентировочная продолжительность: 7–9 мес. (зона I — 4 мес.).', fontsize=8)
    pages_add(fig)


# ---------------------------------------------------------------- лист 12: мониторинг
def sheet_monitor(pages):
    fig, b = sheet('Геотехнический мониторинг. Схема, критерии', 12, pages)
    xl, yl = (30, 104), (-10, 112)
    ax = fig.add_axes([30 / W2, 75 / H2, (xl[1] - xl[0]) * 2.5 / W2, (yl[1] - yl[0]) * 2.5 / H2])
    topo(ax, alpha=0.45); plan_frame(ax, xl, yl, grid=False)
    ax.plot(*M.AXIS.T, color='#a04000', lw=2.0, zorder=5)
    INCL = [(57.0, 30.0), (66.0, 53.0), (58.0, 52.0), (71.0, 73.0), (74.0, 86.0)]
    for i, (x, y) in enumerate(INCL):
        ax.plot(x, y, '^', color='#e74c3c', ms=9, mec='k', zorder=9); ax.text(x + 1.2, y + 1, f'И-{i + 1}', fontsize=7, zorder=9)
    for i, (x, y) in enumerate([(54.0, 40.0), (55.0, 60.0), (60.0, 80.0), (64.0, 96.0)]):
        ax.plot(x, y, 'o', color='#3498db', ms=7, mec='k', zorder=9); ax.text(x + 1.2, y - 2, f'П-{i + 1}', fontsize=7, zorder=9)
    k = 0
    for s in np.arange(4.0, M.AXIS_LEN, 8.0):
        P = axis_points(0, [s])[0]; k += 1
        ax.plot(P[0], P[1], 's', color='#f1c40f', ms=5, mec='k', zorder=9); ax.text(P[0] + 0.8, P[1] - 1.5, f'М{k}', fontsize=5.5, zorder=9)
    for bld in BUILDINGS[:7]:
        for x, y in bld['poly'][:2]:
            k += 1; ax.plot(x, y, 's', color='#f1c40f', ms=5, mec='k', zorder=9); ax.text(x + 0.8, y + 0.6, f'М{k}', fontsize=5.5, zorder=9)
    for bld in BUILDINGS:
        P = np.array(bld['poly'] + [bld['poly'][0]]); ax.plot(P[:, 0], P[:, 1], 'k-', lw=0.7, zorder=6)
    for (x, y) in [(20, 100), (20, 10)]:
        ax.plot(x, y, 'D', color='k', ms=6, zorder=9); ax.text(x + 1, y + 1, 'Rp', fontsize=7, zorder=9)
    north(ax, 98, 96)
    tx, ty = 345, 395
    b.text(tx, ty, 'Состав мониторинга', fontsize=10); y = ty - 8
    for s_ in ['Инклинометрические скважины И-1…И-5 глубиной 22 м (до отм. ≈ 88), обсадка ABS 70 мм,',
               '  заделка цементно-бентонитовым раствором; И-1…И-3 — до начала работ (этап 0).',
               'Пьезометры П-1…П-4 (фильтр в ИГЭ-304/305, 9–12 м), автоматические датчики уровня.',
               'Деформационные марки: по обвязочной балке через 8 м, на габионах, на зданиях (26 шт.).',
               'Глубинные реперы Rp — 2 шт. вне зоны влияния (≥ 40 м от бровки).',
               'Визуальный осмотр трещин на плато и откосах, щелемеры на зданиях.']:
        b.text(tx, y, s_, fontsize=7); y -= 5.4
    y -= 6; b.text(tx, y, 'Периодичность', fontsize=10); y -= 7
    for s_ in ['Этап 0 и строительство: инклинометры и марки — 1 раз в неделю, на захватке ГЦК — ежедневно;',
               'после строительства: 1-й год — ежемесячно, 2-й год — ежеквартально, далее 2 раза в год',
               '(апрель–май после снеготаяния и сентябрь–октябрь); пьезометры — ежемесячно + после ливней.']:
        b.text(tx, y, s_, fontsize=7); y -= 5.4
    y -= 6; b.text(tx, y, 'Критерии (пороговые значения)', fontsize=10); y -= 7
    rows = [('Параметр', 'Внимание', 'Тревога (остановка, меры)'),
            ('Скорость смещения по инклинометру', '> 2 мм/мес', '> 5 мм/сут или > 15 мм/мес'),
            ('Накопленное смещение на уровне скольжения', '> 15 мм', '> 30 мм'),
            ('Осадка/сдвиг обвязочной балки', '> 10 мм', '> 25 мм'),
            ('Подъём УГВ в пьезометрах', '> 102,0', '> 103,0 (проверка дренажа)'),
            ('Раскрытие трещин на плато/зданиях', 'появление', '> 2 мм или прирост'),
            ('Расход дренажа', 'рост в 2 раза', 'вынос грунта (мутность)')]
    for r_ in rows:
        b.text(tx, y, r_[0], fontsize=7); b.text(tx + 95, y, r_[1], fontsize=7); b.text(tx + 140, y, r_[2], fontsize=7); y -= 5.6
    y -= 6
    for s_ in ['Результаты оформлять ежеквартальными отчётами с графиками «смещение—время» и сопоставлением',
               'с расчётной моделью; при достижении уровня «Тревога» — остановка работ, доклад заказчику и',
               'проектировщику, противоаварийные меры (пригрузка, откачка, ограничение доступа).']:
        b.text(tx, y, s_, fontsize=7); y -= 5.4
    pages_add(fig)


# ---------------------------------------------------------------- лист 13: 3D
def sheet_3d(pages):
    fig, b = sheet('3D-модель. Виды', 13, pages)
    site = os.path.join(HERE, '..', 'site')
    imgs = [('r1_exist.png', 'Существующее положение: разрезы, скважины, тело оползня у сеч. А-А'),
            ('r2_design.png', 'Проект: общий вид'),
            ('r3_underground.png', 'Проект, рентген: контрфорсы ГЦК, дренаж Д-1, ГДС, скважины'),
            ('r6_flood.png', 'Проект при РУВВ 1 % (103,00)')]
    pos = [(25, 215), (300, 215), (25, 70), (300, 70)]
    for (fn, cap), (x, y) in zip(imgs, pos):
        p = os.path.join(site, fn)
        if not os.path.exists(p):
            continue
        im = Image.open(p).convert('RGB')
        w, h = im.size
        im = im.crop((0, int(h * 0.08), w, int(h * 0.92)))
        a = fig.add_axes([x / W2, y / H2, 265 / W2, 140 / H2]); a.imshow(im); a.axis('off')
        b.text(x, y + 143, cap, fontsize=9)
    pages_add(fig)


# ---------------------------------------------------------------- DXF (R12)
class DXF:
    def __init__(self):
        self.ent = []; self.layers = {}

    def layer(self, name, color):
        self.layers[name] = color

    def line(self, ly, p, q):
        self.ent += ['0', 'LINE', '8', ly, '10', f'{p[0]:.3f}', '20', f'{p[1]:.3f}', '30', '0.0', '11', f'{q[0]:.3f}', '21', f'{q[1]:.3f}', '31', '0.0']

    def poly(self, ly, pts, closed=False):
        self.ent += ['0', 'POLYLINE', '8', ly, '66', '1', '70', '1' if closed else '0']
        for p in pts:
            self.ent += ['0', 'VERTEX', '8', ly, '10', f'{p[0]:.3f}', '20', f'{p[1]:.3f}', '30', '0.0']
        self.ent += ['0', 'SEQEND', '8', ly]

    def circle(self, ly, c, r):
        self.ent += ['0', 'CIRCLE', '8', ly, '10', f'{c[0]:.3f}', '20', f'{c[1]:.3f}', '30', '0.0', '40', f'{r:.3f}']

    def text(self, ly, p, s, h=1.0, rot=0):
        self.ent += ['0', 'TEXT', '8', ly, '10', f'{p[0]:.3f}', '20', f'{p[1]:.3f}', '30', '0.0', '40', f'{h:.3f}', '1', s, '50', f'{rot:.2f}']

    def save(self, path):
        out = ['0', 'SECTION', '2', 'HEADER', '9', '$ACADVER', '1', 'AC1009', '9', '$DWGCODEPAGE', '3', 'ANSI_1251', '0', 'ENDSEC',
               '0', 'SECTION', '2', 'TABLES', '0', 'TABLE', '2', 'LAYER', '70', str(len(self.layers))]
        for n, c in self.layers.items():
            out += ['0', 'LAYER', '2', n, '70', '0', '62', str(c), '6', 'CONTINUOUS']
        out += ['0', 'ENDTAB', '0', 'ENDSEC', '0', 'SECTION', '2', 'ENTITIES'] + self.ent + ['0', 'ENDSEC', '0', 'EOF']
        open(path, 'w', encoding='cp1251', errors='replace', newline='\r\n').write('\n'.join(out))


def export_dxf():
    dx = DXF()
    for n, c in [('ИЗ_ОСЬ_БЕРМЫ', 30), ('ИЗ_БЕРМА', 42), ('ИЗ_ГЦК_РЕБРА', 8), ('ИЗ_ГАБИОНЫ', 9), ('ИЗ_РЕНО', 250),
                 ('ИЗ_ОТКОС_СРЕЗКИ', 3), ('ИЗ_ДРЕНАЖ_Д1', 5), ('ИЗ_ГДС', 4), ('ИЗ_ЛОТОК', 150), ('ИЗ_ВЫПУСКИ', 160),
                 ('ИЗ_МОНИТОРИНГ', 1), ('ИЗ_ПИКЕТАЖ', 7), ('ИЗ_РАЗРЕЗЫ', 1), ('ИЗ_ДЕМОНТАЖ', 1), ('ИЗ_СКВАЖИНЫ', 7),
                 ('ПРОФИЛЬ_СУЩ', 7), ('ПРОФИЛЬ_ПРОЕКТ', 2), ('ПРОФИЛЬ_ГЦК', 8), ('ПРОФИЛЬ_СКОЛЬЖЕНИЕ', 1), ('ПРОФИЛЬ_ТЕКСТ', 7)]:
        dx.layer(n, c)
    msk = lambda p: (p[0] + data.Y0, p[1] + data.X0)     # DXF X = Y (восток), DXF Y = X (север)
    dx.poly('ИЗ_ОСЬ_БЕРМЫ', [msk(p) for p in M.AXIS])
    for off, ly in ((-2.3, 'ИЗ_БЕРМА'), (2.3, 'ИЗ_БЕРМА'), (5.3, 'ИЗ_ГАБИОНЫ'), (-9.5, 'ИЗ_ОТКОС_СРЕЗКИ')):
        dx.poly(ly, [msk(p) for p in axis_points(off, S_ALL)])
    for s in np.arange(2.0, M.AXIS_LEN - 1.0, JET['s_r']):
        a = axis_points(-2.3, [s])[0]; c = axis_points(4.7, [s])[0]
        dx.line('ИЗ_ГЦК_РЕБРА', msk(a), msk(c))
        for k in range(11):
            P = a + (c - a) * (k * JET['step'] / 7.0)
            dx.circle('ИЗ_ГЦК_РЕБРА', msk(P), 0.5)
    for s in np.arange(0, M.AXIS_LEN + 0.1, 10):
        p = axis_points(-3.6, [s])[0]; dx.text('ИЗ_ПИКЕТАЖ', msk(p), f'ПК{int(s // 100)}+{int(s % 100):02d}', 0.8)
    for s in np.arange(3.25, M.AXIS_LEN - 1.0, JET['s_r']):
        dx.line('ИЗ_ГДС', msk(axis_points(-2.0, [s])[0]), msk(axis_points(-14.0, [s])[0]))
    Dr = np.array(DRAIN_AXIS)
    dx.poly('ИЗ_ДРЕНАЖ_Д1', [msk(p) for p in Dr]); dx.poly('ИЗ_ЛОТОК', [msk((p[0] + 2.6, p[1])) for p in Dr])
    for i, p in enumerate([Dr[0], Dr[3], Dr[6], Dr[9], Dr[-1]]):
        dx.circle('ИЗ_ДРЕНАЖ_Д1', msk(p), 0.5); dx.text('ИЗ_ДРЕНАЖ_Д1', msk((p[0] - 3, p[1] + 1)), f'ДК-{i + 1}', 0.8)
    for w in WALLS_EXIST[:4]:
        dx.poly('ИЗ_ДЕМОНТАЖ', [msk(p) for p in w['pts']])
    dx.poly('ИЗ_ДЕМОНТАЖ', [msk(p) for p in DECK['poly']], closed=True)
    for nm, (x, y, z, lay, gw) in BOREHOLES.items():
        dx.circle('ИЗ_СКВАЖИНЫ', msk((x, y)), 0.4); dx.text('ИЗ_СКВАЖИНЫ', msk((x + 0.8, y)), f'{nm} {z:.2f}', 0.7)
    for key, ln in LINES.items():
        x, y = line_xy(ln, np.array([0.0, 55.0]))
        dx.line('ИЗ_РАЗРЕЗЫ', msk((x[0], y[0])), msk((x[1], y[1]))); dx.text('ИЗ_РАЗРЕЗЫ', msk((x[0], y[0] + 1)), key, 1.2)
    # профили: размещены вне плана (смещение), масштаб 1:1 (м), отметка = Y − 0 + сдвиг
    ox = data.Y0 + 150
    for i, key in enumerate(['А-А', 'Б-Б', 'В-В', 'Г-Г']):
        oy = data.X0 + 200 - i * 40 - 90
        d = DESIGN[key]
        dx.text('ПРОФИЛЬ_ТЕКСТ', (ox, oy + 116), f'Разрез {key} (отм. = Y − {oy:.0f})', 1.5)
        dx.poly('ПРОФИЛЬ_СУЩ', [(ox + p[0], oy + p[1]) for p in d['exist_surf']])
        dx.poly('ПРОФИЛЬ_ПРОЕКТ', [(ox + p[0], oy + p[1]) for p in d['surf']])
        x1, x2, zb = d['jet']
        dx.poly('ПРОФИЛЬ_ГЦК', [(ox + x1, oy + 105), (ox + x2, oy + 102), (ox + x2, oy + zb), (ox + x1, oy + zb)], closed=True)
        dx.poly('ИЗ_ГАБИОНЫ', [(ox + p[0], oy + p[1]) for p in d['gabion']], closed=True)
        cr = R['design'][key]['base']
        dx.poly('ПРОФИЛЬ_СКОЛЬЖЕНИЕ', [(ox + a, oy + c) for a, c in zip(cr['xs'], cr['zs'])])
    dx.save(os.path.join(OUT, 'proekt_beregoukrepleniya_MSK70.dxf'))


if __name__ == '__main__':
    pages = []
    sheet_general(pages); sheet_plan_exist(pages); sheet_plan_design(pages)
    for i, key in enumerate(['А-А', 'Б-Б', 'В-В', 'Г-Г']):
        sheet_section(pages, key, 4 + i)
    sheet_jet(pages); sheet_gabion(pages); sheet_drain(pages); sheet_pos(pages); sheet_monitor(pages); sheet_3d(pages)
    for t in pages:
        t.set_text(str(len(SHEETS)))
    with PdfPages(os.path.join(OUT, 'chertezhi_2026-MOS40-IZ.pdf')) as pdf:
        for i, f in enumerate(SHEETS):
            pdf.savefig(f)
            f.savefig(os.path.join(OUT, f'sheet_{i + 1:02d}.png'), dpi=60)
            plt.close(f)
    export_dxf()
    print('листов', len(SHEETS))
