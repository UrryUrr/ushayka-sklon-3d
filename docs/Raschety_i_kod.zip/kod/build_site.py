# -*- coding: utf-8 -*-
"""Сборка публичного сайта-презентации: 3D-модель + документация проекта (Vercel, статический)."""
import json, os, re, shutil, zipfile
import pymupdf
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
RES_DIR = os.path.join(HERE, 'results')
SITE = os.path.join(HERE, '..', 'site')
OUT = os.path.join(HERE, '..', 'deploy', 'ushayka-sklon-3d')
R = json.load(open(os.path.join(RES_DIR, 'results.json'), encoding='utf-8'))
COST = json.load(open(os.path.join(RES_DIR, 'cost.json')))
for sub in ('docs', 'img/sheets', 'img/thumbs', 'img/fig'):
    os.makedirs(os.path.join(OUT, sub), exist_ok=True)

def mb(p):
    s = os.path.getsize(p)
    return f'{s / 1e6:.1f} МБ'.replace('.', ',') if s >= 100_000 else f'{s / 1e3:.0f} КБ'

# ---------------------------------------------------------------- документы
PZ = os.path.join(OUT, 'docs', 'PZ_2026-MOS40-IZ.pdf'); shutil.copy(os.path.join(RES_DIR, 'PZ_2026-MOS40-IZ.pdf'), PZ)
CH = os.path.join(OUT, 'docs', 'Chertezhi_2026-MOS40-IZ.pdf'); shutil.copy(os.path.join(RES_DIR, 'chertezhi_2026-MOS40-IZ.pdf'), CH)
DXF = os.path.join(OUT, 'docs', 'Plan_razrezy_MSK70.dxf'); shutil.copy(os.path.join(RES_DIR, 'proekt_beregoukrepleniya_MSK70.dxf'), DXF)
XL = os.path.join(OUT, 'docs', 'Smeta_2026-MOS40.xlsx'); shutil.copy(os.path.join(RES_DIR, 'Smeta_ukrupn_2026-MOS40.xlsx'), XL)
OSD = os.path.join(OUT, 'docs', 'Obosnovanie_stoimosti_2026-MOS40.pdf'); shutil.copy(os.path.join(RES_DIR, 'Obosnovanie_stoimosti_2026-MOS40.pdf'), OSD)
os_pages = pymupdf.open(OSD).page_count
OBJZ = os.path.join(OUT, 'docs', 'Model_3D_OBJ.zip')
with zipfile.ZipFile(OBJZ, 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(os.path.join(RES_DIR, 'model.obj'), 'model.obj'); z.write(os.path.join(RES_DIR, 'model.mtl'), 'model.mtl')
CALZ = os.path.join(OUT, 'docs', 'Raschety_i_kod.zip')
with zipfile.ZipFile(CALZ, 'w', zipfile.ZIP_DEFLATED) as z:
    for f in ('data.py', 'slope.py', 'sections.py', 'design.py', 'dem.py', 'run_calcs.py', 'piles.py', 'model3d.py',
              'drawings.py', 'report.py', 'smeta.py', 'cost_rows.py', 'cost_doc.py', 'build_mobile.py', 'build_site.py', 'viewer_mobile.html'):
        z.write(os.path.join(HERE, f), 'kod/' + f)
    z.write(os.path.join(HERE, '..', 'river_edges.json'), 'kod/river_edges.json')
    z.write(os.path.join(RES_DIR, 'results.json'), 'results.json'); z.write(os.path.join(RES_DIR, 'run_log.txt'), 'run_log.txt')
    z.write(os.path.join(RES_DIR, 'cost.json'), 'cost.json')
TXT = os.path.join(OUT, 'docs', 'README.txt')
shutil.copy(os.path.join(HERE, '..', 'README.txt'), TXT)

# оглавление ПЗ со страницами
d = pymupdf.open(PZ)
toc, seen = [], set()
for i, p in enumerate(d):
    if i < 2:
        continue
    for line in p.get_text().strip().split('\n')[:4]:
        m = re.match(r'^(\d{1,2})\.\s*(.*)|^(Приложение\s+[А-Г])\.\s*(.*)', line.replace('\xad', '-').replace('\xa0', ' '))
        if m:
            key = m.group(1) or m.group(3)
            if key not in seen:
                seen.add(key); toc.append([key, ((m.group(2) if m.group(1) else m.group(4)) or '').strip(), i + 1])
            break
for k, t in (('13', 'Охрана окружающей среды, водное и земельное законодательство'),):
    for row in toc:
        if row[0] == k:
            row[1] = t
pz_pages = len(d); d.close()

# листы чертежей → изображения
SHEETS = ['Общие данные', 'План существующего положения, М 1:400', 'План проектных решений, М 1:400',
          'Разрез А-А, М 1:200', 'Разрез Б-Б, М 1:200', 'Разрез В-В, М 1:200', 'Разрез Г-Г, М 1:200',
          'Грунтоцементные контрфорсы', 'Габионная стена и крепление подошвы', 'Дренаж и водоотвод',
          'Организация строительства', 'Геотехнический мониторинг', '3D-модель, виды']
d = pymupdf.open(CH)
sheets = []
for i, p in enumerate(d):
    pix = p.get_pixmap(dpi=110)
    full = os.path.join(OUT, 'img', 'sheets', f'list_{i + 1:02d}.jpg')
    im = Image.frombytes('RGB', (pix.width, pix.height), pix.samples)
    im.save(full, quality=82, optimize=True)
    th = im.copy(); th.thumbnail((560, 560)); th.save(os.path.join(OUT, 'img', 'thumbs', f'list_{i + 1:02d}.jpg'), quality=80)
    sheets.append(dict(n=i + 1, t=SHEETS[i], full=f'img/sheets/list_{i + 1:02d}.jpg', th=f'img/thumbs/list_{i + 1:02d}.jpg'))
d.close()

# рисунки
def fig(src, name, maxw=1600, crop=None):
    im = Image.open(src).convert('RGB')
    if crop:
        w, h = im.size; im = im.crop((int(crop[0] * w), int(crop[1] * h), int(crop[2] * w), int(crop[3] * h)))
    if im.size[0] > maxw:
        im = im.resize((maxw, int(im.size[1] * maxw / im.size[0])), Image.LANCZOS)
    im.save(os.path.join(OUT, 'img', 'fig', name), quality=84, optimize=True)
    return 'img/fig/' + name

PZI = os.path.join(RES_DIR, 'pz_img')
F = dict(photo=fig(os.path.join(PZI, 'photo.jpg'), 'photo.jpg', 900), photo2=fig(os.path.join(PZI, 'photo2.jpg'), 'photo2.jpg', 900))
for k in ('AA', 'BB', 'VV', 'GG'):
    F['sec' + k] = fig(os.path.join(RES_DIR, f'sec_{k}.png'), f'sec_{k}.jpg', 1800)
F['thrust'] = fig(os.path.join(RES_DIR, 'thrust.png'), 'thrust.jpg', 1400)
renders = [('r1_exist', 'Существующее положение: разрезы, скважины, тело оползня'), ('r2_design', 'Проект: общий вид'),
           ('r3_underground', 'Проект, «рентген»: рёбра, дренаж'), ('r4_exist_river', 'Сейчас: вид с реки'),
           ('r5_design_river', 'Проект: вид с реки'), ('r6_flood', 'Проект при паводке 1 %'), ('r7_plan', 'Проект: план'),
           ('r8_aa', 'Вдоль разреза А-А, подземная часть')]
F['renders'] = [dict(src=fig(os.path.join(SITE, n + '.png'), n + '.jpg', 1600, (0, 0.05, 1, 0.95)), t=t) for n, t in renders]
F['phone'] = [dict(src=fig(os.path.join(SITE, n + '.png'), n + '.jpg', 780), t=t) for n, t in
              (('f1_now', 'Телефон: сейчас'), ('f2_prj', 'Телефон: проект'), ('f3_ug', 'Телефон: под землёй'))]

c2 = lambda v: f'{v:.2f}'.replace('.', ',')
E, D = R['exist'], R['design']
T = R['quant']['total']
DOCS = dict(
    pz=dict(href='docs/PZ_2026-MOS40-IZ.pdf', size=mb(PZ), pages=pz_pages, toc=toc),
    ch=dict(href='docs/Chertezhi_2026-MOS40-IZ.pdf', size=mb(CH), sheets=sheets),
    files=[['Пояснительная записка', 'PDF, ' + str(pz_pages) + ' стр.', 'docs/PZ_2026-MOS40-IZ.pdf', mb(PZ)],
           ['Чертежи, 13 листов А2', 'PDF', 'docs/Chertezhi_2026-MOS40-IZ.pdf', mb(CH)],
           ['План и разрезы для AutoCAD', 'DXF, МСК-70', 'docs/Plan_razrezy_MSK70.dxf', mb(DXF)],
           ['Ведомость объёмов и смета', 'XLSX', 'docs/Smeta_2026-MOS40.xlsx', mb(XL)],
           ['Обоснование стоимости (ориентировочно)', 'PDF, ' + str(os_pages) + ' стр.', 'docs/Obosnovanie_stoimosti_2026-MOS40.pdf', mb(OSD)],
           ['3D-модель для Civil 3D, Revit, Blender', 'OBJ + MTL, ZIP', 'docs/Model_3D_OBJ.zip', mb(OBJZ)],
           ['Расчёты: исходный код и результаты', 'Python, JSON, ZIP', 'docs/Raschety_i_kod.zip', mb(CALZ)],
           ['Краткая справка по проекту', 'TXT', 'docs/README.txt', mb(TXT)]],
    fig=F,
    k=[dict(s=s, n=E[s]['norm']['F'], e=E[s]['base']['F'], p=E[s]['perched']['F'], q0=E[s]['seis']['F'],
            d=D[s]['base']['F'], q=D[s]['seis']['F'], r=D[s]['rdd']['F'], nj=D[s]['nojet']['F']) for s in ['А-А', 'Г-Г', 'Б-Б', 'В-В']],
    cost=dict(tot=[round(COST['tot'][0] / 1e6), round(COST['tot'][1] / 1e6)], z1=[round(COST['z1'][0] / 1e6), round(COST['z1'][1] / 1e6)]),
    q=dict(ribs=int(T['ribs']), cols=int(T['cols']), colm=int(T['col_m']), gab=int(T['gabion']), reno=int(T['reno']),
           cut=int(T['cut']), fill=int(T['fill']), bench=int(T['bench'])),
)

# ---------------------------------------------------------------- страница
src = open(os.path.join(SITE, 'zavarzino_3d.html'), encoding='utf-8').read()
src = src.replace(' (КН :79)', '').replace(' (КН :392)', '')
src = src.replace('<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>', '<script src="/lib/three.min.js"></script>')
src = src.replace('<script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>', '<script src="/lib/OrbitControls.js"></script>')
src = src.replace('const DOCS = /*DOCS*/null;', 'const DOCS = ' + json.dumps(DOCS, ensure_ascii=False, separators=(',', ':')) + ';')
src = src.replace('<title>Склон Заварзино 3D</title>', '<title>Берегоукрепление, Мостовая, 40</title>')
assert '/lib/three.min.js' in src and 'const DOCS = {' in src
head = ('<!doctype html><html lang="ru"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
        '<meta name="robots" content="noindex,nofollow"><meta name="format-detection" content="telephone=no">'
        '<meta name="theme-color" content="#e4ebec">'
        '<style>[hidden]{display:none!important}html,body{margin:0}</style></head><body>')
open(os.path.join(OUT, 'index.html'), 'w', encoding='utf-8').write(head + src + '</body></html>')
vj = {"rewrites": [
    {"source": "/lib/three.min.js", "destination": "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"},
    {"source": "/lib/OrbitControls.js", "destination": "https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"}],
      "headers": [{"source": "/(.*)", "headers": [{"key": "X-Robots-Tag", "value": "noindex, nofollow"}]}]}
json.dump(vj, open(os.path.join(OUT, 'vercel.json'), 'w'), indent=1)
open(os.path.join(OUT, 'robots.txt'), 'w').write('User-agent: *\nDisallow: /\n')
tot = sum(os.path.getsize(os.path.join(a, f)) for a, _, fs in os.walk(OUT) for f in fs)
print('сайт собран:', round(tot / 1e6, 1), 'МБ; оглавление:', len(toc), 'пунктов')
