# -*- coding: utf-8 -*-
"""Обоснование стоимости работ (ориентировочная оценка) → PDF (PyMuPDF Story)."""
import json, os
import pymupdf
import smeta  # пересобирает XLSX и cost.json, даёт RF, q, DRL
import cost_rows

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'results')
R = json.load(open(os.path.join(OUT, 'results.json'), encoding='utf-8'))
COST = json.load(open(os.path.join(OUT, 'cost.json'), encoding='utf-8'))
T = R['quant']['total']
RF = smeta.RF
CODE = '2026-МОС40-ИЗ-ОС'
ZN = ('I', 'II', 'III')
CONT = cost_rows.CONT

sp = lambda v: f'{v:,.0f}'.replace(',', ' ')
m1 = lambda v: f'{v / 1e6:.1f}'.replace('.', ',')
m0 = lambda v: f'{v / 1e6:.0f}'
rng = lambda a, b, f=m0: f'{f(a)}–{f(b)}'
pc = lambda v: f'{v * 100:.0f} %'
k2 = lambda v: f'{v:.2f}'.replace('.', ',')


def price(v):
    return sp(v) if v < 1_000_000 else (m1(v) + ' млн')


TAB = [0]
def tab(cap, head, rows, cls=''):
    TAB[0] += 1
    h = ''.join(f'<th>{x}</th>' for x in head)
    body = ''.join('<tr>' + ''.join(f'<td>{c}</td>' for c in r) + '</tr>' for r in rows)
    return f'<p class="tcap">Таблица {TAB[0]} — {cap}</p><table class="{cls}"><tr>{h}</tr>{body}</table>'


# ---------------------------------------------------------------- расчётные величины
qty = [(r, sum(r[3](z) for z in ZN)) for r in RF]
sec = {}
for r, v in qty:
    sec.setdefault(r[0], [0, 0]); sec[r[0]][0] += v * r[4]; sec[r[0]][1] += v * r[5]
base_lo = sum(a for a, b in sec.values()); base_hi = sum(b for a, b in sec.values())
SC = COST['scen']; OLD = COST['old']
jet = next(r for r in RF if r[10] == 'jet'); jet_m = sum(jet[3](z) for z in ZN)
z23 = sum(sum(r[3](z) for z in ('II', 'III')) * (r[4], r[5])[i] for r in RF if r[10] in ('jet', 'pipe') for i in (0,)) , sum(sum(r[3](z) for z in ('II', 'III')) * r[5] for r in RF if r[10] in ('jet', 'pipe'))
pipe_t = sum(next(r for r in RF if r[10] == 'pipe')[3](z) for z in ZN)
E = R['exist']; D = R['design']
SECS = ['А-А', 'Б-Б', 'В-В', 'Г-Г']
mn = lambda r: min(r['F'], r.get('Fsp', r['F']))  # с нормой сравнивается меньшее из Бишопа и Спенсера
kE = [mn(E[s]['base']) for s in SECS]; kP = [mn(E[s]['perched']) for s in SECS]
kD = [min(D[s]['base']['F'], D[s]['base'].get('Fsp', 9)) for s in SECS]
kNJ = [mn(D[s]['nojet']) for s in SECS]

SRC = [
    ('1', 'Стоимость струйной цементации (2025): 3 500–6 000 ₽/п. м; пример расчёта с расходом цемента 300 кг/п. м и долей работ 80–100 % от стоимости материалов',
     'https://grouting.ru/blog/stoimost-struynoy-tsementatsii.html'),
    ('2', 'Струйная цементация грунтов (Jet grouting): 2 000–3 000 ₽/п. м в зависимости от расхода цемента',
     'https://jet-grouting.ru/ukreplenie-gruntov/jet-grouting-struynaya-cementacia-gruntov/'),
    ('3', 'Габионы: короб 2×1×1 м (Zn) 2 823 ₽, с ПВХ 3 473 ₽', 'https://www.td-geo.ru/materials/gabions'),
    ('4', 'Подпорная стена из габионов «под ключ» — от 15 000 ₽/м³; монтаж «под ключ» от 7 000 ₽/м³ (СПб)',
     'https://geo-dvor.ru/services/podpornaya-stena/'),
    ('5', 'Стоимость инженерных изысканий 2025: бурение ≈ 3 500–5 000 ₽/п. м',
     'https://www.uralgeoecology.ru/portfolio/poznavatelnye-materialy-blog/news/price-2025'),
    ('6', 'Бурение скважины на воду: средняя цена ≈ 2 300 ₽/п. м', 'https://finance.rambler.ru/other/44694124-eksperty-rasskazali-skolko-stoit-podvesti-vodu-na-dachu/'),
    ('7', 'Берегозащита и противооползневые работы в пос. Филино (Калининградская обл.): контракт 1,35 млрд ₽, 579 м берегозащиты и нагельное крепление склона 16,4 тыс. м²',
     'https://www.newkaliningrad.ru/news/briefs/community/24159786-dlya-stroitelstva-beregozashchitnykh-sooruzheniy-v-filino-zaklyuchili-kontrakt-na-1-35-mlrd.html'),
]

CH = []
CH.append(f'''
<p class="tt1">ОБОСНОВАНИЕ СТОИМОСТИ РАБОТ</p>
<p class="tt2">Инженерная защита склона левого берега р. Ушайки<br/>ул. Мостовая, 40, п. Заварзино, г. Томск</p>
<p class="tt2">Шифр {CODE} · к пояснительной записке 2026-МОС40-ИЗ-ПЗ · октябрь 2026 г.</p>
<p class="notice"><b>Статус.</b> Оценка ориентировочная, точность ±30 %. Она основана на объёмах работ из расчётной модели проекта,
открытых рыночных ценах 2025–2026 гг. и расчёте по расходу материалов. Цены без НДС, IV квартал 2026 г., с непредвиденными затратами {pc(CONT)}.
Перед заключением договоров стоимость уточняется коммерческими предложениями 2–3 подрядчиков.</p>

<h1>1. Итог</h1>
<p>Ниже — ориентировочная стоимость пяти вариантов: от первоочередных мер до полной защиты склона. Варианты отличаются составом работ
и тем, какой запас устойчивости склона они обеспечивают (норма — 1,15).</p>
{tab('Варианты по бюджету, млн ₽', ['Вариант', 'Без НДС', 'С НДС 22 %', 'Запас устойчивости'], [
    [f"<b>{s['id']}.</b> {s['name']}", rng(*SC[s['id']], m1 if SC[s['id']][1] < 2e7 else m0),
     rng(SC[s['id']][0] * 1.22, SC[s['id']][1] * 1.22, m1 if SC[s['id']][1] < 2e7 else m0), s['k']] for s in cost_rows.SCEN])}
<p>Оценка в пояснительной записке первоначально составляла {rng(*OLD['tot'])} млн ₽ (весь склон) и {rng(*OLD['z1'])} млн ₽ (участок у дома).
При проверке расценки струйной цементации, армирования, габионов, матрацев, дренажа и мобилизации техники приведены к рыночному уровню,
непредвиденные затраты приняты {pc(CONT)} вместо 15 %. Объёмы работ не менялись.</p>
''')

CH.append(f'''
<h1>2. Из чего складывается стоимость полного варианта</h1>
{tab('Структура стоимости варианта A (без непредвиденных и НДС)', ['Раздел', 'Мин, млн ₽', 'Макс, млн ₽', 'Доля'], [
    [k, m1(a), m1(b), pc(a / base_lo)] for k, (a, b) in sec.items()] + [['<b>Итого</b>', f'<b>{m1(base_lo)}</b>', f'<b>{m1(base_hi)}</b>', '100 %'],
    [f'Непредвиденные {pc(CONT)}', m1(base_lo * CONT), m1(base_hi * CONT), ''], ['<b>Всего без НДС</b>', f'<b>{m1(base_lo * (1 + CONT))}</b>', f'<b>{m1(base_hi * (1 + CONT))}</b>', '']])}
<p>Почти две трети стоимости — подземные грунтоцементные рёбра (струйная цементация, армирование, пробные колонны и контроль). Они удерживают склон:
расчётные поверхности скольжения проходят на глубине 13–15 м ниже двора, и без рёбер дренаж и срезка поднимают запас только
до {k2(min(kNJ))}–{k2(max(kNJ))} при норме 1,15.</p>

<h1>3. Объёмы работ</h1>
{tab('Основные объёмы (по расчётной модели, уточняются в рабочей документации)', ['Работа', 'Объём', 'Откуда'], [
    ['Грунтоцементные рёбра', f"{T['ribs']:.0f} рёбер", 'шаг 2,5 м по фронту ≈ 100 м; каждое ребро — 11 колонн Ø1,0 м, длина 7 м в плане, низ на отм. 90,0'],
    ['Колонны струйной цементации', f'{sp(jet_m)} п. м', f'≈ {sp(jet_m * 0.785)} м³ грунтоцемента; цемент ≈ {sp(jet_m * 0.35)}–{sp(jet_m * 0.45)} т'],
    ['Армирование трубой 146×8', f'{sp(pipe_t)} т', 'труба в колоннах рёбер, связь с обвязочной балкой'],
    ['Габионы', f"{sp(T['gabion'])} м³", 'стена 2,4–3 м между полкой и нижней террасой'],
    ['Матрацы Рено 0,3 м', f"{sp(T['reno'])} м²", 'крепление берега от габионов до дна и фартук 3 м'],
    ['Срезка / подсыпка', f"{sp(T['cut'])} / {sp(T['fill'])} м³", 'выполаживание верха до 1:1,5 и полка (берма) +105'],
    ['Перехватывающий дренаж', '102 м', 'вдоль края двора, 3 выпуска, 5 колодцев'],
    ['Горизонтальные дрены', f"{2 * int(T['ribs'])} шт. по 15,5 м", 'между рёбрами, выпуск в габионы'],
    ['Мониторинг', '5 инклинометров, 4 пьезометра', 'наблюдения на время стройки и 2 года после']])}
''')

rows_tab = []
for r, v in qty:
    unit_scale = 1
    rows_tab.append([r[1], r[2], (f'{v:.1f}'.replace('.', ',') if v < 10 else sp(v)),
                     f'{price(r[7])}–{price(r[8])}', f'<b>{price(r[4])}–{price(r[5])}</b>', r[9]])
CH.append(f'''
<h1>4. Расценки: проверка и обоснование</h1>
<p>Для каждой работы сравнены прежняя расценка и принятая после проверки. Номера в квадратных скобках — источники в разделе 8.
Цены — за единицу, ₽ без НДС; «млн» — за комплект.</p>
{tab('Расценки за единицу', ['Работа', 'Ед.', 'Объём', 'Было', 'Принято', 'Обоснование'], rows_tab, 'small')}
''')

CH.append(f'''
<h1>5. Струйная цементация: цена 1 п. м колонны Ø1,0 м</h1>
<p>Это главная статья, поэтому её цена рассчитана по составляющим. В открытых прайсах 2025 г. струйная цементация стоит
2–6 тыс. ₽/п. м [1][2], но эти цены относятся к колоннам меньшего диаметра (0,5–0,8 м) и расходу цемента 50–300 кг/п. м.
Колонна Ø1,0 м содержит 0,785 м³ грунтоцемента и требует больше цемента.</p>
{tab('Расчёт цены 1 п. м', ['Составляющая', 'Расчёт', 'Тыс. ₽/п. м'], [
    ['Цемент', '350–450 кг/п. м (≈ 450–570 кг на 1 м³ грунтоцемента с потерями) × 9,5–11 тыс. ₽/т с доставкой в Томск', '3,3–5,0'],
    ['Работы: установка, насос, компрессор, бригада, энергия', '80–100 % стоимости материалов — по примеру расчёта [1]', '2,7–5,0'],
    ['Шлам', '0,5–1,0 м³ на 1 п. м: сбор, обезвоживание, вывоз', '0,4–0,8'],
    ['<b>Итого</b>', 'принято в смете', f'<b>{jet[4] / 1000:.1f}–{jet[5] / 1000:.1f}</b>'.replace('.', ',')]])}
<p>Прежняя расценка 10–15 тыс. ₽/п. м была выше этого расчёта примерно в 1,5 раза; это основная причина пересмотра.
Мобилизация установки из Новосибирска, пробные колонны и контроль качества учтены отдельными строками.</p>

<h1>6. Варианты по бюджету</h1>
{tab('Состав вариантов и результат', ['Вариант', 'Что входит', 'Без НДС, млн ₽', 'Запас устойчивости', 'Что остаётся'], [
    [f"<b>{s['id']}.</b> {s['name']}", s['what'], rng(*SC[s['id']], m1 if SC[s['id']][1] < 2e7 else m0), s['k'], s['rest']] for s in cost_rows.SCEN], 'small')}
<p>Запас устойчивости по расчётам пояснительной записки: сейчас {k2(min(kE))}–{k2(max(kE))}, весной при верховодке
{k2(min(kP))}–{k2(max(kP))}; без рёбер {k2(min(kNJ))}–{k2(max(kNJ))}; полный проект {k2(min(kD))}–{k2(max(kD))}.
Варианты D0 и D входят в любой следующий вариант и не теряются: дренаж и мониторинг нужны при любом решении,
а доизыскания определяют, сколько рёбер нужно на самом деле.</p>

<h1>7. Что может изменить стоимость</h1>
<p><b>В меньшую сторону.</b> Испытания грунтов по схеме CD могут показать более высокую прочность — тогда объём рёбер на участках II–III
сокращается на 30–50 % (≈ {m0(z23[0] * 0.3 * (1 + CONT))}–{m0(z23[1] * 0.5 * (1 + CONT))} млн ₽). Армирование можно ставить не в каждую колонну. Конкурс 2–3 подрядчиков
по струйной цементации позволит выбрать лучшую цену. Лестница (1,2–2,0 млн ₽) на устойчивость не влияет.</p>
<p><b>В большую сторону.</b> Слабые грунты ниже отм. 94,5 (там нет скважин) — более глубокие рёбра. Глубина реки у берега больше принятой —
больше матрацев. Работы зимой дороже из-за зимнего удорожания. Рост цен на цемент и металл.</p>
<p><b>Сравнение.</b> Полный вариант соответствует {m1(SC['A'][0] / 99)}–{m1(SC['A'][1] / 99)} млн ₽ на 1 м берега (≈ 99 м).
Для сравнения: контракт на берегозащиту и противооползневые работы в пос. Филино — 1,35 млрд ₽ на 579 м, ≈ 2,3 млн ₽/м,
включая нагельное крепление склона [7]. Объекты различаются по составу работ, поэтому сравнение — только по порядку величин.</p>
<p><b>Земля.</b> Склон находится на неразграниченных землях вне границ участков. Работы на нём требуют оформления прав и разрешений;
участие администрации в финансировании возможно в рамках программ инженерной защиты.</p>

<h1>8. Источники цен</h1>
{''.join(f'<p class="src">[{n}] {t}. {u}</p>' for n, t, u in SRC)}
<p class="src">Объёмы — ведомость объёмов «Смета_укрупнённая_2026-МОС40.xlsx» (лист «Ведомость объёмов»); коэффициенты устойчивости —
пояснительная записка 2026-МОС40-ИЗ-ПЗ, разделы 7–9. Расчёт вариантов — лист «Варианты» того же файла.</p>
''')

CSS = '''
@font-face {font-family: tnr; src: url(times.ttf);} @font-face {font-family: tnr; src: url(timesbd.ttf); font-weight: bold;}
@font-face {font-family: ar; src: url(arial.ttf);} @font-face {font-family: ar; src: url(arialbd.ttf); font-weight: bold;}
body {font-family: tnr; font-size: 11.5pt; line-height: 1.32; text-align: justify;}
h1 {font-family: ar; font-size: 13pt; font-weight: bold; margin-top: 10pt; margin-bottom: 6pt; color: #12313b;}
p {margin-top: 0; margin-bottom: 5pt;}
table {border-collapse: collapse; width: 100%; margin-bottom: 8pt;}
td, th {border: 0.5px solid #555; padding: 2pt 3pt; font-family: ar; font-size: 8.5pt; vertical-align: top; text-align: left;}
table.small td, table.small th {font-size: 7.3pt;}
th {font-weight: bold; color: #12313b; border-bottom: 1.2px solid #12313b;}
.tcap {font-family: ar; font-size: 9pt; font-weight: bold; margin-top: 6pt; margin-bottom: 3pt;}
.tt1 {font-family: ar; font-size: 18pt; font-weight: bold; text-align: center; margin-top: 10pt; margin-bottom: 8pt; color: #12313b;}
.tt2 {font-family: ar; font-size: 10.5pt; text-align: center; margin-bottom: 6pt;}
.notice {font-family: ar; font-size: 9pt; border: 1px solid #12313b; padding: 6pt; margin-top: 8pt; margin-bottom: 10pt; text-align: left;}
.src {font-family: ar; font-size: 8.5pt; text-align: left;}
'''


def build():
    arch = pymupdf.Archive('C:/Windows/Fonts')
    raw = os.path.join(OUT, 'os_raw.pdf'); final = os.path.join(OUT, 'Obosnovanie_stoimosti_2026-MOS40.pdf')
    wr = pymupdf.DocumentWriter(raw)
    rect = pymupdf.paper_rect('a4'); where = rect + (57, 50, -34, -50)
    story = pymupdf.Story(html=''.join(CH), user_css=CSS, archive=arch)
    more, n = 1, 0
    while more:
        dev = wr.begin_page(rect); more, _ = story.place(where); story.draw(dev); wr.end_page(); n += 1
    wr.close()
    doc = pymupdf.open(raw); fnt = pymupdf.Font(fontfile='C:/Windows/Fonts/arial.ttf')
    for i, pg in enumerate(doc):
        pg.wrap_contents(); tw = pymupdf.TextWriter(pg.rect)
        tw.append((57, 30), f'{CODE}   Обоснование стоимости · ул. Мостовая, 40, п. Заварзино', font=fnt, fontsize=7.5)
        tw.append((pg.rect.width - 70, pg.rect.height - 25), f'Лист {i + 1}', font=fnt, fontsize=8)
        tw.write_text(pg, color=(0.3, 0.3, 0.3)); pg.draw_line((57, 36), (pg.rect.width - 34, 36), color=(0.6, 0.6, 0.6), width=0.4)
    doc.set_metadata({'title': 'Обоснование стоимости работ — ул. Мостовая, 40', 'author': '', 'creator': '', 'producer': ''})
    doc.subset_fonts(); doc.save(final, garbage=3, deflate=True); doc.close()
    try:
        os.remove(raw)
    except OSError:
        pass
    print('обоснование:', n, 'стр.')


if __name__ == '__main__':
    build()
