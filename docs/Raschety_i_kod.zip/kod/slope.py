# -*- coding: utf-8 -*-
"""Расчёт устойчивости откосов методами предельного равновесия.

Реализовано:
  * метод Бишопа (упрощённый), круглоцилиндрические поверхности, поиск по сетке центров;
  * метод Спенсера (силовое + моментное равновесие), произвольная поверхность;
  * метод передачи сил (оползневое давление, «метод Шахунянца»/imbalance thrust);
  * удерживающие элементы (свайный ряд) — горизонтальная удерживающая сила в точке
    пересечения поверхности скольжения с осью ряда;
  * поровое давление по депрессионной кривой, внешняя вода (река), пригрузки,
    псевдостатическая сейсмика (горизонтальная сила k_h·W).
Знаки: склон понижается в сторону +x, смещение оползня — в сторону +x.
"""
import numpy as np
from matplotlib.path import Path
from scipy.optimize import brentq, fsolve

GW = 10.0


def interp(poly, x):
    p = np.asarray(poly, float)
    return np.interp(x, p[:, 0], p[:, 1])


class Section:
    def __init__(self, name, surface, layers, soils, water=None, wl_ext=None, loads=(), kh=0.0,
                 regions=(), piles=(), sat_below_water=True, perched=None, param='design', reinf=()):
        """surface — [(x,z)]; layers — [(ИГЭ, кровля [(x,z)] или None=поверхность)] сверху вниз;
        regions — [(ИГЭ, полигон [(x,z)])] — переопределяют материал (габионы, засыпка);
        water — депрессионная кривая [(x,z)]; wl_ext — уровень воды в реке;
        perched — линия верховодки [(x,z)] (поровое давление только в пределах верхнего слоя);
        piles — [dict(x, ztop, ztip, H)] — удерживающая сила H, кН/м, по горизонтали."""
        self.name = name
        self.surface = np.asarray(surface, float)
        self.layers = layers
        self.soils = soils
        self.water = None if water is None else np.asarray(water, float)
        self.wl_ext = wl_ext
        self.loads = list(loads)
        self.kh = kh
        self.regions = [(m, Path(np.asarray(p, float))) for m, p in regions]
        self.piles = list(piles)
        self.sat_below_water = sat_below_water
        self.perched = None if perched is None else np.asarray(perched, float)
        self.param = param
        # зоны армирования (грунтоцемент): [(полигон, Δc кПа, Δφ°)] — добавка к прочности по основанию отсека
        self.reinf = [(Path(np.asarray(p, float)), dc, dphi) for p, dc, dphi in reinf]

    # ------------------------------------------------------------ свойства в точке
    def ground(self, x):
        return interp(self.surface, x)

    def material(self, x, z):
        """вектор имён ИГЭ для точек (x,z)"""
        x = np.atleast_1d(x).astype(float); z = np.atleast_1d(z).astype(float)
        out = np.empty(x.shape, dtype=object)
        out[:] = self.layers[0][0]
        # стратиграфия: сверху вниз, нижележащий слой переопределяет
        for name, top in self.layers:
            ztop = self.ground(x) if top is None else interp(top, x)
            out[z <= ztop + 1e-9] = name
        if self.regions:
            pts = np.c_[x, z]
            for name, path in self.regions:
                inside = path.contains_points(pts)
                out[inside] = name
        return out

    def zw(self, x):
        if self.water is None:
            return np.full_like(np.atleast_1d(x).astype(float), -1e9)
        z = interp(self.water, x)
        g = self.ground(x)
        z = np.minimum(z, g)          # депрессионная кривая не выше поверхности (высачивание)
        if self.wl_ext is not None:
            z = np.where(g < self.wl_ext, np.maximum(z, self.wl_ext), z)
        return z

    def props(self, names, below_water):
        sel = self.param
        phi = np.empty(len(names)); c = np.empty(len(names))
        for i, (n, bw) in enumerate(zip(names, below_water)):
            s = self.soils[n]
            if sel == 'normative':
                phi[i], c[i] = s['phi_n'], s['c_n']
            elif bw and self.sat_below_water:
                phi[i], c[i] = s['phi_s'], s['c_s']
            else:
                phi[i], c[i] = s['phi'], s['c']
        return np.radians(phi), c

    # ------------------------------------------------------------ разбиение на отсеки
    def slices(self, xs, zs, n=50):
        """xs, zs — точки поверхности скольжения (по возрастанию x) от входа до выхода."""
        xb = np.linspace(xs[0], xs[-1], n + 1)
        zb = np.interp(xb, xs, zs)
        xm = 0.5 * (xb[1:] + xb[:-1]); b = np.diff(xb)
        zbm = np.interp(xm, xs, zs)
        alpha = np.arctan2(zb[:-1] - zb[1:], b)          # >0 — основание падает к реке
        zt = self.ground(xm)
        h = np.maximum(zt - zbm, 0.0)
        # вес столба: интегрирование по высоте (25 точек)
        m = 25
        t = (np.arange(m) + 0.5) / m
        ZZ = zbm[:, None] + h[:, None] * t[None, :]
        XX = np.repeat(xm[:, None], m, axis=1)
        mats = self.material(XX.ravel(), ZZ.ravel()).reshape(ZZ.shape)
        zwm = self.zw(xm)
        g = np.empty(ZZ.shape)
        for name in set(mats.ravel()):
            s = self.soils[name]
            msk = mats == name
            below = ZZ < zwm[:, None]
            g[msk & below] = s['gs']; g[msk & ~below] = s['g']
        W = (g * (h[:, None] / m)).sum(1) * b
        zcg = np.where(W > 0, (g * ZZ * (h[:, None] / m)).sum(1) * b / np.maximum(W, 1e-9), zbm)
        # внешняя вода (вертикальная пригрузка)
        Q = np.zeros_like(W)
        if self.wl_ext is not None:
            Q += GW * np.maximum(self.wl_ext - zt, 0) * b
        for (x1, x2, q) in self.loads:
            ov = np.clip(np.minimum(xb[1:], x2) - np.maximum(xb[:-1], x1), 0, None)
            Q += q * ov
        # основание
        base_mat = self.material(xm, zbm - 1e-3)
        u = GW * np.maximum(zwm - zbm, 0.0)
        if self.perched is not None:
            zp = interp(self.perched, xm)
            up = GW * np.maximum(zp - zbm, 0.0)
            # верховодка действует в пределах верхнего слоя (над водоупором)
            top2 = self.layers[1][1]
            lim = interp(top2, xm) if top2 is not None else zbm
            up = np.where(zbm > lim - 0.5, up, 0.0)
            u = np.maximum(u, up)
        below = zbm < np.maximum(zwm, (interp(self.perched, xm) if self.perched is not None else zwm))
        phi, c = self.props(base_mat, below)
        for path, dc, dphi in self.reinf:
            ins = path.contains_points(np.c_[xm, zbm])
            c = np.where(ins, c + dc, c); phi = np.where(ins, phi + np.radians(dphi), phi)
        L = b / np.cos(alpha)
        return dict(xm=xm, b=b, alpha=alpha, W=W, Q=Q, u=u, phi=phi, c=c, L=L, zb=zbm, zt=zt,
                    zcg=zcg, mat=base_mat, xb=xb, zbb=zb)

    def pile_force(self, xs, zs):
        """суммарная удерживающая сила и точка приложения для поверхности"""
        res = []
        for p in self.piles:
            if xs[0] < p['x'] < xs[-1]:
                zp = np.interp(p['x'], xs, zs)
                if p['ztip'] <= zp <= p['ztop']:
                    res.append((p['H'], p['x'], zp))
        return res

    # ------------------------------------------------------------ Бишоп
    def bishop_circle(self, xc, zc, R, n=50, min_depth=0.8, ret_slices=False):
        xs, zs = circle_surface(self, xc, zc, R)
        if xs is None:
            return None
        S = self.slices(xs, zs, n)
        if S['W'].sum() <= 0 or (S['zt'] - S['zb']).max() < min_depth:
            return None
        W = S['W'] + S['Q']
        sa, ca = np.sin(S['alpha']), np.cos(S['alpha'])
        tphi = np.tan(S['phi'])
        num0 = S['c'] * S['b'] + np.maximum(W - S['u'] * S['b'], 0) * tphi
        drive = (W * sa).sum() + (self.kh * S['W'] * (zc - S['zcg']) / R).sum()
        if drive <= 0:
            return None
        pf = self.pile_force(xs, zs)
        Mp = sum(H * (zc - zp) for H, _, zp in pf) / R
        F = 1.2
        for _ in range(60):
            ma = ca + sa * tphi / F
            ma = np.maximum(ma, 0.2)
            Fn = ((num0 / ma).sum() + Mp) / drive
            if abs(Fn - F) < 1e-5:
                F = Fn; break
            F = Fn
        out = dict(F=F, xc=xc, zc=zc, R=R, xs=xs, zs=zs, x_in=xs[0], x_out=xs[-1], drive=drive * R,
                   method='Бишоп')
        if ret_slices:
            out['S'] = S
        return out

    def search_bishop(self, xc_rng, zc_rng, nx=18, nz=14, nr=14, x_in=None, x_out=None, min_depth=0.8,
                      depth_max=None, refine=2):
        best = None
        allres = []
        xg = np.linspace(*xc_rng, nx); zg = np.linspace(*zc_rng, nz)
        for it in range(refine + 1):
            for xc in xg:
                for zc in zg:
                    # радиусы: от касания поверхности вглубь
                    zmin_ground = self.surface[:, 1].min()
                    zbot = zmin_ground - (depth_max if depth_max else 12.0)
                    for R in np.linspace(max(zc - self.surface[:, 1].max() + 1.0, 2.0), zc - zbot, nr):
                        r = self.bishop_circle(xc, zc, R, min_depth=min_depth)
                        if r is None:
                            continue
                        if x_in is not None and not (x_in[0] <= r['x_in'] <= x_in[1]):
                            continue
                        if x_out is not None and not (x_out[0] <= r['x_out'] <= x_out[1]):
                            continue
                        allres.append(r)
                        if best is None or r['F'] < best['F']:
                            best = r
            if best is None:
                return None, allres
            dx = (xg[1] - xg[0]); dz = (zg[1] - zg[0])
            xg = np.linspace(best['xc'] - dx, best['xc'] + dx, 9)
            zg = np.linspace(best['zc'] - dz, best['zc'] + dz, 9)
            nr = 16
        return best, allres

    # ------------------------------------------------------------ Спенсер
    def spencer(self, xs, zs, n=50, F0=1.2):
        S = self.slices(np.asarray(xs), np.asarray(zs), n)
        W = S['W'] + S['Q']; a = S['alpha']; tphi = np.tan(S['phi'])
        kW = self.kh * S['W']
        pf = self.pile_force(np.asarray(xs), np.asarray(zs))
        # удерживающая сила свай — как внешняя горизонтальная сила (−x) на отсек с осью ряда
        Pext = np.zeros_like(W);
        for H, xp, zp in pf:
            i = np.searchsorted(S['xb'], xp) - 1
            if 0 <= i < len(W):
                Pext[i] += H

        def Q(F, th):
            num = (S['c'] * S['L'] + (W * np.cos(a) - (kW - Pext) * np.sin(a) - S['u'] * S['L']) * tphi) / F \
                  - (W * np.sin(a) + (kW - Pext) * np.cos(a))
            den = np.cos(a + th) + np.sin(a + th) * tphi / F
            return num / den

        xm, zm = S['xm'], S['zb']

        def eqs(v):
            F, th = v
            q = Q(F, th)
            return [q.sum(), (q * (xm * np.sin(th) - zm * np.cos(th))).sum()]
        # знак: Q — равнодействующая межотсечных сил, направленная по смещению
        try:
            sol, info, ier, msg = fsolve(eqs, [F0, np.radians(10)], full_output=True)
            F, th = sol
            if ier != 1 or not (0.2 < F < 20):
                raise RuntimeError
        except Exception:
            # только силовое равновесие при θ = 0 (Янбу-подобно)
            f = lambda F: Q(F, 0.0).sum()
            try:
                F = brentq(f, 0.3, 10); th = 0.0
            except Exception:
                return None
        return dict(F=F, theta=np.degrees(th), xs=np.asarray(xs), zs=np.asarray(zs), method='Спенсер', S=S)

    # ------------------------------------------------------------ оползневое давление
    def thrust(self, xs, zs, kst, n=60):
        """метод передачи сил: E_i = E_{i-1}·ψ + kst·T − R; возвращает x-границы и E (кН/м),
        E — по направлению основания отсека; горизонтальная составляющая E·cosα."""
        S = self.slices(np.asarray(xs), np.asarray(zs), n)
        W = S['W'] + S['Q']; a = S['alpha']; tphi = np.tan(S['phi'])
        kW = self.kh * S['W']
        T = W * np.sin(a) + kW * np.cos(a)
        Rr = np.maximum(W * np.cos(a) - kW * np.sin(a) - S['u'] * S['L'], 0) * tphi + S['c'] * S['L']
        E = np.zeros(len(W) + 1)
        for i in range(len(W)):
            psi = 1.0 if i == 0 else np.cos(a[i - 1] - a[i]) - np.sin(a[i - 1] - a[i]) * tphi[i]
            E[i + 1] = max(0.0, E[i] * psi + kst * T[i] - Rr[i])
        Eh = E[1:] * np.cos(a)
        return dict(xb=S['xb'], E=E, Eh=np.r_[0, Eh], S=S)


def circle_surface(sec, xc, zc, R, npts=200):
    """пересечение окружности (нижняя дуга) с поверхностью; возвращает точки дуги от входа до выхода"""
    xg = sec.surface[:, 0]
    xx = np.linspace(max(xc - R, xg[0]), min(xc + R, xg[-1]), 1200)
    zarc = zc - np.sqrt(np.maximum(R ** 2 - (xx - xc) ** 2, 0))
    d = sec.ground(xx) - zarc
    s = np.sign(d)
    idx = np.nonzero(np.diff(s) != 0)[0]
    if len(idx) < 2:
        return None, None
    # берём первый вход (земля выше дуги справа от точки) — самый протяжённый сегмент
    segs = []
    for i in range(len(idx) - 1):
        a, b = idx[i], idx[i + 1]
        if d[a + 1] > 0:
            segs.append((a, b))
    if not segs:
        return None, None
    a, b = max(segs, key=lambda t: t[1] - t[0])
    def root(i):
        x1, x2 = xx[i], xx[i + 1]; d1, d2 = d[i], d[i + 1]
        return x1 - d1 * (x2 - x1) / (d2 - d1)
    x_in, x_out = root(a), root(b)
    if x_out - x_in < 1.0:
        return None, None
    xs = np.linspace(x_in, x_out, npts)
    zs = zc - np.sqrt(np.maximum(R ** 2 - (xs - xc) ** 2, 0))
    return xs, zs
