# -*- coding: utf-8 -*-
"""Расчёт свай удерживающего сооружения на оползневое давление.

Модель: стержень на упругопластическом винклеровом основании (СП 24.13330.2021, прил. В):
  C_z = K·z'/γc,  γc = 3, z' — глубина ниже поверхности скольжения;
  предельное давление σ_lim = η1·η2·4/cosφ·(γ·z·tgφ + ξ·c), η1 = 1, η2 = 0,7, ξ = 0,6.
Выше поверхности скольжения — оползневое давление E_h (кН/м) с шагом s, эпюра прямоугольная
(связный оползневой массив), сопротивление грунта ниже по склону не учитывается (в запас).
Сечение — круглое ж/б, бетон B30, арматура А500С; несущая способность по нелинейной
деформационной модели (СП 63.13330.2018, двухлинейная диаграмма бетона).
"""
import numpy as np

Eb = 32.5e6      # кПа, B30
Rb = 17.0e3      # кПа
Rbt = 1.15e3
Rs = 435.0e3     # кПа, A500C
Es = 2.0e8
Rsw = 300.0e3


def bp_width(d, s):
    bp = d + 1.0 if d >= 0.8 else 1.5 * d + 0.5
    return min(bp, s)


def analyse(D, s, L, h_slide, Eh, soils_below, cap_fixity=0.0, nseg=None, kred=0.6, shape='rect'):
    """D — диаметр, м; s — шаг, м; L — длина, м; h_slide — толщина оползня по оси ряда, м;
    Eh — оползневое давление, кН/м; soils_below — [(толщина, K кН/м4, γ, φ°, c)] сверху вниз.
    Возвращает z, w, M, Q, p (реакция), pmax."""
    n = nseg or int(L / 0.1)
    z = np.linspace(0, L, n + 1)
    le = L / n
    I = np.pi * D ** 4 / 64
    EI = kred * Eb * I
    # МКЭ балка Эйлера–Бернулли
    ndof = 2 * (n + 1)
    K = np.zeros((ndof, ndof)); F = np.zeros(ndof)
    ke = EI / le ** 3 * np.array([[12, 6 * le, -12, 6 * le], [6 * le, 4 * le ** 2, -6 * le, 2 * le ** 2],
                                  [-12, -6 * le, 12, -6 * le], [6 * le, 2 * le ** 2, -6 * le, 4 * le ** 2]])
    for e in range(n):
        idx = [2 * e, 2 * e + 1, 2 * e + 2, 2 * e + 3]
        K[np.ix_(idx, idx)] += ke
    # нагрузка выше поверхности скольжения
    P = Eh * s  # кН на сваю
    zc = 0.5 * (z[1:] + z[:-1])
    if shape == 'rect':
        q = np.where(zc <= h_slide, P / h_slide, 0.0)
    else:  # трапеция 0,5…1,5
        qn = np.where(zc <= h_slide, 0.5 + zc / h_slide, 0.0)
        q = qn * P / (qn * le).sum()
    for e in range(n):
        f = q[e] * le
        F[2 * e] += f / 2; F[2 * e + 2] += f / 2
        F[2 * e + 1] += f * le / 12; F[2 * e + 3] -= f * le / 12
    # грунт ниже поверхности скольжения
    bp = bp_width(D, s)
    kz = np.zeros(n + 1); plim = np.full(n + 1, 1e12)
    acc = h_slide; i_layer = 0; zl = 0.0
    lay = []
    t0 = h_slide
    for (t, Kp, g, phi, c) in soils_below:
        lay.append((t0, t0 + t, Kp, g, phi, c)); t0 += t
    lay[-1] = (lay[-1][0], 1e9) + lay[-1][2:]
    sigma_v_slide = 0.0
    for j, zz in enumerate(z):
        if zz <= h_slide:
            continue
        for (a, b, Kp, g, phi, c) in lay:
            if a <= zz < b:
                zp = zz - h_slide
                kz[j] = Kp * zp / 3.0 * bp * le       # кН/м на узел
                ph = np.radians(phi)
                # вертикальное напряжение: эффективный вес выше поверхности скольжения + ниже
                sv = 9.0 * zz
                plim[j] = 1.0 * 0.7 * 4.0 / np.cos(ph) * (sv * np.tan(ph) + 0.6 * c) * bp * le
                break
    # голова: частичное защемление ростверком (поворотная пружина)
    if cap_fixity > 0:
        K[1, 1] += cap_fixity
    # итерации по упругопластическим пружинам
    w = np.zeros(ndof)
    active = np.ones(n + 1, bool)
    Fsoil = np.zeros(n + 1)
    for it in range(60):
        Kt = K.copy(); Ft = F.copy()
        for j in range(n + 1):
            if kz[j] > 0:
                if active[j]:
                    Kt[2 * j, 2 * j] += kz[j]
                else:
                    Ft[2 * j] -= np.sign(w[2 * j]) * plim[j]
        # закрепление от «плавания»: малая пружина в голове
        Kt[0, 0] += 1e-6
        w = np.linalg.solve(Kt, Ft)
        reac = kz * w[0::2]
        new_active = active.copy()
        for j in range(n + 1):
            if kz[j] > 0 and abs(reac[j]) > plim[j]:
                new_active[j] = False
        if (new_active == active).all():
            break
        active = new_active
    wd = w[0::2]
    reac = np.where(active, kz * wd, np.sign(wd) * plim)
    reac = np.where(kz > 0, reac, 0.0)
    # внутренние усилия: из уравнений элементов
    M = np.zeros(n + 1); Qf = np.zeros(n + 1)
    for e in range(n):
        idx = [2 * e, 2 * e + 1, 2 * e + 2, 2 * e + 3]
        fe = ke @ w[idx]
        # приведённая к узлам распределённая нагрузка
        f = q[e] * le
        feq = np.array([f / 2, f * le / 12, f / 2, -f * le / 12])
        fe = fe - feq
        Qf[e] = fe[0]; M[e] = -fe[1]
        if e == n - 1:
            Qf[e + 1] = -fe[2]; M[e + 1] = fe[3]
    p_kpa = np.where(kz > 0, reac / (bp * le), 0)
    util = np.where(kz > 0, np.abs(reac) / np.where(plim < 1e11, plim, 1e12), 0)
    return dict(z=z, w=wd, M=M, Q=Qf, p=p_kpa, util=util, P=P, bp=bp, EI=EI, active=active,
                Mmax=np.abs(M).max(), Qmax=np.abs(Qf).max(), w_head=wd[0], w_tip=wd[-1],
                z_Mmax=z[np.argmax(np.abs(M))], plastic=int((~active & (kz > 0)).sum()))


def circ_section_capacity(D, nbar, dbar, cover=0.07, N=0.0):
    """Предельный момент круглого сечения (кН·м) по нелинейной деформационной модели.
    D, м; dbar — диаметр стержня, м; N — продольная сила (+ сжатие), кН."""
    R = D / 2; rs = R - cover - dbar / 2
    As1 = np.pi * dbar ** 2 / 4
    ang = np.linspace(0, 2 * np.pi, nbar, endpoint=False)
    ys = rs * np.cos(ang)
    # волокна бетона
    ny = 200
    yv = np.linspace(-R, R, ny + 1); yc = 0.5 * (yv[1:] + yv[:-1]); dy = np.diff(yv)
    bw = 2 * np.sqrt(np.maximum(R ** 2 - yc ** 2, 0))
    Ab = bw * dy
    eb2 = 0.0035; eb0 = 0.002; ebt = 0
    best = 0
    for x in np.linspace(0.05 * D, 0.95 * D, 400):
        # деформации: максимум сжатия ε = eb2 на верхней грани (y = R), нейтральная ось на y = R − x
        k = eb2 / x
        eps = k * (yc - (R - x))
        sig_b = np.where(eps > 0, np.minimum(eps / eb0 * Rb, Rb) * np.where(eps > eb0, 1.0, 1.0), 0.0)
        # двухлинейная: σ = Rb·ε/ε1 до ε1 = 0,0015 (упрощённо ε1 = Rb/Eb_red)
        e1 = 0.0015
        sig_b = np.where(eps > 0, np.where(eps < e1, Rb * eps / e1, Rb), 0.0)
        eps_s = k * (ys - (R - x))
        sig_s = np.clip(eps_s * Es, -Rs, Rs)
        Nint = (sig_b * Ab).sum() + (sig_s * As1).sum()
        if abs(Nint - N) < 0.02 * (Rb * np.pi * R ** 2):
            M = (sig_b * Ab * yc).sum() + (sig_s * As1 * ys).sum()
            best = max(best, M)
    return best


def shear_capacity(D, sw_d=0.012, sw_s=0.15, cover=0.07):
    """Q_ult ≈ Q_b + Q_sw для круглого сечения (приведение к прямоугольному b = 0,9D, h0 = 0,8D)."""
    b = 0.9 * D; h0 = 0.8 * D
    Qb = 0.5 * Rbt * b * h0 * 2.0 / 1.5   # Qb ≈ φb2·Rbt·b·h0²/c при c = 1,5h0 (оценка)
    Asw = 2 * np.pi * sw_d ** 2 / 4
    qsw = Rsw * Asw / sw_s
    Qsw = 0.75 * qsw * h0 * 1.5
    return Qb + Qsw


def analyse_frame(D, s, L, h_slide, Eh, soils_below, a=3.0, k_ax=None, Q_ax=None, shape='rect'):
    """Двухрядная рама: два ряда свай на расстоянии a, жёсткий ростверк.
    Эквивалентная схема на полосу шириной s: стержень с 2·EI, 2·пружины грунта,
    поворотная пружина головы K_θ = k_ax·a²/2 (осевая работа свай «сжатие–выдёргивание»)."""
    if k_ax is None:
        k_ax = 60000.0 * (D / 0.82)
    Kth = k_ax * a ** 2 / 2.0
    # два ствола: удваиваем EI и пружины — эквивалентно делению нагрузки на 2 на один ствол
    r = analyse(D, s, L, h_slide, Eh / 2.0, soils_below, cap_fixity=Kth / 2.0, shape=shape)
    # осевая сила в сваях от момента в голове: N = M_head / a (на полосу, на 2 сваи)
    M_head = abs(r['M'][0]) * 2.0
    N_ax = M_head / a
    r.update(dict(Kth=Kth, N_ax=N_ax, M_head_total=M_head, frame=True, a=a))
    return r
