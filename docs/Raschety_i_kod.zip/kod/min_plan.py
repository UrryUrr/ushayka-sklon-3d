# -*- coding: utf-8 -*-
"""Оценка предложения «20 винтовых свай Ø108 L = 6 м» и план первоочередных мер с минимальным бюджетом.
Выход: results/Plan_PM_2026-MOS40.pdf (записка А4 + 2 листа А2), results/Smeta_PM_2026-MOS40.xlsx, results/min_plan.json."""
import json, os, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Poly, Rectangle, Circle
from matplotlib.backends.backend_pdf import PdfPages
import pymupdf
from openpyxl import Workbook
from openpyxl.styles import Font, Border, Side

import drawings as Dw
from data import BUILDINGS, WALLS_EXIST, DECK, DRAIN_AXIS, line_xy
from design import DESIGN

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'results')
R = json.load(open(os.path.join(OUT, 'results.json'), encoding='utf-8'))
AB = json.load(open(os.path.join(OUT, 'ab_piles.json'), encoding='utf-8'))
CODE = '2026-МОС40-ПМ'
Dw.CODE = CODE
Dw.OBJ = 'Первоочередные меры на склоне у участка по ул. Мостовая, 40, п. Заварзино, г. Томск (минимальный бюджет)'
CONT = 0.10
k2 = lambda v: f'{v:.2f}'.replace('.', ',')
k3 = lambda v: f'{v:.3f}'.replace('.', ',')
f1 = lambda v: f'{v:.1f}'.replace('.', ',')
sp = lambda v: f'{v:,.0f}'.replace(',', ' ')

# ---------------------------------------------------------------- геометрия плана
DA = np.array(DRAIN_AXIS, float)


def cut_y(P, y0, y1, n=200):
    t = np.linspace(y0, y1, n); return np.c_[np.interp(t, P[:, 1], P[:, 0]), t]


COLL = cut_y(DA, 26.0, 96.0)                       # коллектор вдоль края двора
FENCE = COLL + np.array([1.3, 0.0])                # ограждение — 1,3 м ближе к склону
STRIP = np.r_[FENCE, (FENCE - np.array([10.0, 0.0]))[::-1]]  # полоса 10 м без нагрузок
plen = lambda P: float(np.hypot(*np.diff(P, axis=0).T).sum())
L_COLL, L_FENCE = plen(COLL), plen(FENCE)
OUTLET = np.array([[60.2, 72.0], [66.0, 73.0], [72.0, 74.2], [77.5, 75.3], [82.3, 76.3]])
L_OUT_PLAN = plen(OUTLET); L_OUT = L_OUT_PLAN * 1.12          # по склону (уклон 25–31°, часть пути — терраса)
N_FENCE = int(round(L_FENCE / 2.5)) + 1
N_ANCH = int(math.ceil(L_OUT / 2.8)) + 1
BENCH = [('Р1', 41.5, 78.0), ('Р2', 44.0, 39.0)]
WELLS = [('НС1', 55.9, 47.0), ('НС2', 58.0, 66.5)]
CRACK = [(49.3, 60.7), (46.6, 48.9), (53.0, 59.9), (58.6, 81.4), (61.6, 56.0)]
DOWN = [((49.3, 60.7), 60.7), ((53.0, 59.9), 58.0), ((58.6, 81.4), 81.0), ((48.6, 70.0), 70.0), ((55.6, 82.2), 84.0)]


def fence_marks(n=8):
    cum = np.r_[0, np.cumsum(np.hypot(*np.diff(FENCE, axis=0).T))]
    out = []
    for s in np.linspace(cum[-1] * 0.06, cum[-1] * 0.94, n):
        i = min(int(np.searchsorted(cum, s)), len(FENCE) - 1); out.append(FENCE[i])
    return out


MARKS = fence_marks(8)

# ---------------------------------------------------------------- смета (ориентировочно)
# (работа, ед., кол-во, подрядчик мин, макс, своими силами мин, макс, пояснение)
ROWS = [
    ('Коллектор ПНД Ø110 SN8 в траншее 0,6 м вдоль края двора (песчаное основание, засыпка, уклон к выпуску ≥ 0,01)', 'м', round(L_COLL),
     1200, 1900, 450, 700, 'собирает воду с крыш и двора до того, как она уйдёт в склон'),
    ('Дождеприёмники и ревизии на коллекторе', 'шт.', 8, 3000, 5000, 2000, 3500, 'в низких точках двора и у водостоков'),
    ('Подключение водостоков построек к коллектору', 'здание', 5, 4000, 8000, 2000, 4000, 'нежилое строение, навес, баня, гараж, пристройка'),
    ('Закрытый выпуск Ø110 по склону до реки, крепление хомутами к винтовым сваям Ø57 L = 1,5 м через 2,5–3 м', 'м', round(L_OUT),
     2000, 3500, 900, 1400, f'свай-анкеров {N_ANCH} шт.; работа на склоне — со страховкой'),
    ('Гаситель на выходе выпуска (габион 2×1×0,5 м с камнем)', 'шт.', 1, 12000, 20000, 7000, 11000, 'чтобы струя не размывала берег'),
    ('Планировка полосы вдоль края двора с уклоном от склона 2–3 %', 'м²', 350, 150, 300, 30, 80, 'ширина ≈ 5 м; вода уходит в дождеприёмники'),
    ('Демонтаж аварийной обзорной площадки (металл ≈ 8 т) с вывозом', 'компл.', 1, 150000, 350000, 150000, 350000,
     'только подрядчик со страховкой; металлолом возвращает ≈ 120–160 тыс. ₽'),
    (f'Ограждение по краю двора на винтовых сваях Ø76 L = 2,5 м (шаг 2,5 м, {N_FENCE} шт.), панели 3D-сетки h = 1,5 м, калитка у лестницы', 'м',
     round(L_FENCE), 2600, 3600, 1800, 2500, 'безопасность людей и машин; склон не удерживает'),
    ('Знаки «Опасно: оползень. Проход запрещён»', 'шт.', 5, 400, 700, 400, 700, ''),
    ('Реперы — винтовые сваи Ø108 L = 3–6 м вне зоны оползня, ствол заполнить бетоном, оголовок с маркой, защитный короб', 'шт.', 2,
     10000, 16000, 6000, 12000, 'неподвижные точки для измерений; ≥ 15 м от края двора'),
    ('Деформационные марки на ограждении и стенах (12) и маяки на трещины (10)', 'шт.', 22, 500, 900, 200, 400, ''),
    ('Наблюдательные скважины 5 м (ручное бурение, труба ПВХ Ø50 с фильтром)', 'шт.', 2, 15000, 30000, 4000, 8000, 'уровень воды у края двора'),
    ('Проверка сетей на протечки: водопровод, канализация, септик', 'компл.', 1, 10000, 30000, 3000, 8000, 'утечка у края двора опаснее дождя'),
    ('Геодезические наблюдения: нулевой цикл и 4 цикла за первый год', 'цикл', 5, 8000, 15000, 0, 3000, 'своими силами — рулеткой от реперов, грубее'),
]
tot = lambda i, j: (sum(r[2] * r[i] for r in ROWS) * (1 + CONT), sum(r[2] * r[j] for r in ROWS) * (1 + CONT))
TC, TS = tot(3, 4), tot(5, 6)
AB_COST = (20 * 9000 + 20 * 1500, 20 * 11000 + 20 * 2500)

E = R['exist']; D = R['design']
KS = ['А-А', 'Б-Б', 'В-В', 'Г-Г']
kE = {k: min(E[k]['base']['F'], E[k]['base']['Fsp']) for k in KS}
kP = {k: min(E[k]['perched']['F'], E[k]['perched']['Fsp']) for k in KS}
json.dump(dict(contractor=list(TC), self=list(TS), ab=list(AB_COST), L_coll=L_COLL, L_fence=L_FENCE, L_out=L_OUT, n_fence=N_FENCE,
               n_anch=N_ANCH), open(os.path.join(OUT, 'min_plan.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# ---------------------------------------------------------------- лист 1: план
def plan_sheet(pages):
    fig, b = Dw.sheet('План первоочередных мер. М 1:250', 1, pages)
    xl, yl = (26, 90), (22, 108)
    ax = fig.add_axes([28 / Dw.W2, 62 / Dw.H2, (xl[1] - xl[0]) * 4.0 / Dw.W2, (yl[1] - yl[0]) * 4.0 / Dw.H2])
    Dw.topo(ax, alpha=0.85); Dw.plan_frame(ax, xl, yl)
    for bd in BUILDINGS:
        P = np.array(bd['poly'] + [bd['poly'][0]]); ax.fill(P[:, 0], P[:, 1], fc='#d5d8dc', ec='#555', lw=0.6, zorder=3)
    ax.fill(STRIP[:, 0], STRIP[:, 1], fc='#f5b041', alpha=0.13, ec='none', zorder=2)
    ax.text(50.5, 30.5, 'Полоса 10 м:\nне складировать,\nне ставить технику,\nне поливать', fontsize=6, color='#9c640c', zorder=9)
    for w in WALLS_EXIST:
        P = np.array(w['pts']); ax.plot(P[:, 0], P[:, 1], color='#c0392b' if w['state'] == 'аварийное' else '#7f8c8d', lw=2.0, zorder=5)
    Dk = np.array(DECK['poly'] + [DECK['poly'][0]])
    ax.fill(Dk[:, 0], Dk[:, 1], fc='#c0392b', alpha=0.22, ec='#c0392b', lw=1.0, hatch='xx', zorder=5)
    ax.text(67.8, 51.2, 'Демонтаж\nплощадки', fontsize=6.5, ha='center', color='#7b241c', zorder=9)
    ax.text(69.5, 64.6, 'W2, W3 не разбирать\nдо капитальных работ', fontsize=5.5, ha='center', color='#7b241c', zorder=9)
    for key in KS:
        cr = E[key]['base']; x, y = line_xy(Dw.LINES[key], np.array([cr['x_in'], DESIGN[key]['edge']]))
        ax.plot(x, y, color='#e74c3c', lw=5, alpha=0.18, solid_capstyle='butt', zorder=4); ax.plot(x[0], y[0], 's', color='#e74c3c', ms=4, zorder=7)
    ax.plot(COLL[:, 0], COLL[:, 1], color='#1f618d', lw=1.6, ls=(0, (6, 2)), zorder=7)
    ax.plot(OUTLET[:, 0], OUTLET[:, 1], color='#1f618d', lw=1.8, zorder=7)
    for t in np.linspace(0, 1, N_ANCH):
        i = t * (len(OUTLET) - 1); j = min(int(i), len(OUTLET) - 2); p = OUTLET[j] + (i - j) * (OUTLET[j + 1] - OUTLET[j])
        ax.plot(*p, 'o', color='#1f618d', ms=2.4, zorder=8)
    ax.add_patch(Rectangle((82.3, 75.8), 2.0, 1.0, angle=12, fc='#95a5a6', ec='k', lw=0.6, zorder=8))
    ax.text(84.6, 78.0, 'Гаситель', fontsize=6, zorder=9)
    ax.annotate('Выпуск Ø110\nпо склону', xy=(71, 74.0), xytext=(70, 80.5), fontsize=6, color='#1f4e79', zorder=9,
                arrowprops=dict(arrowstyle='-', lw=0.5, color='#1f4e79'))
    ax.text(52.6, 93.0, 'Коллектор Ø110\n(i ≥ 0,01 к выпуску)', fontsize=6, color='#1f4e79', zorder=9)
    for (p, yy) in DOWN:
        q = (float(np.interp(yy, COLL[:, 1], COLL[:, 0])), yy)
        ax.annotate('', xy=q, xytext=p, arrowprops=dict(arrowstyle='-|>', lw=0.7, color='#2874a6'), zorder=8)
    ax.plot(FENCE[:, 0], FENCE[:, 1], color='k', lw=1.1, zorder=7)
    cum = np.r_[0, np.cumsum(np.hypot(*np.diff(FENCE, axis=0).T))]
    for s in np.arange(0, cum[-1] + 0.01, 2.5):
        i = min(int(np.searchsorted(cum, s)), len(FENCE) - 1); ax.plot(*FENCE[i], 'k|', ms=4, mew=0.8, zorder=8)
    ax.text(FENCE[-1, 0] + 0.8, FENCE[-1, 1] - 1, 'калитка\nк лестнице', fontsize=5.5, zorder=9)
    ax.text(62.2, 37.5, 'Ограждение на\nвинтовых сваях\nØ76 L=2,5 м, шаг 2,5 м', fontsize=6, zorder=9)
    for i, p in enumerate(MARKS):
        ax.plot(*p, '^', color='#7d3c98', ms=5, zorder=9); ax.text(p[0] + 0.7, p[1] + 0.4, f'М{i + 1}', fontsize=5.5, color='#7d3c98', zorder=9)
    for p in CRACK:
        ax.plot(*p, 'D', mfc='white', mec='#7d3c98', ms=4, zorder=9)
    for nm, x, y in WELLS:
        ax.plot(x, y, 'o', mfc='#aed6f1', mec='#1f618d', ms=6, zorder=9); ax.text(x - 4.2, y - 0.4, nm, fontsize=6, color='#1f4e79', zorder=9)
    for nm, x, y in BENCH:
        ax.plot(x, y, marker='s', mfc='k', mec='k', ms=6, zorder=9); ax.plot(x, y, marker='+', color='white', ms=5, zorder=10)
        ax.text(x + 1.0, y + 0.6, f'{nm} (репер)', fontsize=6.5, zorder=9)
    Dw.north(ax, 88, 98)
    # легенда и указания
    tx, ty = 300, 395
    b.text(tx, ty, 'Условные обозначения', fontsize=10); y = ty - 9
    def L_line(y, **k): b.plot([tx, tx + 14], [y, y], **k)
    def L_mark(y, **k): b.plot([tx + 7], [y], **k)
    def L_box(y, **k): b.add_patch(Rectangle((tx + 2, y - 2), 10, 4, **k))
    leg = [(lambda y: L_line(y, color='#1f618d', lw=1.6, ls=(0, (6, 2))), 'коллектор ПНД Ø110 в траншее 0,6 м'),
           (lambda y: (L_line(y, color='#1f618d', lw=1.8), b.plot([tx + 4, tx + 10], [y, y], 'o', color='#1f618d', ms=2.4)), f'закрытый выпуск по склону, точки — сваи-анкеры Ø57 ({N_ANCH} шт.)'),
           (lambda y: b.annotate('', xy=(tx + 14, y), xytext=(tx, y), arrowprops=dict(arrowstyle='-|>', lw=0.7, color='#2874a6')), 'подключение водостоков'),
           (lambda y: (L_line(y, color='k', lw=1.1), b.plot([tx + 2, tx + 7, tx + 12], [y] * 3, 'k|', ms=5, mew=0.8)), f'ограждение на винтовых сваях Ø76 ({N_FENCE} шт.)'),
           (lambda y: L_mark(y, marker='^', color='#7d3c98', ms=5, ls='none'), 'деформационные марки М1–М8 (ещё 4 — на стенах построек)'),
           (lambda y: L_mark(y, marker='D', mfc='white', mec='#7d3c98', ms=4, ls='none'), 'маяки на трещины построек и стены W1'),
           (lambda y: L_mark(y, marker='o', mfc='#aed6f1', mec='#1f618d', ms=6, ls='none'), 'наблюдательные скважины НС1, НС2 глубиной 5 м'),
           (lambda y: L_mark(y, marker='s', mfc='k', mec='k', ms=6, ls='none'), 'реперы Р1, Р2 — винтовые сваи Ø108'),
           (lambda y: (L_line(y, color='#e74c3c', lw=5, alpha=0.18), L_mark(y, marker='s', color='#e74c3c', ms=4, ls='none')), 'вход расчётной поверхности скольжения (сущ.)'),
           (lambda y: L_box(y, fc='#c0392b', alpha=0.22, ec='#c0392b', hatch='xx'), 'демонтаж аварийной обзорной площадки'),
           (lambda y: L_box(y, fc='#f5b041', alpha=0.2, ec='none'), 'полоса 10 м без нагрузок')]
    for draw, txt in leg:
        draw(y); b.text(tx + 20, y, txt, fontsize=7.2, va='center'); y -= 7.0
    y -= 6
    b.text(tx, y, 'Указания', fontsize=10); y -= 8
    notes = ['1. Первоочередные меры снижают приток воды в склон и дают раннее предупреждение о смещениях.',
             '    Склон они не удерживают: запас устойчивости остаётся ниже нормы 1,15 (см. записку, раздел 5).',
             '2. Тяжёлую технику ближе 10 м к краю двора не ставить; сваи завинчивать ручным или лёгким сваекрутом.',
             '3. Стены W2, W3 (аварийные) не разбирать до капитальных работ — под ними закрыть доступ.',
             '4. Выпуск и демонтаж площадки — на неразграниченных землях: до работ уведомить администрацию.',
             '5. Реперы ставить не ближе 15 м от края двора — вне зоны возможного сдвига (вход поверхностей 6,6–9,9 м).',
             '6. Положение коллектора, выпуска и реперов уточнить по месту с учётом сетей и покрытий.',
             '7. Пороги наблюдений и порядок действий — в записке, раздел 7.']
    for s in notes:
        b.text(tx, y, s, fontsize=7.2); y -= 5.6
    Dw.pages_add(fig)


# ---------------------------------------------------------------- лист 2: разрез А-А и узлы
def section_sheet(pages):
    fig, b = Dw.sheet('Разрез А-А: сваи Ø108 L=6 м и поверхность скольжения. Узлы', 2, pages)
    xl, yl = (8.0, 62.0), (91.0, 113.0)
    ax = fig.add_axes([30 / Dw.W2, 222 / Dw.H2, (xl[1] - xl[0]) * 6.667 / Dw.W2, (yl[1] - yl[0]) * 6.667 / Dw.H2])
    cr = E['А-А']['base']
    Dw.draw_profile(ax, 'А-А', 'exist', [(cr, '#c0392b', f"k = {k2(kE['А-А'])}")], xl, yl)
    xe, zg, zs = 31.9, AB['А-А']['z_ground'], AB['А-А']['z_slip_at_edge']
    xp = xe - 1.2
    ax.add_patch(Rectangle((xp - 0.12, zg - 6.0), 0.24, 6.0, fc='#2c3e50', ec='k', lw=0.4, zorder=12))
    ax.plot([xp - 0.35, xp + 0.35], [zg - 5.7, zg - 5.7], color='#2c3e50', lw=2.0, zorder=12)
    ax.annotate('', xy=(xp + 1.4, zs), xytext=(xp + 1.4, zg - 6.0), arrowprops=dict(arrowstyle='<->', lw=0.8, color='#c0392b'), zorder=12)
    ax.text(xp + 1.8, zg - 7.1, f'{f1(zg - 6.0 - zs)} м\nне доходит', fontsize=7, color='#c0392b', zorder=12)
    ax.annotate('Свая Ø108 L = 6 м\n(предложение)', xy=(xp, zg - 3), xytext=(xp - 13, zg - 1.0), fontsize=7.5, zorder=12,
                arrowprops=dict(arrowstyle='-', lw=0.6))
    ax.plot([xe - 3.0, xe - 3.0], [zg, zg - 0.6], color='#1f618d', lw=3.5, zorder=12)
    ax.text(xe - 3.2, zg + 0.8, 'коллектор', fontsize=6.5, ha='right', color='#1f4e79', zorder=12)
    ax.text(xe - 1.0, zg + 1.9, 'ограждение', fontsize=6.5, ha='center', zorder=12)
    ax.plot([xe - 1.2, xe - 1.2], [zg, zg + 1.5], 'k-', lw=1.2, zorder=12)
    b.text(30, 392, f'Разрез А-А. М 1:150. Поверхность скольжения под краем двора — на глубине {f1(zg - zs)} м (отм. {zs:.2f}); '
                    f'свая L = 6 м заканчивается выше неё и смещается вместе с грунтом.', fontsize=8.5)
    # таблица результатов
    tx, ty = 410, 375
    b.text(tx, ty, 'Расчёт (Бишоп, критическая поверхность\nсуществующего положения)', fontsize=9.5, va='top'); y = ty - 16
    hdr = ['Разрез', 'k сейчас', '20 свай L=6 м', 'если бы L=12 м', 'нужно, кН/м']
    xs_ = [0, 22, 44, 76, 108]
    for x_, h in zip(xs_, hdr):
        b.text(tx + x_, y, h, fontsize=7.2, weight='bold')
    y -= 6.5
    for key in ('А-А', 'Б-Б', 'В-В'):
        a = AB[key]
        for x_, v in zip(xs_, [key, k3(a['F0']), k3(a['АВ: L=6 м, 20 шт на 40 м']), k3(a['если бы L=12 м']), sp(a['H_needed_kN_per_m'])]):
            b.text(tx + x_, y, v, fontsize=7.2)
        y -= 6
    b.text(tx, y - 4, 'Одна свая Ø108×4 передаёт ≈ 10–15 кН (изгиб ствола,\nM ≈ 8–10 кН·м); 20 свай на 40 м — 5–8 кН/м.\n'
                      'Для нормы 1,15 у края двора нужно 190–265 кН/м:\n13–26 таких свай на каждый метр — невыполнимо.', fontsize=7.2, va='top')
    # узлы
    def frame(x, y, w, h, title):
        a = fig.add_axes([x / Dw.W2, y / Dw.H2, w / Dw.W2, h / Dw.H2]); a.set_aspect('equal'); a.axis('off')
        b.text(x, y + h + 4, title, fontsize=8.5); return a
    a1 = frame(30, 72, 70, 120, 'Узел 1. Ограждение на винтовой свае')
    a1.set_xlim(-1.2, 1.6); a1.set_ylim(-2.9, 1.9)
    a1.fill_between([-1.2, 1.6], -2.9, 0, color='#ead8b5', hatch='///', ec='#a08060', lw=0)
    a1.add_patch(Rectangle((-0.04, -2.5), 0.08, 2.5 + 1.6, fc='#566573', ec='k', lw=0.5))
    a1.plot([-0.15, 0.15], [-2.3, -2.3], 'k-', lw=2.5)
    a1.add_patch(Rectangle((0.06, 0.05), 1.3, 1.45, fc='none', ec='k', lw=0.6, hatch='++'))
    a1.text(-1.1, 1.75, 'панель 3D-сетки h = 1,5 м', fontsize=6.5); a1.text(0.2, -1.2, 'свая Ø76\nL = 2,5 м\nшаг 2,5 м', fontsize=6.5)
    a1.text(-1.1, -2.75, 'лопасть Ø250', fontsize=6.5)
    a2 = frame(125, 132, 80, 60, 'Узел 2. Траншея коллектора')
    a2.set_xlim(-0.8, 0.8); a2.set_ylim(-0.9, 0.3)
    a2.fill_between([-0.8, 0.8], -0.9, 0, color='#ead8b5', hatch='///', ec='#a08060', lw=0)
    a2.add_patch(Poly([(-0.3, 0), (0.3, 0), (0.25, -0.7), (-0.25, -0.7)], fc='#fdebd0', ec='k', lw=0.6))
    a2.add_patch(Rectangle((-0.25, -0.7), 0.5, 0.1, fc='#f9e79f', ec='k', lw=0.4)); a2.add_patch(Circle((0, -0.53), 0.055, fc='#5dade2', ec='k', lw=0.6))
    a2.text(0.33, -0.1, 'засыпка местным\nгрунтом', fontsize=6); a2.text(0.33, -0.6, 'ПНД Ø110 на\nпеске 0,1 м', fontsize=6)
    a2.text(-0.78, 0.15, '0,6 м', fontsize=6)
    a3 = frame(125, 72, 80, 45, 'Узел 3. Крепление выпуска к склону')
    a3.set_xlim(-0.2, 3.4); a3.set_ylim(-1.5, 0.9)
    gx = np.array([-0.2, 3.4]); a3.fill_between(gx, -1.5, -0.55 * gx, color='#ead8b5', hatch='///', ec='#a08060', lw=0)
    a3.plot(gx, -0.55 * gx + 0.12, color='#2e86c1', lw=3)
    for xx in (0.4, 2.9):
        a3.plot([xx, xx], [-0.55 * xx + 0.2, -0.55 * xx - 1.2], color='#566573', lw=1.6)
    a3.text(0.5, 0.45, 'ПНД Ø110 на поверхности, хомут\nк свае Ø57 L = 1,5 м через 2,5–3 м', fontsize=6)
    a4 = frame(230, 72, 60, 120, 'Узел 4. Репер')
    a4.set_xlim(-1.0, 1.4); a4.set_ylim(-3.4, 0.9)
    a4.fill_between([-1, 1.4], -3.4, 0, color='#ead8b5', hatch='///', ec='#a08060', lw=0)
    a4.add_patch(Rectangle((-0.06, -3.1), 0.12, 3.25, fc='#566573', ec='k', lw=0.5))
    a4.add_patch(Rectangle((-0.35, -0.25), 0.7, 0.55, fc='none', ec='k', lw=0.6))
    a4.text(0.42, -0.05, 'короб с\nкрышкой', fontsize=6); a4.text(0.2, -1.9, 'свая Ø108\nL = 3–6 м,\nствол\nзабетонировать', fontsize=6)
    a4.text(-0.95, 0.6, '≥ 15 м от края двора', fontsize=6)
    Dw.pages_add(fig)


# ---------------------------------------------------------------- рисунок для записки
def fig_section(path):
    fig = plt.figure(figsize=(170 / 25.4, 88 / 25.4))
    ax = fig.add_axes([0.07, 0.06, 0.92, 0.9])
    cr = E['А-А']['base']; xl, yl = (10.0, 68.0), (92.0, 115.0)
    Dw.draw_profile(ax, 'А-А', 'exist', [(cr, '#c0392b', 'поверхность скольжения, k = ' + k2(kE['А-А']))], xl, yl)
    xe, zg, zs = 31.9, AB['А-А']['z_ground'], AB['А-А']['z_slip_at_edge']; xp = xe - 1.2
    ax.add_patch(Rectangle((xp - 0.15, zg - 6.0), 0.3, 6.0, fc='#2c3e50', ec='k', lw=0.4, zorder=12))
    ax.annotate('', xy=(xp + 1.6, zs), xytext=(xp + 1.6, zg - 6.0), arrowprops=dict(arrowstyle='<->', lw=0.9, color='#c0392b'), zorder=12)
    ax.text(xp + 2.1, zg - 7.3, f'{f1(zg - 6.0 - zs)} м', fontsize=8, color='#c0392b', zorder=12)
    ax.annotate('свая Ø108 L = 6 м (предложение)', xy=(xp, zg - 0.8), xytext=(xp - 17, 113.3), fontsize=8, zorder=12, arrowprops=dict(arrowstyle='-', lw=0.6))
    fig.savefig(path, dpi=220); plt.close(fig)


# ---------------------------------------------------------------- записка
def doc_html():
    a = AB['А-А']
    rows_tab = ''.join(f'<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td><td>{sp(r[2] * r[3])}–{sp(r[2] * r[4])}</td>'
                       f'<td>{sp(r[2] * r[5])}–{sp(r[2] * r[6])}</td><td>{r[7]}</td></tr>' for r in ROWS)
    m = lambda v: f'{v / 1e6:.2f}'.replace('.', ',')
    H = f'''
<p class="tt1">ВИНТОВЫЕ СВАИ ДЛЯ УКРЕПЛЕНИЯ СКЛОНА:<br/>ОЦЕНКА ПРЕДЛОЖЕНИЯ И ПЛАН ПЕРВООЧЕРЕДНЫХ МЕР</p>
<p class="tt2">Склон левого берега р. Ушайки у участка по ул. Мостовая, 40, п. Заварзино · шифр {CODE} · октябрь 2026 г.</p>
<p class="notice"><b>Статус.</b> Расчёты выполнены той же моделью, что и в пояснительной записке 2026-МОС40-ИЗ-ПЗ (разрезы А-А, Б-Б, В-В).
Первоочередные меры не делают склон устойчивым: они уменьшают приток воды и дают раннее предупреждение о смещениях.
Работы за границей участка — после уведомления администрации. Стоимость ориентировочная, по открытым ценам 2025–2026 гг.</p>

<h1>1. Предложение</h1>
<p>Купить винтовые сваи диаметром 108 мм длиной 6 м и установить около 20 штук для сохранения склона; для завинчивания —
сваекрут. Ориентировочная стоимость: сваи Ø108 длиной 6 м под заказ ≈ 9–11 тыс. ₽ за штуку (в наличии у продавца — длиной 3 м,
≈ 4,9 тыс. ₽), установка ≈ 1,5–2,5 тыс. ₽ за штуку; всего ≈ {m(AB_COST[0])}–{m(AB_COST[1])} млн ₽ без учёта инструмента.</p>

<h1>2. Вывод</h1>
<p><b>Для удержания склона предложение не подходит.</b> Сваи длиной 6 м заканчиваются выше поверхности скольжения и смещаются
вместе с грунтом; запас устойчивости не меняется ({k3(a['F0'])} → {k3(a['АВ: L=6 м, 20 шт на 40 м'])} по разрезу А-А). Даже если бы сваи
доставали ниже поверхности скольжения, 20 свай дали бы около 2–4 % нужной удерживающей силы. Винтовые сваи полезны на этом участке
для другого: ограждения, крепления водоотводной трубы и реперов для наблюдений. На них и построен скорректированный план (разделы 4–8).</p>

<h1>3. Обоснование</h1>
<p><img src="fig_ab.png" width="100%"/></p>
<p class="cap">Рисунок 1 — Разрез А-А: свая Ø108 длиной 6 м у края двора и расчётная поверхность скольжения</p>
<table><tr><th>Показатель</th><th>А-А</th><th>Б-Б</th><th>В-В</th><th>Что это значит</th></tr>
<tr><td>Глубина поверхности скольжения под краем двора, м</td><td>{f1(AB['А-А']['depth'])}</td><td>{f1(AB['Б-Б']['depth'])}</td><td>{f1(AB['В-В']['depth'])}</td>
<td>свая 6 м не доходит на 2–3 м; под склоном поверхность ещё глубже — до 13–14 м ниже двора</td></tr>
<tr><td>Запас устойчивости сейчас (норма 1,15)</td><td>{k3(AB['А-А']['F0'])}</td><td>{k3(AB['Б-Б']['F0'])}</td><td>{k3(AB['В-В']['F0'])}</td><td>склон в аварийном состоянии</td></tr>
<tr><td>С 20 сваями L = 6 м</td><td>{k3(AB['А-А']['АВ: L=6 м, 20 шт на 40 м'])}</td><td>{k3(AB['Б-Б']['АВ: L=6 м, 20 шт на 40 м'])}</td><td>{k3(AB['В-В']['АВ: L=6 м, 20 шт на 40 м'])}</td><td>без изменений</td></tr>
<tr><td>Если бы сваи были L = 12 м</td><td>{k3(AB['А-А']['если бы L=12 м'])}</td><td>{k3(AB['Б-Б']['если бы L=12 м'])}</td><td>{k3(AB['В-В']['если бы L=12 м'])}</td><td>+0,006 — в пределах точности расчёта</td></tr>
<tr><td>Нужна удерживающая сила у края двора для нормы, кН на 1 м</td><td>{sp(AB['А-А']['H_needed_kN_per_m'])}</td><td>{sp(AB['Б-Б']['H_needed_kN_per_m'])}</td><td>{sp(AB['В-В']['H_needed_kN_per_m'])}</td>
<td>≈ 19–27 т на каждый метр края двора</td></tr></table>
<p>Свая Ø108 со стенкой 4 мм — тонкая стальная труба: момент сопротивления ≈ 33 см³, предельный изгибающий момент ≈ 8–10 кН·м.
Поперечное усилие, которое такая свая может передать через поверхность скольжения, — около 10–15 кН. Двадцать свай на 40 м края двора
дают 5–8 кН на метр при нужных 190–265 кН/м: потребовалось бы 13–26 свай на каждый метр, то есть сплошная стена из труб.
Такие усилия воспринимают только массивные конструкции: грунтоцементные рёбра Ø1,0 м или буронабивные сваи Ø0,8–1,2 м
(варианты 2, 3 и 6 пояснительной записки). Кроме того, лопасти винтовых свай плохо работают в мягких и текучих суглинках и супесях этого склона.</p>

<h1>4. Что даёт эффект при малом бюджете</h1>
<p>Главная причина весенних подвижек — вода: верховодка в суглинках снижает запас с {k2(min(kE.values()))}–{k2(max(kE.values()))} до
{k2(min(kP.values()))}–{k2(max(kP.values()))}. Вода с крыш и двора, утечки из сетей и полив уходят прямо в склон. Поэтому первые деньги —
на отвод воды, разгрузку края двора и наблюдения: они недорогие, не требуют тяжёлой техники и нужны при любом дальнейшем решении.</p>

<h1>5. Скорректированный план</h1>
<table><tr><th>Мера</th><th>Зачем</th><th>Как</th></tr>
<tr><td>Отвод воды с крыш и двора</td><td>убрать главный источник верховодки</td><td>коллектор ПНД Ø110 в траншее 0,6 м вдоль края двора ({round(L_COLL)} м),
8 дождеприёмников, подключение водостоков 5 построек; закрытый выпуск по склону до реки ({round(L_OUT)} м) на винтовых сваях-анкерах Ø57; гаситель у воды</td></tr>
<tr><td>Планировка края двора</td><td>вода не должна стоять у края</td><td>уклон 2–3 % от склона в полосе ≈ 5 м к дождеприёмникам</td></tr>
<tr><td>Проверка сетей</td><td>утечка у края двора опаснее дождя</td><td>опрессовка водопровода, проверка канализации и септика; найденные утечки устранить</td></tr>
<tr><td>Разгрузка</td><td>не добавлять вес на верх склона</td><td>демонтаж аварийной обзорной площадки (≈ 8 т металла); в полосе 10 м — ничего не складировать, не ставить технику, не поливать</td></tr>
<tr><td>Ограждение</td><td>безопасность людей и машин</td><td>{round(L_FENCE)} м на винтовых сваях Ø76 L = 2,5 м ({N_FENCE} шт.), панели 3D-сетки 1,5 м, калитка к лестнице, знаки</td></tr>
<tr><td>Наблюдения</td><td>заметить ускорение смещений заранее</td><td>2 репера — винтовые сваи Ø108 не ближе 15 м от края двора; 12 марок, 10 маяков на трещины,
2 наблюдательные скважины 5 м; замеры по графику раздела 7</td></tr>
<tr><td>Без изменений</td><td>не ухудшить</td><td>аварийные стены W2, W3 не разбирать до капитальных работ — без них склон станет менее устойчивым; под ними закрыть доступ</td></tr></table>
<p>Если сваи Ø108 длиной 6 м уже куплены, две из них — реперы; остальные можно использовать в ограждении, завинтив на 3–4 м.
Для ограждения достаточно свай Ø76 длиной 2,5 м: они в 3–4 раза дешевле.</p>

<h1>6. Что это даст</h1>
<p>Отвод воды не даёт запасу опускаться весной: ориентировочно он остаётся на уровне {k2(min(kE.values()))}–{k2(max(kE.values()))}
вместо {k2(min(kP.values()))}–{k2(max(kP.values()))}. Это заметно снижает вероятность весенней активизации, но не выводит склон на норму 1,15:
он остаётся в аварийном состоянии. Наблюдения дают время принять меры: перед крупной подвижкой смещения, как правило, заранее ускоряются.
Данные скважин и марок нужны и для доизысканий: по ним уточнят, сколько удерживающих сооружений действительно нужно.</p>

<h1>7. Наблюдения и пороги</h1>
<table><tr><th>Что</th><th>Когда</th><th>Порог — действие</th></tr>
<tr><td>Марки М1–М8 и на стенах: смещение от реперов Р1, Р2 (рулетка, лазерный дальномер, нивелир)</td><td>раз в месяц; в апреле–мае и после ливней — раз в неделю</td>
<td>≥ 5 мм за месяц или ≥ 10 мм от начала — вызвать инженера, полосу 10 м закрыть; ≥ 20 мм за месяц — вывести людей из ближайших построек</td></tr>
<tr><td>Маяки на трещинах построек и стены W1</td><td>одновременно с марками</td><td>маяк лопнул или трещина раскрылась на ≥ 2 мм — инженеру</td></tr>
<tr><td>Уровень воды в НС1, НС2</td><td>раз в 2 недели; весной — раз в неделю</td><td>вода выше 2 м от поверхности — проверить коллектор и сети, усилить наблюдения</td></tr>
<tr><td>Осмотр края двора и склона</td><td>после каждого ливня и оттепели</td><td>новые трещины в грунте, «пьяный» лес, выход воды на склоне — инженеру</td></tr></table>
<p>Пороги ориентировочные; после первых месяцев наблюдений их уточняет инженер.</p>

<h1>8. Стоимость (ориентировочно)</h1>
<table class="small"><tr><th>Работа</th><th>Ед.</th><th>Кол-во</th><th>Подрядчик, ₽</th><th>Своими силами, ₽</th><th>Пояснение</th></tr>
{rows_tab}
<tr><td><b>Итого с непредвиденными {round(CONT * 100)} %</b></td><td></td><td></td><td><b>{m(TC[0])}–{m(TC[1])} млн</b></td><td><b>{m(TS[0])}–{m(TS[1])} млн</b></td>
<td>демонтаж площадки — подрядчиком в обоих случаях</td></tr></table>
<p>Для сравнения: предложение с 20 сваями Ø108 L = 6 м — ≈ {m(AB_COST[0])}–{m(AB_COST[1])} млн ₽ без влияния на устойчивость.
План первоочередных мер стоит {m(TC[0])}–{m(TC[1])} млн ₽ с подрядчиком ({m(TS[0])}–{m(TS[1])} млн ₽ при работе своими силами) и даёт
измеримый эффект. Срок — 2–4 недели, лучше до промерзания грунта или сразу после оттаивания.</p>

<h1>9. Что дальше</h1>
<p>1) Выполнить первоочередные меры и начать наблюдения. 2) Уведомить администрацию: склон на неразграниченных землях, а оползень угрожает
и соседним участкам — защита берега может войти в муниципальную программу. 3) Через год наблюдений и после доизысканий
(скважины 25–30 м, испытания грунтов) — решение о капитальной защите по пояснительной записке 2026-МОС40-ИЗ-ПЗ.</p>
<p>Чертежи: лист 1 — план первоочередных мер; лист 2 — разрез А-А со сваями Ø108 и поверхностью скольжения, узлы ограждения, коллектора,
крепления выпуска и репера.</p>
'''
    return H


CSS = '''
@font-face {font-family: tnr; src: url(times.ttf);} @font-face {font-family: tnr; src: url(timesbd.ttf); font-weight: bold;}
@font-face {font-family: ar; src: url(arial.ttf);} @font-face {font-family: ar; src: url(arialbd.ttf); font-weight: bold;}
body {font-family: tnr; font-size: 11.5pt; line-height: 1.32; text-align: justify;}
h1 {font-family: ar; font-size: 13pt; font-weight: bold; margin-top: 10pt; margin-bottom: 6pt; color: #12313b;}
p {margin-top: 0; margin-bottom: 5pt;}
table {border-collapse: collapse; width: 100%; margin-bottom: 8pt;}
td, th {border: 0.5px solid #555; padding: 2pt 3pt; font-family: ar; font-size: 8.3pt; vertical-align: top; text-align: left;}
table.small td, table.small th {font-size: 7.2pt;}
th {font-weight: bold; color: #12313b; border-bottom: 1.2px solid #12313b;}
.cap {font-family: ar; font-size: 9pt; text-align: center; margin-bottom: 8pt;}
.tt1 {font-family: ar; font-size: 15pt; font-weight: bold; text-align: center; margin-top: 6pt; margin-bottom: 8pt; color: #12313b;}
.tt2 {font-family: ar; font-size: 10pt; text-align: center; margin-bottom: 6pt;}
.notice {font-family: ar; font-size: 9pt; border: 1px solid #12313b; padding: 6pt; margin-top: 6pt; margin-bottom: 8pt; text-align: left;}
'''


def build():
    imgdir = os.path.join(OUT, 'pm_img'); os.makedirs(imgdir, exist_ok=True)
    fig_section(os.path.join(imgdir, 'fig_ab.png'))
    pages = []; plan_sheet(pages); section_sheet(pages)
    for t in pages:
        t.set_text('2')
    shp = os.path.join(OUT, 'pm_sheets.pdf')
    with PdfPages(shp) as pdf:
        for i, f in enumerate(Dw.SHEETS):
            pdf.savefig(f); f.savefig(os.path.join(OUT, f'pm_sheet_{i + 1}.png'), dpi=70); plt.close(f)
    arch = pymupdf.Archive('C:/Windows/Fonts'); arch.add(imgdir)
    raw = os.path.join(OUT, 'pm_raw.pdf'); wr = pymupdf.DocumentWriter(raw)
    rect = pymupdf.paper_rect('a4'); where = rect + (57, 50, -34, -50)
    story = pymupdf.Story(html=doc_html(), user_css=CSS, archive=arch); more = 1
    while more:
        dev = wr.begin_page(rect); more, _ = story.place(where); story.draw(dev); wr.end_page()
    wr.close()
    doc = pymupdf.open(raw); fnt = pymupdf.Font(fontfile='C:/Windows/Fonts/arial.ttf')
    for i, pg in enumerate(doc):
        pg.wrap_contents(); tw = pymupdf.TextWriter(pg.rect)
        tw.append((57, 30), f'{CODE}   Первоочередные меры · ул. Мостовая, 40, п. Заварзино', font=fnt, fontsize=7.5)
        tw.append((pg.rect.width - 70, pg.rect.height - 25), f'Лист {i + 1}', font=fnt, fontsize=8)
        tw.write_text(pg, color=(0.3, 0.3, 0.3)); pg.draw_line((57, 36), (pg.rect.width - 34, 36), color=(0.6, 0.6, 0.6), width=0.4)
    n_text = doc.page_count
    doc.insert_pdf(pymupdf.open(shp))
    doc.set_metadata({'title': 'Винтовые сваи: оценка предложения и план первоочередных мер — ул. Мостовая, 40', 'author': '', 'creator': '', 'producer': ''})
    final = os.path.join(OUT, 'Plan_PM_2026-MOS40.pdf')
    doc.subset_fonts(); doc.save(final, garbage=3, deflate=True); doc.close()
    for p in (raw, shp):
        try:
            os.remove(p)
        except OSError:
            pass
    # смета XLSX
    wb = Workbook(); ws = wb.active; ws.title = 'Первоочередные меры'
    ws.append([f'Первоочередные меры, ориентировочная стоимость (руб., без НДС), шифр {CODE}']); ws.append([])
    ws.append(['№', 'Работа', 'Ед.', 'Кол-во', 'Подрядчик мин', 'Подрядчик макс', 'Своими силами мин', 'Своими силами макс', 'Пояснение'])
    for i, r in enumerate(ROWS, 1):
        ws.append([i, r[0], r[1], r[2], r[2] * r[3], r[2] * r[4], r[2] * r[5], r[2] * r[6], r[7]])
    ws.append([]); ws.append(['', f'Итого с непредвиденными {round(CONT * 100)} %', '', '', round(TC[0]), round(TC[1]), round(TS[0]), round(TS[1]), ''])
    for row in ws.iter_rows(min_row=4):
        for c in row[4:8]:
            c.number_format = '#,##0'
    for col, w in zip('ABCDEFGHI', [4, 80, 8, 8, 14, 14, 16, 16, 50]):
        ws.column_dimensions[col].width = w
    ws['A1'].font = Font(bold=True, size=12)
    wb.save(os.path.join(OUT, 'Smeta_PM_2026-MOS40.xlsx'))
    print('записка', n_text, 'стр. + 2 листа; подрядчик', round(TC[0] / 1e6, 2), '–', round(TC[1] / 1e6, 2), 'млн; сами', round(TS[0] / 1e6, 2), '–', round(TS[1] / 1e6, 2))


if __name__ == '__main__':
    build()
