# -*- coding: utf-8 -*-
"""3D-модель: ЦМР (сущ./проект), здания, сооружения, ГЦК, габионы, крепления, дренаж, мониторинг,
геологические разрезы и тело оползня. Экспорт: scene.json (для веб-вьюера) и OBJ/MTL."""
import json, math, os, base64
import numpy as np
from scipy.interpolate import RegularGridInterpolator
import data
from data import (BUILDINGS, WALLS_EXIST, GABION_EXIST, DECK, WL_LOW, WL_FLOOD, RIVER_BED, line_xy,
                  LINE_AA, LINE_BB, LINE_VV, LINE_GG, BOREHOLES, SOILS)
import dem
from design import DESIGN, JET

HERE = os.path.dirname(os.path.abspath(__file__))
RES = json.load(open(os.path.join(HERE, 'results', 'results.json'), encoding='utf-8'))
LINES = {'А-А': LINE_AA, 'Б-Б': LINE_BB, 'В-В': LINE_VV, 'Г-Г': LINE_GG}

# ---------------------------------------------------------------- ЦМР
d = np.load(os.path.join(HERE, 'dem_exist.npz'))
GX, GY = dem.GX, dem.GY
ZE = d['Z']
fE = RegularGridInterpolator((GY, GX), ZE, bounds_error=False, fill_value=None)


def zE(x, y):
    return fE(np.c_[np.atleast_1d(y), np.atleast_1d(x)])


# ось бермы (с юга на север) — по центрам берм в расчётных сечениях
def bench_center_xy(key):
    b0, b1, _ = DESIGN[key]['bench']
    return line_xy(LINES[key], 0.5 * (b0 + b1))


AXIS = [(80.6, 6.0)] + [tuple(map(float, bench_center_xy('В-В')))] + [(70.6, 41.0)] + \
       [tuple(map(float, bench_center_xy('А-А')))] + [(69.6, 64.0)] + [tuple(map(float, bench_center_xy('Г-Г')))] + \
       [tuple(map(float, bench_center_xy('Б-Б')))] + [(80.8, 94.0), (82.6, 104.0)]
AXIS = np.array(AXIS)


def axis_frame(P):
    """станция s и смещение n (+ к реке) точки P относительно оси бермы"""
    best = None
    s_acc = 0.0
    for i in range(len(AXIS) - 1):
        A, B = AXIS[i], AXIS[i + 1]
        v = B - A; L = np.hypot(*v); t = np.clip(np.dot(P - A, v) / L ** 2, 0, 1)
        Q = A + t * v; dist = np.hypot(*(P - Q))
        nrm = np.array([v[1], -v[0]]) / L          # нормаль вправо по ходу (с юга на север → на восток)
        n = float(np.dot(P - Q, nrm))
        if best is None or dist < best[0]:
            best = (dist, s_acc + t * L, n)
        s_acc += L
    return best[1], best[2]


AXIS_LEN = float(np.sum(np.hypot(*np.diff(AXIS, axis=0).T)))
SEC_S = {}
for key in DESIGN:
    bx, by = bench_center_xy(key)
    SEC_S[key] = axis_frame(np.array([bx, by]))[0]
ORDER = sorted(DESIGN, key=lambda k: SEC_S[k])


def sec_profiles(key):
    """профили сечения в координате n (смещение от центра бермы по линии сечения)"""
    dd = DESIGN[key]
    pc = 0.5 * (dd['bench'][0] + dd['bench'][1])
    ds = np.array(dd['surf']); es = np.array(dd['exist_surf'])
    return dict(nc=dd['crest'] - pc - 0.6, ne=dd['edge'] - pc, des=np.c_[ds[:, 0] - pc, ds[:, 1]],
                ex=np.c_[es[:, 0] - pc, es[:, 1]])


PROF = {k: sec_profiles(k) for k in DESIGN}


def z_design_point(x, y, z_exist):
    s, n = axis_frame(np.array([x, y]))
    ks = ORDER
    ss = [SEC_S[k] for k in ks]
    if s <= ss[0]:
        i, j, w = 0, 0, 0.0
    elif s >= ss[-1]:
        i, j, w = len(ks) - 1, len(ks) - 1, 0.0
    else:
        j = int(np.searchsorted(ss, s)); i = j - 1; w = (s - ss[i]) / (ss[j] - ss[i])
    Pi, Pj = PROF[ks[i]], PROF[ks[j]]
    nc = (1 - w) * Pi['nc'] + w * Pj['nc']; ne = (1 - w) * Pi['ne'] + w * Pj['ne']
    t = (n - nc) / (ne - nc)
    if t < 0 or t > 1.0:
        return z_exist, s, n, t
    zi = np.interp(Pi['nc'] + t * (Pi['ne'] - Pi['nc']), Pi['des'][:, 0], Pi['des'][:, 1])
    zj = np.interp(Pj['nc'] + t * (Pj['ne'] - Pj['nc']), Pj['des'][:, 0], Pj['des'][:, 1])
    zd = (1 - w) * zi + w * zj
    # плавное сопряжение у бровки (t < 0,08) и у уреза (t > 0,92)
    if t < 0.08:
        a = t / 0.08; zd = (1 - a) * z_exist + a * min(zd, z_exist)
    if t > 0.92:
        a = (1 - t) / 0.08; zd = (1 - a) * z_exist + a * zd
    # концы участка (s за пределами сечений): затухание проекта
    fade = 1.0
    if s < ss[0]:
        fade = max(0.0, 1 - (ss[0] - s) / 14.0)
    if s > ss[-1]:
        fade = max(0.0, 1 - (s - ss[-1]) / 10.0)
    return fade * zd + (1 - fade) * z_exist, s, n, t


def build_design_dem():
    ZD = ZE.copy()
    T = np.full(ZE.shape, np.nan)
    for iy, y in enumerate(GY):
        for ix, x in enumerate(GX):
            if x < 52 or x > 100 or y < -10 or y > 108:
                continue
            z, s, n, t = z_design_point(x, y, ZE[iy, ix])
            ZD[iy, ix] = z; T[iy, ix] = t if 0.0 <= t <= 1.0 else np.nan
    np.savez(os.path.join(HERE, 'dem_design.npz'), Z=ZD, T=T)
    return ZD, T


# ---------------------------------------------------------------- геометрические примитивы
class Mesh:
    def __init__(self, name, color, opacity=1.0, layer='common', group='', desc=''):
        self.name, self.color, self.opacity, self.layer, self.group, self.desc = name, color, opacity, layer, group, desc
        self.v = []; self.f = []

    def add(self, verts, faces):
        o = len(self.v)
        self.v.extend([tuple(map(float, p)) for p in verts]); self.f.extend([(a + o, b + o, c + o) for a, b, c in faces])

    def quad(self, a, b, c, d):
        self.add([a, b, c, d], [(0, 1, 2), (0, 2, 3)])


def prism(m, poly, z0, z1):
    poly = list(poly)
    n = len(poly)
    verts = [(x, y, z0) for x, y in poly] + [(x, y, z1) for x, y in poly]
    faces = []
    for i in range(1, n - 1):
        faces += [(0, i + 1, i), (n, n + i, n + i + 1)]
    for i in range(n):
        j = (i + 1) % n
        faces += [(i, j, n + j), (i, n + j, n + i)]
    m.add(verts, faces)


def prism_var(m, poly, z0s, z1s):
    n = len(poly)
    verts = [(x, y, z) for (x, y), z in zip(poly, z0s)] + [(x, y, z) for (x, y), z in zip(poly, z1s)]
    faces = []
    for i in range(1, n - 1):
        faces += [(0, i + 1, i), (n, n + i, n + i + 1)]
    for i in range(n):
        j = (i + 1) % n
        faces += [(i, j, n + j), (i, n + j, n + i)]
    m.add(verts, faces)


def offset_poly(pts, t):
    """полоса шириной t вдоль полилинии → полигон (левый край, правый край)"""
    P = np.asarray(pts, float)
    L, Rr = [], []
    for i in range(len(P)):
        if i == 0:
            v = P[1] - P[0]
        elif i == len(P) - 1:
            v = P[-1] - P[-2]
        else:
            v = (P[i + 1] - P[i - 1])
        v = v / np.hypot(*v); nrm = np.array([-v[1], v[0]])
        L.append(P[i] + nrm * t / 2); Rr.append(P[i] - nrm * t / 2)
    return L, Rr


def wall(m, pts, t, ztop, zbot_fun):
    L, Rr = offset_poly(pts, t)
    for i in range(len(pts) - 1):
        a0, a1, b0, b1 = L[i], L[i + 1], Rr[i], Rr[i + 1]
        quad_pts = [a0, a1, b1, b0]
        zt = [ztop(p) for p in quad_pts]; zb = [zbot_fun(p) for p in quad_pts]
        prism_var(m, quad_pts, zb, zt)


def cylinder(m, x, y, r, z0, z1, seg=14):
    poly = [(x + r * math.cos(2 * math.pi * k / seg), y + r * math.sin(2 * math.pi * k / seg)) for k in range(seg)]
    prism(m, poly, z0, z1)


def tube(m, pts3, r, seg=8):
    P = np.asarray(pts3, float)
    rings = []
    for i in range(len(P)):
        v = P[min(i + 1, len(P) - 1)] - P[max(i - 1, 0)]; v /= np.linalg.norm(v)
        a = np.array([0, 0, 1.0]) if abs(v[2]) < 0.9 else np.array([1.0, 0, 0])
        u = np.cross(v, a); u /= np.linalg.norm(u); w = np.cross(v, u)
        rings.append([P[i] + r * (math.cos(2 * math.pi * k / seg) * u + math.sin(2 * math.pi * k / seg) * w)
                      for k in range(seg)])
    verts = [p for ring in rings for p in ring]
    faces = []
    for i in range(len(P) - 1):
        for k in range(seg):
            a = i * seg + k; b = i * seg + (k + 1) % seg; c = (i + 1) * seg + (k + 1) % seg; dd = (i + 1) * seg + k
            faces += [(a, b, c), (a, c, dd)]
    m.add(verts, faces)


def ear_clip(poly):
    pts = [tuple(p) for p in poly]
    if len(pts) > 2 and np.allclose(pts[0], pts[-1]):
        pts = pts[:-1]
    idx = list(range(len(pts)))
    A = sum(pts[i][0] * pts[(i + 1) % len(pts)][1] - pts[(i + 1) % len(pts)][0] * pts[i][1] for i in range(len(pts)))
    if A < 0:
        idx.reverse()
    tris = []
    def inside(p, a, b, c):
        def s(p1, p2, p3):
            return (p1[0] - p3[0]) * (p2[1] - p3[1]) - (p2[0] - p3[0]) * (p1[1] - p3[1])
        d1, d2, d3 = s(p, a, b), s(p, b, c), s(p, c, a)
        return not ((d1 < 0 or d2 < 0 or d3 < 0) and (d1 > 0 or d2 > 0 or d3 > 0))
    guard = 0
    while len(idx) > 3 and guard < 10000:
        guard += 1
        for k in range(len(idx)):
            i0, i1, i2 = idx[k - 1], idx[k], idx[(k + 1) % len(idx)]
            a, b, c = pts[i0], pts[i1], pts[i2]
            cross = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
            if cross <= 1e-12:
                continue
            if any(inside(pts[j], a, b, c) for j in idx if j not in (i0, i1, i2)):
                continue
            tris.append((i0, i1, i2)); idx.pop(k); break
        else:
            break
    if len(idx) == 3:
        tris.append(tuple(idx))
    return pts, tris


def curtain(m, line, poly_pk_z, off=0.0):
    pts, tris = ear_clip(poly_pk_z)
    verts = []
    for pk, z in pts:
        x, y = line_xy(line, pk)
        verts.append((x, y, z))
    m.add(verts, tris)


# ---------------------------------------------------------------- сборка сцены
def build():
    ZD, T = build_design_dem()
    fD = RegularGridInterpolator((GY, GX), ZD, bounds_error=False, fill_value=None)
    zD = lambda x, y: float(fD([[y, x]])[0])
    zEx = lambda x, y: float(fE([[y, x]])[0])
    meshes = []

    # здания
    for b in BUILDINGS:
        kind = b['kind']
        col = {'house': '#b5835a', 'garage': '#8d6e63', 'bath': '#a1887f', 'shed': '#bcaaa4', 'canopy': '#d7ccc8'}[kind]
        m = Mesh(b['name'], col, layer='common', group='Здания', desc=b['name'])
        poly = b['poly']
        zb = b.get('base', min(zEx(x, y) for x, y in poly))
        h = b['h']
        if kind == 'canopy':
            prism(m, poly, zb + h - 0.25, zb + h)
            for x, y in poly:
                cylinder(m, x, y, 0.08, zb, zb + h, seg=6)
        else:
            prism(m, poly, zb - 0.3, zb + h * (0.72 if kind in ('house', 'garage') else 1.0))
        meshes.append(m)
        if kind in ('house', 'garage'):
            r = Mesh(b['name'] + ' (кровля)', '#5d4037' if kind == 'house' else '#455a64', group='Здания')
            P = np.array(poly); c = P.mean(0)
            e0 = (P[0] + P[1]) / 2; e1 = (P[2] + P[3]) / 2
            ztop = zb + h; zeav = zb + h * 0.72
            r.add([(*P[0], zeav), (*P[1], zeav), (*P[2], zeav), (*P[3], zeav), (*((P[0] + P[3]) / 2), ztop),
                   (*((P[1] + P[2]) / 2), ztop)],
                  [(0, 1, 5), (0, 5, 4), (2, 3, 4), (2, 4, 5), (0, 4, 3), (1, 2, 5)])
            meshes.append(r)

    # существующие стены, площадка, габионы — слой «exist»
    for w in WALLS_EXIST:
        st = w['state']
        col = '#e74c3c' if st == 'аварийное' else ('#f39c12' if 'недопуст' in st else '#bdc3c7')
        m = Mesh(w['name'], col, layer='exist', group='Существующие сооружения', desc=f"{w['name']} — {st}")
        if w['zt'] is None:
            wall(m, w['pts'], w['t'], lambda p: zEx(*p) + 1.0, lambda p: zEx(*p) - 0.6)
        else:
            wall(m, w['pts'], w['t'], lambda p, zt=w['zt']: zt, lambda p, zb=w['zb']: zb - 0.6)
        meshes.append(m)
    m = Mesh(DECK['name'], '#c0392b', layer='exist', group='Существующие сооружения',
             desc='Обзорная площадка на металлическом каркасе — аварийное состояние, демонтаж')
    prism(m, DECK['poly'], DECK['z'] - 0.35, DECK['z'])
    for x, y in DECK['poly'] + [(67.8, 58.2)]:
        cylinder(m, x, y, 0.12, zEx(x, y), DECK['z'] - 0.35, seg=8)
    meshes.append(m)
    m = Mesh('Существующие габионы у уреза', '#95a5a6', layer='exist', group='Существующие сооружения',
             desc='Габионы вдоль уреза (по топоплану) — требуют обследования')
    wall(m, GABION_EXIST, 1.0, lambda p: zEx(*p) + 0.6, lambda p: zEx(*p) - 0.4)
    meshes.append(m)

    # ---------------- проект
    # обвязочная балка ГЦК по оси бермы
    def bench_z(x, y):
        return zD(x, y)
    ax_dense = []
    for i in range(len(AXIS) - 1):
        for t in np.linspace(0, 1, 6, endpoint=False):
            ax_dense.append(AXIS[i] + t * (AXIS[i + 1] - AXIS[i]))
    ax_dense.append(AXIS[-1]); ax_dense = np.array(ax_dense)
    m = Mesh('Обвязочная ж/б балка ГЦК 1,0×0,6 м', '#7f8c8d', layer='design', group='Удерживающее сооружение',
             desc='Монолитная балка B30 по оголовкам контрфорсов, верх на отм. бермы')
    wall(m, ax_dense, 1.0, lambda p: bench_z(*p) + 0.05, lambda p: bench_z(*p) - 0.55)
    meshes.append(m)

    # грунтоцементные контрфорсы: рёбра поперёк берега с шагом s_r
    mj = Mesh('Грунтоцементные контрфорсы (Jet-2, Ø1,0 м)', '#9e9e9e', opacity=0.85, layer='design_ug',
              group='Удерживающее сооружение',
              desc=f"Рёбра из колонн Ø1,0 м шаг {JET['step']} м, толщина {JET['t']} м, шаг рёбер {JET['s_r']} м, до отм. 90,0; армирование трубой 146×8 через колонну")
    s_vals = np.arange(2.0, AXIS_LEN - 1.0, JET['s_r'])
    ribs = []
    cum = np.r_[0, np.cumsum(np.hypot(*np.diff(AXIS, axis=0).T))]
    for s in s_vals:
        i = int(np.searchsorted(cum, s)) - 1; i = max(0, min(i, len(AXIS) - 2))
        t = (s - cum[i]) / (cum[i + 1] - cum[i]); P = AXIS[i] + t * (AXIS[i + 1] - AXIS[i])
        v = AXIS[i + 1] - AXIS[i]; v = v / np.hypot(*v); nrm = np.array([v[1], -v[0]])
        a = P - nrm * 2.3; b = P + nrm * 4.7
        ribs.append((a, b))
        L, Rr = offset_poly([a, b], JET['t'])
        quad_pts = [L[0], L[1], Rr[1], Rr[0]]
        prism_var(mj, quad_pts, [90.0] * 4, [bench_z(*p) - 0.55 if k in (0, 3) else min(bench_z(*p), 102.0) - 0.1
                                            for k, p in enumerate(quad_pts)])
    meshes.append(mj)
    # армирующие трубы (условно — по 2 на ребро для наглядности)
    mp = Mesh('Армирующие трубы 146×8', '#34495e', layer='design_ug', group='Удерживающее сооружение')
    for a, b in ribs:
        for t in (0.2, 0.55):
            P = a + t * (b - a)
            cylinder(mp, P[0], P[1], 0.073, 90.2, bench_z(*P) - 0.6, seg=6)
    meshes.append(mp)

    # габионная стена: по линии нижней кромки бермы (n = +2,3…+4,7 от оси)
    mg = Mesh('Габионная стена h = 2,4…3,0 м', '#8e9aa5', layer='design', group='Габионы и крепления',
              desc='Коробчатые габионы 2×1×1 / 2×1,5×1 / 2×3×1, сетка 8×10 Zn-Al+ПВХ 2,7/3,7 мм, камень 100–250 мм, уступы 0,5 м')
    for s in np.arange(0.0, AXIS_LEN - 0.5, 2.0):
        for (n0, n1, z0rel, z1rel) in ((2.3, 5.3, 0, 1), (2.3, 4.8, 1, 2), (2.3, 4.3, 2, 3)):
            i = int(np.searchsorted(cum, s)) - 1; i = max(0, min(i, len(AXIS) - 2))
            pts = []
            for ss in (s, min(s + 2.0, AXIS_LEN)):
                j = int(np.searchsorted(cum, ss)) - 1; j = max(0, min(j, len(AXIS) - 2))
                t = (ss - cum[j]) / (cum[j + 1] - cum[j]); P = AXIS[j] + t * (AXIS[j + 1] - AXIS[j])
                v = AXIS[j + 1] - AXIS[j]; v = v / np.hypot(*v); nrm = np.array([v[1], -v[0]])
                pts.append((P + nrm * n0, P + nrm * n1))
            quad_pts = [pts[0][0], pts[1][0], pts[1][1], pts[0][1]]
            zb = min(zD(*pts[0][1]), zD(*pts[1][1]), 102.0) - 0.4
            prism(mg, quad_pts, zb + z0rel, zb + z1rel)
    meshes.append(mg)

    # матрацы Рено: полоса по рельефу от подножия габионов до дна (+фартук 3 м)
    mr = Mesh('Матрацы Рено 0,3 м + фартук 3,0 м', '#5d6d7e', layer='design', group='Габионы и крепления',
              desc='Матрацы Рено 6×2×0,3 м на геотекстиле 300 г/м², до отм. 99,0 и фартук по дну 3 м')
    for s in np.arange(0.0, AXIS_LEN - 0.5, 1.0):
        rows = []
        for ss in (s, min(s + 1.0, AXIS_LEN)):
            j = int(np.searchsorted(cum, ss)) - 1; j = max(0, min(j, len(AXIS) - 2))
            t = (ss - cum[j]) / (cum[j + 1] - cum[j]); P = AXIS[j] + t * (AXIS[j + 1] - AXIS[j])
            v = AXIS[j + 1] - AXIS[j]; v = v / np.hypot(*v); nrm = np.array([v[1], -v[0]])
            row = [P + nrm * n for n in np.arange(5.3, 16.5, 0.7)]
            row = [p for p in row if zD(*p) > RIVER_BED - 0.05] or row[:2]
            rows.append(row[:min(len(row), 14)])
        k = min(len(rows[0]), len(rows[1]))
        for q in range(k - 1):
            a, b, c, dd = rows[0][q], rows[1][q], rows[1][q + 1], rows[0][q + 1]
            mr.quad((*a, zD(*a) + 0.08), (*b, zD(*b) + 0.08), (*c, zD(*c) + 0.08), (*dd, zD(*dd) + 0.08))
    meshes.append(mr)

    # противоэрозионное крепление откоса срезки (георешётка + посев): подсветка по T
    # (делается окраской вершин рельефа во вьюере по полю T)

    # дренаж: перехватывающий Д-1 (на плато, глубина 3,2 м), колодцы, выпуски, ГДС
    md = Mesh('Перехватывающий дренаж Д-1, Ø160', '#2e86c1', layer='design_ug', group='Дренаж и водоотвод',
              desc='Траншея 0,8×3,2 м, щебень 20–40 в геотекстиле, труба ПВХ гофр. перфорир. Ø160 SN8, i ≥ 0,005')
    drain = np.array(data.DRAIN_AXIS)
    pts3 = [(x, y, zEx(x, y) - 3.2) for x, y in drain]
    tube(md, pts3, 0.15)
    meshes.append(md)
    mw = Mesh('Смотровые дренажные колодцы ДК Ø1000', '#1b4f72', layer='design', group='Дренаж и водоотвод')
    wells = [drain[0], drain[3], drain[6], drain[9], drain[-1]]
    for x, y in wells:
        cylinder(mw, x, y, 0.55, zEx(x, y) - 3.6, zEx(x, y) + 0.15, seg=16)
    meshes.append(mw)
    mo = Mesh('Выпуски ПНД Ø160–200 в реку', '#1f618d', layer='design', group='Дренаж и водоотвод',
              desc='Закрытые выпуски дренажа и ливневой канализации с оголовками в креплении')
    for (x, y) in (drain[0], drain[6], drain[-1]):
        s, n = axis_frame(np.array([x, y]))
        j = int(np.searchsorted(cum, s)) - 1; j = max(0, min(j, len(AXIS) - 2))
        v = AXIS[j + 1] - AXIS[j]; v = v / np.hypot(*v); nrm = np.array([v[1], -v[0]])
        P0 = np.array([x, y]); pts = [P0 + nrm * k for k in np.linspace(0, 30, 31)]
        p3 = [(p[0], p[1], max(zD(*p) - 0.8, WL_LOW + 0.3)) for p in pts if zD(*p) > WL_LOW - 0.2]
        if len(p3) > 2:
            tube(mo, p3, 0.12)
    meshes.append(mo)
    mh = Mesh('Горизонтальные дренажные скважины ГДС', '#5dade2', layer='design_ug', group='Дренаж и водоотвод',
              desc='Ø108 мм, фильтр ПВХ Ø63 в геотекстиле, L = 15–18 м, уклон 3–5° к выходу, шаг 2,5 м (между рёбрами ГЦК), 2 яруса')
    for idx, s in enumerate(np.arange(3.25, AXIS_LEN - 1.0, JET['s_r'])):
        j = int(np.searchsorted(cum, s)) - 1; j = max(0, min(j, len(AXIS) - 2))
        t = (s - cum[j]) / (cum[j + 1] - cum[j]); P = AXIS[j] + t * (AXIS[j + 1] - AXIS[j])
        v = AXIS[j + 1] - AXIS[j]; v = v / np.hypot(*v); nrm = np.array([v[1], -v[0]])
        for n_out, dz0, L in ((2.2, -0.8, 16.0), (5.4, None, 15.0)):
            A = P + nrm * n_out
            z0 = (zD(*A) + dz0) if dz0 is not None else min(zD(*A), 102.0) + 0.3
            B = A - nrm * L
            tube(mh, [(A[0], A[1], z0), (B[0], B[1], z0 + L * math.tan(math.radians(4)))], 0.05, seg=5)
    meshes.append(mh)
    ml = Mesh('Водоотводный лоток по бровке DN200', '#21618c', layer='design', group='Дренаж и водоотвод',
              desc='Лоток полимербетонный DN200 с решёткой, сбор с кровель и плато → выпуски')
    crest_line = [(x + 2.6, y) for x, y in drain]
    wall(ml, crest_line, 0.35, lambda p: zEx(*p) + 0.02, lambda p: zEx(*p) - 0.3)
    meshes.append(ml)

    # лестница (проект): от плато к берме и к воде, у северной границы зоны I
    mstair = Mesh('Лестница металлическая на винтовых сваях', '#6c3483', layer='design', group='Благоустройство',
                  desc='Марши по 1,0 м шириной, площадки на берме и нижней террасе, ограждения h = 1,1 м')
    sx, sy = 63.0, 66.6
    for k in range(26):
        x = sx + k * 0.6; y = sy - k * 0.05
        z = zD(x, y)
        prism(mstair, [(x, y - 0.6), (x + 0.6, y - 0.6), (x + 0.6, y + 0.6), (x, y + 0.6)], z + 0.05, z + 0.2)
    meshes.append(mstair)

    # мониторинг
    mi = Mesh('Инклинометрические скважины (Н = 22 м)', '#e74c3c', layer='monitor', group='Мониторинг')
    mpz = Mesh('Пьезометры', '#3498db', layer='monitor', group='Мониторинг')
    mgm = Mesh('Деформационные марки', '#f1c40f', layer='monitor', group='Мониторинг')
    INCL = [(57.0, 30.0), (66.0, 53.0), (58.0, 52.0), (71.0, 73.0), (74.0, 86.0)]
    for x, y in INCL:
        cylinder(mi, x, y, 0.18, zD(x, y), zD(x, y) + 1.2, seg=10)
    for x, y in [(54.0, 40.0), (55.0, 60.0), (60.0, 80.0), (64.0, 96.0)]:
        cylinder(mpz, x, y, 0.15, zD(x, y), zD(x, y) + 0.9, seg=10)
    for s in np.arange(4.0, AXIS_LEN, 8.0):
        j = int(np.searchsorted(cum, s)) - 1; j = max(0, min(j, len(AXIS) - 2))
        t = (s - cum[j]) / (cum[j + 1] - cum[j]); P = AXIS[j] + t * (AXIS[j + 1] - AXIS[j])
        cylinder(mgm, P[0], P[1], 0.12, zD(*P) + 0.05, zD(*P) + 0.35, seg=8)
    for b in BUILDINGS[:7]:
        for x, y in b['poly'][:2]:
            cylinder(mgm, x, y, 0.1, zEx(x, y) + 0.3, zEx(x, y) + 0.6, seg=8)
    meshes += [mi, mpz, mgm]

    # скважины ИГИ с колонками грунтов
    for name, (x, y, z0, lay, gwd) in BOREHOLES.items():
        ztop = z0
        for ige, bot in lay:
            col = SOILS[ige]['color'] if ige in SOILS else '#795548'
            m = Mesh(f'Скв. {name}: ИГЭ-{ige}', col, layer='geo', group='Геология',
                     desc=f'Скважина {name} (устье {z0:.2f}), ИГЭ-{ige} до глубины {bot} м')
            cylinder(m, x, y, 0.22, z0 - bot, ztop, seg=12)
            ztop = z0 - bot
            meshes.append(m)

    # геологические «шторки» по разрезам (существующее положение)
    import sections as S
    for key in ['А-А', 'Б-Б']:
        sec = DESIGN[key]['exist']('design')
        surf = np.asarray(sec.surface)
        pk = np.linspace(surf[0, 0] + 15, min(surf[-1, 0], DESIGN[key]['edge'] + 8), 120)
        g = np.interp(pk, surf[:, 0], surf[:, 1])
        tops = []
        for name, top in sec.layers:
            zt = g if top is None else np.minimum(np.interp(pk, np.asarray(top)[:, 0], np.asarray(top)[:, 1]), g)
            tops.append((name, zt))
        for i, (name, zt) in enumerate(tops):
            zb = tops[i + 1][1] if i + 1 < len(tops) else np.full_like(pk, 90.0)
            zb = np.minimum(zb, zt)
            m = Mesh(f'Разрез {key}: ИГЭ-{name}', SOILS[name]['color'], opacity=0.92, layer='geo', group='Геология',
                     desc=f"Разрез {key}, ИГЭ-{name}: {SOILS[name]['desc']}")
            for q in range(len(pk) - 1):
                if zt[q] - zb[q] < 0.02 and zt[q + 1] - zb[q + 1] < 0.02:
                    continue
                x0, y0 = line_xy(LINES[key], pk[q]); x1, y1 = line_xy(LINES[key], pk[q + 1])
                m.quad((x0, y0, zb[q]), (x1, y1, zb[q + 1]), (x1, y1, zt[q + 1]), (x0, y0, zt[q]))
            meshes.append(m)
        # критическая поверхность (сущ.) на шторке
        cr = RES['exist'][key]['base']
        pts = [(*line_xy(LINES[key], p), z + 0.0) for p, z in zip(cr['xs'], cr['zs'])]
        m = Mesh(f'Поверхность скольжения {key} (сущ., k = {cr["F"]:.2f})', '#e74c3c', layer='geo', group='Геология')
        tube(m, pts, 0.12, seg=6)
        meshes.append(m)

    # тело потенциального оползня (сущ., зона А-А): развёртка критической дуги вдоль берега ±14 м
    cr = RES['exist']['А-А']['base']
    m = Mesh('Тело потенциального оползня (сущ. положение, сеч. А-А)', '#ff5252', opacity=0.35, layer='slide',
             group='Оползень', desc=f"Критическая поверхность скольжения k = {cr['F']:.2f}, глубина до отм. {cr['zmin']:.1f}")
    a = math.radians(LINE_AA['az']); ux, uy = math.sin(a), math.cos(a); nx, ny = -uy, ux
    rows = []
    for off in np.linspace(-14, 14, 15):
        shrink = 1 - (abs(off) / 15.5) ** 4
        row = []
        for p, z in zip(cr['xs'], cr['zs']):
            x, y = line_xy(LINE_AA, p); x += nx * off; y += ny * off
            zg = zEx(x, y)
            row.append((x, y, zg - (zg - z) * shrink))
        rows.append(row)
    for i in range(len(rows) - 1):
        for j in range(len(rows[0]) - 1):
            m.quad(rows[i][j], rows[i][j + 1], rows[i + 1][j + 1], rows[i + 1][j])
    meshes.append(m)
    return ZD, T, meshes


def b64(arr, dt):
    return base64.b64encode(np.asarray(arr, dtype=dt).tobytes()).decode()


def export(ZD, T, meshes):
    step = 2   # 1,0 м
    gx = GX[::step]; gy = GY[::step]
    Ze = ZE[::step, ::step]; Zd = ZD[::step, ::step]; Tt = np.nan_to_num(T[::step, ::step], nan=-1)
    # поле классов для раскраски проекта: 0 — плато/газон, 1 — откос срезки (георешётка), 2 — берма, 3 — нижняя терраса
    scene = dict(origin=dict(X0=data.X0, Y0=data.Y0), grid=dict(x0=float(gx[0]), y0=float(gy[0]), dx=1.0, nx=len(gx), ny=len(gy)),
                 zE=b64(Ze, '<f4'), zD=b64(Zd, '<f4'), tD=b64(Tt, '<f4'), wl=WL_LOW, wf=WL_FLOOD, meshes=[])
    for m in meshes:
        if not m.v:
            continue
        scene['meshes'].append(dict(name=m.name, color=m.color, opacity=m.opacity, layer=m.layer, group=m.group,
                                    desc=m.desc, v=b64(np.array(m.v), '<f4'), f=b64(np.array(m.f), '<u4')))
    json.dump(scene, open(os.path.join(HERE, 'results', 'scene.json'), 'w', encoding='utf-8'), ensure_ascii=False)
    # OBJ (Y-вверх не меняем: z — высота; координаты локальные, начало X0/Y0 МСК-70)
    obj = ['# Заварзино, Мостовая 40 — 3D-модель проекта берегоукрепления', f'# локальная СК: x = Y - {data.Y0}, y = X - {data.X0}, z — БС77',
           'mtllib berег.mtl'.replace('berег', 'model')]
    mtl = []
    vo = 1
    def add_grid(name, Z, col):
        nonlocal vo
        obj.append(f'o {name}'); obj.append(f'usemtl {name.replace(" ", "_")}')
        mtl.append(f"newmtl {name.replace(' ', '_')}\nKd {int(col[1:3],16)/255:.3f} {int(col[3:5],16)/255:.3f} {int(col[5:7],16)/255:.3f}\n")
        ny, nx = Z.shape
        for j in range(ny):
            for i in range(nx):
                obj.append(f'v {gx[i]:.2f} {gy[j]:.2f} {Z[j, i]:.3f}')
        for j in range(ny - 1):
            for i in range(nx - 1):
                a = vo + j * nx + i; b = a + 1; c = a + nx + 1; dd = a + nx
                obj.append(f'f {a} {b} {c}'); obj.append(f'f {a} {c} {dd}')
        vo += nx * ny
    add_grid('Рельеф существующий', Ze, '#8d9b6a')
    add_grid('Рельеф проектный', Zd, '#9bb069')
    for k, m in enumerate(meshes):
        if not m.v:
            continue
        nm = f'm{k:03d}_' + ''.join(ch if ch.isalnum() else '_' for ch in m.name)[:50]
        obj.append(f'o {nm}'); obj.append(f'usemtl {nm}')
        c = m.color
        mtl.append(f"newmtl {nm}\nKd {int(c[1:3],16)/255:.3f} {int(c[3:5],16)/255:.3f} {int(c[5:7],16)/255:.3f}\nd {m.opacity}\n")
        for v in m.v:
            obj.append(f'v {v[0]:.3f} {v[1]:.3f} {v[2]:.3f}')
        for f in m.f:
            obj.append(f'f {f[0]+vo} {f[1]+vo} {f[2]+vo}')
        vo += len(m.v)
    open(os.path.join(HERE, 'results', 'model.obj'), 'w', encoding='utf-8').write('\n'.join(obj))
    open(os.path.join(HERE, 'results', 'model.mtl'), 'w', encoding='utf-8').write('\n'.join(mtl))
    print('meshes', len(scene['meshes']), 'obj lines', len(obj))


if __name__ == '__main__':
    ZD, T, meshes = build()
    export(ZD, T, meshes)
