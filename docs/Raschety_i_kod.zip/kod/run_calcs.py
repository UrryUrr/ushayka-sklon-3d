# -*- coding: utf-8 -*-
"""Сводный расчёт: устойчивость (сущ./проект), оползневое давление, ГЦК, габионы,
крепление подошвы, дренаж и водоотвод, объёмы. Результаты → results/results.json, рисунки → results/*.png"""
import json, os, time, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MplPoly

import data
from data import SOILS, WL_LOW, WL_FLOOD, WL_ICE, V_FLOOD, ICE_H
import sections as S
from design import DESIGN, sec_design, KST, KST_SP, KH7, JET, jet_dc, rapid_drawdown_gw

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results')
os.makedirs(OUT, exist_ok=True)
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8})
R = dict(meta=dict(date=time.strftime('%Y-%m-%d'), kst=KST, kst_sp=KST_SP, kh=KH7, jet=JET, dc=jet_dc()))


def search(sec, d, **kw):
    b, _ = sec.search_bishop(d['xr'], d['zr'], nx=14, nz=12, nr=14, refine=2, **kw)
    if b is None:
        return None
    sp = sec.spencer(b['xs'], b['zs'])
    return dict(F=round(b['F'], 3), Fsp=round(sp['F'], 3) if sp else None, xc=b['xc'], zc=b['zc'], R=b['R'],
                x_in=round(b['x_in'], 2), x_out=round(b['x_out'], 2), zmin=round(float(b['zs'].min()), 2),
                xs=b['xs'][::5].round(3).tolist(), zs=b['zs'][::5].round(3).tolist())


def perched_line(surf, crest, edge):
    s = np.asarray(surf)
    g = lambda x: float(np.interp(x, s[:, 0], s[:, 1]))
    pts = [(x, g(x) - 3.0) for x in np.arange(s[0, 0] - 5, crest + 0.01, 2.0)]
    pts += [(edge - 1.0, g(edge - 1.0) - 0.3), (edge + 20, WL_LOW - 0.5)]
    return pts


def exist_sec(key, case):
    d = DESIGN[key]
    f = d['exist']
    if case == 'norm':
        return f('normative', name=f'{key} сущ. норм.')
    if case == 'base':
        return f('design', name=f'{key} сущ.')
    if case == 'seis':
        return f('design', kh=KH7, name=f'{key} сущ. сейсм.')
    if case == 'perched':
        sec = f('design', name=f'{key} сущ. верховодка')
        sec.perched = np.asarray(perched_line(d['exist_surf'], d['crest'], d['edge']), float)
        return sec


t0 = time.time()
R['exist'] = {}
R['design'] = {}
for key in ['А-А', 'Б-Б', 'В-В', 'Г-Г']:
    d = DESIGN[key]
    ex = {}
    for case in ['norm', 'base', 'perched', 'seis']:
        ex[case] = search(exist_sec(key, case), d)
        print(key, 'сущ', case, ex[case]['F'], ex[case]['Fsp'], flush=True)
    R['exist'][key] = ex
    de = {}
    de['base'] = search(sec_design(key), d)
    de['seis'] = search(sec_design(key, kh=KH7), d)
    de['rdd'] = search(sec_design(key, gw=rapid_drawdown_gw(key)), d)
    gw_nodrain = d['exist']('design').water.tolist()
    de['nodrain'] = search(sec_design(key, gw=[tuple(p) for p in gw_nodrain]), d)
    de['nojet'] = search(sec_design(key, jet=False), d)
    de['constr'] = search(sec_design(key, jet=False, extra_loads=[(d['bench'][0], d['bench'][1], 30.0)]), d)
    de['constr_n'] = search(sec_design(key, jet=False, param='normative',
                                       extra_loads=[(d['bench'][0], d['bench'][1], 30.0)]), d)
    de['upper'] = search(sec_design(key), d, x_out=(0, d['bench'][0] + 0.2))
    de['lower'] = search(sec_design(key), d, x_in=(d['bench'][1] - 0.2, 99))
    for k2, v in de.items():
        print(key, 'проект', k2, v['F'] if v else None, flush=True)
    # оползневое давление на зону ГЦК (метод передачи сил) по критической поверхности без ГЦК
    sec0 = sec_design(key, jet=False)
    crit = de['nojet']
    th = sec0.thrust(np.array(crit['xs']), np.array(crit['zs']), KST, n=80)
    x1 = d['jet'][0]
    Eh_at = float(np.interp(x1, th['xb'], th['Eh']))
    Emax = float(th['Eh'].max())
    sec0s = sec_design(key, jet=False, kh=KH7)
    crits = search(sec0s, d)
    ths = sec0s.thrust(np.array(crits['xs']), np.array(crits['zs']), KST_SP, n=80)
    de['thrust'] = dict(xb=th['xb'].round(2).tolist(), Eh=np.round(th['Eh'], 1).tolist(), Eh_at=round(Eh_at, 1),
                        Emax=round(Emax, 1), Eh_at_s=round(float(np.interp(x1, ths['xb'], ths['Eh'])), 1),
                        Emax_s=round(float(ths['Eh'].max()), 1))
    print(key, 'E_h', de['thrust']['Eh_at'], de['thrust']['Emax'], 'сейсм', de['thrust']['Emax_s'], flush=True)
    R['design'][key] = de
print('устойчивость: %.0f с' % (time.time() - t0))


# ---------------------------------------------------------------- рисунки сечений
def draw_section(ax, key, state, res, title):
    d = DESIGN[key]
    if state == 'exist':
        sec = d['exist']('design')
        surf = np.asarray(sec.surface)
    else:
        sec = sec_design(key)
        surf = np.asarray(sec.surface)
    xs = np.linspace(surf[0, 0], surf[-1, 0], 400)
    g = np.interp(xs, surf[:, 0], surf[:, 1])
    zbot = 88.0
    # слои
    cols = {'304': '#e3c79a', '305': '#b9d1b5', '406': '#a9c0db', '301': '#c8a070'}
    prev = g
    tops = []
    for name, top in sec.layers:
        zt = g if top is None else np.minimum(np.interp(xs, np.asarray(top)[:, 0], np.asarray(top)[:, 1]), g)
        tops.append((name, zt))
    for i, (name, zt) in enumerate(tops):
        zb = tops[i + 1][1] if i + 1 < len(tops) else np.full_like(xs, zbot)
        zb = np.minimum(zb, zt)
        ax.fill_between(xs, zb, zt, color=cols.get(name, '#ddd'), lw=0, zorder=1)
        if i > 0:
            ax.plot(xs, zt, color='#7a6a55', lw=0.5, ls='--', zorder=2)
    # вода
    ax.fill_between(xs, g, WL_LOW, where=g < WL_LOW, color='#9fd3f5', zorder=2)
    ax.axhline(WL_FLOOD, color='#1f77b4', lw=0.6, ls=':', zorder=2)
    ax.text(surf[-1, 0] - 0.5, WL_FLOOD + 0.15, f'РУВВ 1% {WL_FLOOD:.2f} (принят)', ha='right', fontsize=6, color='#1f77b4')
    ax.text(surf[-1, 0] - 0.5, WL_LOW - 0.6, f'урез {WL_LOW:.2f}', ha='right', fontsize=6, color='#1f77b4')
    gw = np.asarray(sec.water)
    ax.plot(gw[:, 0], gw[:, 1], color='#1f77b4', lw=1.0, ls='-.', zorder=3, label='УГВ')
    if state == 'exist':
        ax.plot(surf[:, 0], surf[:, 1], 'k-', lw=1.2, zorder=5)
    else:
        es = np.asarray(d['exist_surf'])
        ax.plot(es[:, 0], es[:, 1], color='#888', lw=0.8, ls='--', zorder=4, label='сущ. поверхность')
        ax.plot(surf[:, 0], surf[:, 1], 'k-', lw=1.3, zorder=5, label='проектная поверхность')
        x1, x2, zb = d['jet']
        gz = lambda x: float(np.interp(x, surf[:, 0], surf[:, 1]))
        ax.add_patch(MplPoly([(x1, gz(x1)), (x2, gz(x2)), (x2, zb), (x1, zb)], closed=True, fc='#9e9e9e', ec='#424242',
                             alpha=0.45, hatch='///', lw=0.8, zorder=4, label='ГЦК (струйная цементация)'))
        ax.add_patch(MplPoly(d['gabion'], closed=True, fc='#7f8c8d', ec='k', lw=0.8, zorder=6, label='габионы'))
        ax.add_patch(MplPoly(d['toe'], closed=True, fc='#566573', ec='k', lw=0.5, zorder=6, label='матрацы Рено, фартук'))
        b0, b1, bz = d['bench']
        ax.plot([b0, b1], [bz + 0.25, bz + 0.25], color='#a04000', lw=3, zorder=6, solid_capstyle='butt',
                label='обвязочная балка/берма')
        # дренаж
        cx = d['crest'] - 4.0
        ax.plot([cx], [gz(cx) - 3.2], 'o', ms=5, mfc='white', mec='#1f77b4', zorder=7, label='перехват. дренаж Д-1')
        for zz, xx0 in ((bz - 0.7, b1 - 0.5), (101.9, d['gabion'][1][0] + 0.1)):
            ax.plot([xx0, xx0 - 16], [zz, zz - 16 * math.tan(math.radians(-5))], color='#1f77b4', lw=1.0, zorder=7)
        ax.plot([], [], color='#1f77b4', lw=1, label='ГДС (гориз. дренажные скважины)')
    if res:
        ax.plot(res['xs'], res['zs'], color='#c0392b', lw=1.6, zorder=8)
        ax.text(res['x_out'], min(res['zs']) - 0.8, f"k = {res['F']:.2f}", color='#c0392b', fontsize=8, fontweight='bold')
    ax.set_xlim(surf[0, 0], surf[-1, 0]); ax.set_ylim(zbot, 113)
    ax.set_xlabel('ПК, м'); ax.set_ylabel('Отметка, м (БС77)')
    ax.set_title(title, fontsize=9)
    ax.grid(alpha=0.25)
    ax.set_aspect('equal')


for key in ['А-А', 'Б-Б', 'В-В', 'Г-Г']:
    fig, axs = plt.subplots(2, 1, figsize=(11, 8.2))
    ex = R['exist'][key]; de = R['design'][key]
    draw_section(axs[0], key, 'exist', ex['base'],
                 f"Сечение {key}. Существующее положение: k = {ex['base']['F']:.2f} (расчётные хар-ки), "
                 f"{ex['norm']['F']:.2f} (нормативные), {ex['perched']['F']:.2f} (верховодка), {ex['seis']['F']:.2f} (сейсм.)")
    draw_section(axs[1], key, 'design', de['base'],
                 f"Сечение {key}. Проект: k = {de['base']['F']:.2f} ≥ [k] = {KST} (основное); "
                 f"{de['seis']['F']:.2f} ≥ {KST_SP} (сейсм.); {de['rdd']['F']:.2f} (сработка паводка)")
    h, l = axs[1].get_legend_handles_labels()
    axs[1].legend(h, l, loc='lower left', fontsize=6, ncol=3, framealpha=0.9)
    fig.tight_layout()
    fn = 'sec_' + {'А-А': 'AA', 'Б-Б': 'BB', 'В-В': 'VV', 'Г-Г': 'GG'}[key] + '.png'
    fig.savefig(os.path.join(OUT, fn), dpi=170); plt.close(fig)

# эпюры оползневого давления
fig, ax = plt.subplots(figsize=(8, 3.6))
for key, c in zip(['А-А', 'Б-Б', 'В-В', 'Г-Г'], ['#c0392b', '#2471a3', '#239b56', '#7d3c98']):
    th = R['design'][key]['thrust']
    ax.plot(th['xb'], th['Eh'], color=c, label=f"{key}: E_max = {th['Emax']:.0f} кН/м")
    ax.axvline(DESIGN[key]['jet'][0], color=c, lw=0.6, ls=':')
ax.set_xlabel('ПК, м'); ax.set_ylabel('E_h, кН/м'); ax.grid(alpha=.3); ax.legend(fontsize=7)
ax.set_title('Оползневое давление (метод передачи сил, k = 1,15) по критической поверхности без ГЦК', fontsize=9)
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'thrust.png'), dpi=170); plt.close(fig)


# ---------------------------------------------------------------- ГЦК: конструктивный расчёт
def jet_check():
    """проверка зоны ГЦК методом передачи сил: E на входе, сопротивление рёбер, E на выходе (должно быть ≤ 0)"""
    t, tau, s_r = JET['t'], JET['tau'], JET['s_r']
    out = {}
    for key in ['А-А', 'Б-Б', 'В-В', 'Г-Г']:
        d = DESIGN[key]
        x1, x2, zb = d['jet']
        res = {}
        for case, kh, kst in (('осн', 0.0, KST), ('сейсм', KH7, KST_SP)):
            crit = R['design'][key]['nojet'] if kh == 0 else search(sec_design(key, jet=False, kh=kh), d)
            xs, zs = np.array(crit['xs']), np.array(crit['zs'])
            m = (xs >= x1) & (xs <= x2)
            Ls = float(np.sum(np.hypot(np.diff(xs[m]), np.diff(zs[m])))) if m.sum() > 1 else (x2 - x1)
            th0 = sec_design(key, jet=False, kh=kh).thrust(xs, zs, kst, n=90)
            th1 = sec_design(key, jet=True, kh=kh).thrust(xs, zs, kst, n=90)
            res[case] = dict(E_in=round(float(np.interp(x1, th0['xb'], th0['Eh'])), 0),
                             E_exit_nojet=round(float(th0['E'][-1]), 0), E_exit_jet=round(float(th1['E'][-1]), 0),
                             E_max_jet=round(float(th1['Eh'].max()), 0), L_slip=round(Ls, 1),
                             dR=round(jet_dc() * Ls, 0), T_rib=round(tau * t * Ls, 0))
        out[key] = dict(L_rib=round(x2 - x1, 1),
                        depth=round(float(np.interp(x1, *np.array(d['surf']).T)) - zb, 1), **res)
    return out


R['jet'] = jet_check()


# ---------------------------------------------------------------- габионная стена
def gabion_check(H=3.0, B=(3.0, 2.0, 1.5), gam_g=17.0, q=5.0, phi=7.0, c=10.0, g=19.2, mu=0.5, batter=6.0):
    Ka = math.tan(math.radians(45 - phi / 2)) ** 2
    z0 = max((2 * c / math.sqrt(Ka) - Ka * q) / (Ka * g), 0)
    sa = Ka * (g * H + q) - 2 * c * math.sqrt(Ka)
    Ea = 0.5 * sa * (H - z0)
    ya = (H - z0) / 3
    W = sum(B) * 1.0 * gam_g
    # центр тяжести относительно носка (ступени со сдвигом 0,5 м назад)
    xs = [B[0] / 2, 0.5 + B[1] / 2 + (B[0] - 0.5 - B[1]), 1.0 + B[2] / 2 + (B[0] - 1.0 - B[2])]
    xcg = sum(b * x for b, x in zip(B, xs)) / sum(B)
    Wn = W * math.cos(math.radians(batter)) + Ea * math.sin(math.radians(batter))
    Rsl = Wn * mu + 0.5 * 18 * 0.5 ** 2 * math.tan(math.radians(45 + 8)) ** 2   # + пассив у носка (заглубл. 0,5 м)
    Fsl = Ea * math.cos(math.radians(batter)) - W * math.sin(math.radians(batter))
    k_sl = Rsl / max(Fsl, 1e-6)
    Mh = W * xcg; Mo = Ea * ya
    e = B[0] / 2 - (Mh - Mo) / W
    pmax = W / B[0] * (1 + 6 * abs(e) / B[0]); pmin = W / B[0] * (1 - 6 * abs(e) / B[0])
    return dict(H=H, Ka=round(Ka, 3), Ea=round(Ea, 1), W=round(W, 1), k_slide=round(k_sl, 2),
                k_overturn=round(Mh / Mo, 2), e=round(e, 2), pmax=round(pmax, 1), pmin=round(pmin, 1),
                cond_slide=round(1.0 * Fsl, 1), cond_slide_R=round(0.9 * Rsl / 1.15, 1), R0_305=148.7)


R['gabion'] = dict(h30=gabion_check(3.0), h24=gabion_check(2.4, B=(2.5, 1.5, 1.0)))


# ---------------------------------------------------------------- крепление подошвы
def revetment():
    g = 9.81
    V = V_FLOOD
    d_isbash = V ** 2 / (2 * g * 0.86 ** 2 * 1.65)               # камень наброски, м
    # матрац Рено 0,30 м, камень 70–150 мм: допускаемая скорость (рекоменд. производителей) 4,2–4,5 м/с
    Vadm_reno = 4.2
    # глубина местного размыва у подошвы (оценка по формуле Лаптурева для откосных креплений, упрощ.)
    h0 = WL_FLOOD - data.RIVER_BED              # глубина потока у берега в паводок
    Vnr = 0.8                                   # неразмывающая скорость для суглинка/супеси, м/с
    hs = h0 * ((V / Vnr) ** 0.5 - 1) * 0.25     # м (консервативная оценка)
    L_apron = max(1.5 * hs, 2.0) * 1.25
    # ледовая нагрузка на откосное крепление (СП 38.13330.2018, оценка): q = k·R_c·h_d·tg(β) — оценочно
    Rc = 450.0                                  # кПа, сопротивление льда сжатию весной
    q_ice = 0.5 * Rc * ICE_H * math.tan(math.radians(30))
    return dict(V=V, d_isbash=round(d_isbash, 2), Vadm_reno=Vadm_reno, h0=round(h0, 2), hs=round(hs, 2),
                L_apron=round(L_apron, 1), q_ice=round(q_ice, 0), top=103.5, WL_FLOOD=WL_FLOOD, WL_ICE=WL_ICE)


R['revet'] = revetment()


# ---------------------------------------------------------------- дренаж и водоотвод
def drainage():
    # перехватывающий дренаж Д-1: приток по Дюпюи (двусторонний для 1 стороны) на 1 м
    k = 0.05            # м/сут, суглинок лёгкий пылеватый (принято; уточнить откачками)
    H = 2.0; h = 0.0; Rr = 20.0
    q1 = k * (H ** 2 - h ** 2) / (2 * Rr)
    Ld = 102.0
    Qgw = q1 * Ld                                  # м3/сут
    Qinf = 0.25 * 1e-3 * 30 * 2500 / 1.0 / 24      # инфильтрация ливня 30 мм на 2500 м2 → м3/ч (оценочно)
    # ливневой сток (метод предельных интенсивностей, СП 32.13330.2018): q20 = 80 л/(с·га), n = 0,68, P = 2 года
    q20 = 80.0; n = 0.68; mr = 150; gamma = 1.54; P = 2.0
    A = q20 * 20 ** n * (1 + math.log10(P) / math.log10(mr)) ** gamma
    tr = 10.0
    q_t = A / tr ** (1.2 * n - 0.1)                # л/(с·га) упрощённо
    F = 0.34                                       # га (плато :104 + :87, сток к склону)
    psi = 0.45
    Q = psi * q_t * F
    # пропускная способность трубы Ø200 (ПЭ, n=0,011) при i = 0,01 наполнении 0,6
    D = 0.2; nM = 0.011; i = 0.01
    A_ = 0.492 * D ** 2; Rh = 0.278 * D
    Qp = A_ * (1 / nM) * Rh ** (2 / 3) * i ** 0.5 * 1000
    D2 = 0.16
    Qd = 0.492 * D2 ** 2 * (1 / nM) * (0.278 * D2) ** (2 / 3) * 0.005 ** 0.5 * 1000
    return dict(k=k, q1=round(q1, 4), Ld=Ld, Qgw_m3d=round(Qgw, 2), Q_rain=round(Q, 1), q_t=round(q_t, 1),
                F_ha=F, psi=psi, Q_pipe200=round(Qp, 1), Q_drain160=round(Qd, 1))


R['drain'] = drainage()


# ---------------------------------------------------------------- объёмы по сечениям (метод средних площадей)
def areas(key):
    d = DESIGN[key]
    es = np.asarray(d['exist_surf']); ds = np.asarray(d['surf'])
    xs = np.linspace(max(es[0, 0], ds[0, 0]), d['edge'], 600)
    ze = np.interp(xs, es[:, 0], es[:, 1]); zd = np.interp(xs, ds[:, 0], ds[:, 1])
    dx = xs[1] - xs[0]
    cut = float(np.clip(ze - zd, 0, None).sum() * dx)
    fill = float(np.clip(zd - ze, 0, None).sum() * dx)
    gab = abs(float(np.sum(np.array(d['gabion'])[:, 0] * np.roll(np.array(d['gabion'])[:, 1], -1)
                           - np.roll(np.array(d['gabion'])[:, 0], -1) * np.array(d['gabion'])[:, 1]) / 2))
    # длины откосов (для площадей креплений)
    def slope_len(x0, x1):
        m = (xs >= x0) & (xs <= x1)
        return float(np.sum(np.hypot(np.diff(xs[m]), np.diff(zd[m]))))
    upper = slope_len(d['crest'], d['bench'][0])
    reno = slope_len(d['gabion'][1][0], d['edge']) + 3.0 + 1.5
    return dict(cut=round(cut, 1), fill=round(fill, 1), gabion=round(gab, 2), upper_slope=round(upper, 1),
                reno_width=round(reno, 1), jet_len=round(d['jet'][1] - d['jet'][0], 1),
                jet_depth=round(float(np.interp(d['jet'][0], ds[:, 0], ds[:, 1])) - d['jet'][2], 1))


ZONES = [  # участок вдоль бермы: (сечение, длина участка, м)
    ('В-В', 33.0, 'III (юг, :87/:72)'), ('А-А', 30.0, 'I (аварийный, у сеч. А-А)'),
    ('Г-Г', 12.0, 'I-сев. (у гаража, скв. С-4)'), ('Б-Б', 24.0, 'II (север, сеч. Б-Б)')]
Q = dict(zones=[])
tot = dict(cut=0, fill=0, gabion=0, upper=0, reno=0, ribs=0, cols=0, col_m=0, pipe_m=0, bench=0)
for key, L, zname in ZONES:
    a = areas(key)
    nribs = int(round(L / JET['s_r']))
    ncol = int(math.ceil(a['jet_len'] / JET['step'])) + 1
    col_m = nribs * ncol * a['jet_depth'] * 0.93    # часть колонн под габионом короче
    z = dict(key=key, zone=zname, L=L, **a, nribs=nribs, ncol=ncol, col_m=round(col_m, 0),
             pipe_m=round(nribs * math.ceil(ncol / 2) * a['jet_depth'], 0))
    Q['zones'].append(z)
    tot['cut'] += a['cut'] * L; tot['fill'] += a['fill'] * L; tot['gabion'] += a['gabion'] * L
    tot['upper'] += a['upper_slope'] * L; tot['reno'] += a['reno_width'] * L; tot['ribs'] += nribs
    tot['cols'] += nribs * ncol; tot['col_m'] += col_m; tot['pipe_m'] += z['pipe_m']; tot['bench'] += L
Q['total'] = {k: round(v, 0) for k, v in tot.items()}
Q['total']['soilcrete_m3'] = round(tot['col_m'] * math.pi * 0.5 ** 2 * 0.86, 0)
Q['total']['cement_t'] = round(Q['total']['soilcrete_m3'] * 0.40, 0)
Q['total']['pipe_t'] = round(tot['pipe_m'] * 26.2 / 1000, 1)     # труба 146×8: 26,2 кг/м
R['quant'] = Q
json.dump(R, open(os.path.join(OUT, 'results.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print(json.dumps({k: R[k] for k in ['jet', 'gabion', 'revet', 'drain']}, ensure_ascii=False, indent=1))
print(json.dumps(Q, ensure_ascii=False, indent=1))
print('готово за %.0f с' % (time.time() - t0))
