# -*- coding: utf-8 -*-
"""Проектные сечения: разгрузка (срезка), берма, грунтоцементные контрфорсы (ГЦК),
габионная стена, крепление подошвы; дренированный режим подземных вод."""
import numpy as np
from slope import Section, circle_surface
from data import SOILS, WL_LOW, RIVER_BED, WL_FLOOD
import sections as S

KST = 1.15        # [k] основное сочетание: γn·ψ/γd = 1,15·1,0/1,0
KST_SP = 1.09     # [k] особое сочетание / строительный период: 1,15·0,95/1,0
KH7 = S.KH7

# Параметры ГЦК (грунтоцементные контрфорсы, струйная цементация Jet-2):
#  колонны Ø1,0 м с шагом 0,75 м (перекрытие 0,25 м) → эффективная толщина ребра t = 0,80 м;
#  расчётное сопротивление грунтоцемента срезу τ_sc = 150 кПа (R_sc,сж ≥ 1,5 МПа, контроль кернением);
#  шаг рёбер вдоль берега s_r; приведённая добавка сцепления Δc = t·τ_sc / s_r.
JET = dict(D=1.0, step=0.75, t=0.80, tau=150.0, s_r=2.5)


def jet_dc(s_r=None, t=None, tau=None):
    s_r = s_r or JET['s_r']; t = t or JET['t']; tau = tau or JET['tau']
    return t * tau / s_r


DESIGN = {
    'А-А': dict(
        surf=[(0.00, 110.89), (6.14, 110.51), (15.77, 110.73), (24.32, 110.71), (29.41, 110.50),
              (30.20, 110.55), (38.40, 105.00), (43.00, 105.00), (45.40, 102.05), (47.00, 102.00),
              (48.90, 100.23), (50.10, WL_LOW), (52.9, RIVER_BED), (59.0, RIVER_BED), (61.0, WL_LOW), (65.0, 101.0)],
        layers=[('304', None), ('305', S.AA_305), ('406', S.AA_406), ('305', S.DEEP305)],
        gw=[(-8, 102.0), (25.0, 101.3), (35.0, 100.8), (44.0, 100.3), (50.1, WL_LOW), (65, WL_LOW)],
        gabion=[(43.0, 101.6), (45.4, 101.6), (45.4, 103.0), (44.9, 103.0), (44.9, 104.0), (44.4, 104.0),
                (44.4, 105.0), (43.0, 105.0)],
        toe=[(45.4, 102.05), (47.0, 102.0), (48.9, 100.23), (50.1, 99.8), (52.9, 99.0), (55.9, 99.0), (55.9, 98.7),
             (52.9, 98.7), (50.1, 99.4), (48.9, 99.8), (47.0, 101.4), (45.4, 101.5)],
        bench=(38.4, 43.0, 105.0), jet=(38.4, 45.4, 90.0), crest=30.2, edge=50.1,
        loads=[(10.0, 29.5, 10.0), (38.4, 43.0, 5.0)], xr=(26, 66), zr=(104, 142), exist=S.sec_AA_exist,
        exist_surf=S.AA_SURF),
    'Б-Б': dict(
        surf=[(0.00, 110.63), (3.16, 110.60), (12.98, 110.28), (32.00, 109.98), (32.60, 109.80),
              (40.00, 104.40), (45.00, 104.40), (47.30, 102.00), (49.50, 101.70), (53.16, 100.20),
              (54.4, WL_LOW), (57.2, RIVER_BED), (63.0, RIVER_BED), (65.0, WL_LOW), (69.0, 101.0)],
        layers=[('304', None), ('305', S.BB_305), ('406', S.BB_406), ('305', S.DEEP305)],
        gw=[(-5, 102.3), (33.0, 101.9), (44.0, 101.0), (50.0, 100.4), (54.4, WL_LOW), (69, WL_LOW)],
        gabion=[(45.0, 101.6), (47.3, 101.6), (47.3, 103.2), (46.8, 103.2), (46.8, 104.4), (45.0, 104.4)],
        toe=[(47.3, 102.0), (49.5, 101.7), (53.16, 100.2), (54.4, 99.8), (57.2, 99.0), (60.2, 99.0), (60.2, 98.7),
             (57.2, 98.7), (54.4, 99.4), (53.16, 99.8), (49.5, 101.2), (47.3, 101.5)],
        bench=(40.0, 45.0, 104.4), jet=(40.0, 47.3, 90.0), crest=32.6, edge=54.4,
        loads=[(5.0, 31.5, 10.0), (40.0, 45.0, 5.0)], xr=(28, 70), zr=(104, 142), exist=S.sec_BB_exist,
        exist_surf=S.BB_SURF),
}


def _vv_gg():
    import data
    vv = S._dem_profile(data.LINE_VV, 62)
    gg = S._dem_profile(data.LINE_GG, 58)
    DESIGN['В-В'] = dict(
        surf=[p for p in vv if p[0] <= 25.0] + [(32.90, 104.40), (37.50, 104.40), (39.70, 102.00), (41.0, 101.6),
                                               (46.0, 100.1), (47.2, WL_LOW), (49.6, RIVER_BED), (56.0, RIVER_BED),
                                               (58.0, WL_LOW), (62.0, 101.0)],
        layers=[('304', None), ('305', [(-5, 102.8), (40, 102.6), (62, 102.4)]), ('406', [(-5, 101.2), (62, 101.0)]),
                ('305', S.DEEP305)],
        gw=[(-5, 102.5), (24, 102.1), (36, 101.0), (44, 100.3), (47.2, WL_LOW), (62, WL_LOW)],
        gabion=[(37.5, 101.5), (39.7, 101.5), (39.7, 103.2), (39.2, 103.2), (39.2, 104.4), (37.5, 104.4)],
        toe=[(39.7, 102.0), (41.0, 101.6), (46.0, 100.1), (47.2, 99.8), (49.6, 99.0), (52.6, 99.0), (52.6, 98.7),
             (49.6, 98.7), (47.2, 99.4), (46.0, 99.7), (41.0, 101.1), (39.7, 101.5)],
        bench=(32.9, 37.5, 104.4), jet=(32.9, 39.7, 90.0), crest=25.0, edge=47.2,
        loads=[(0.0, 24.5, 10.0), (32.9, 37.5, 5.0)], xr=(20, 60), zr=(104, 142), exist=S.sec_VV_exist,
        exist_surf=vv)
    DESIGN['Г-Г'] = dict(
        surf=[p for p in gg if p[0] <= 21.0] + [(21.5, 110.47), (29.70, 105.00), (34.30, 105.00), (36.70, 102.00),
                                               (38.50, 102.00), (41.20, 100.20), (41.8, WL_LOW), (44.2, RIVER_BED),
                                               (49.0, RIVER_BED), (51.0, WL_LOW), (56.0, 100.95)],
        layers=[('304', None), ('305', [(-5, 102.5), (25, 102.5), (35, 102.8), (58, 102.8)]),
                ('406', [(-5, 100.5), (58, 100.4)]), ('305', S.DEEP305)],
        gw=[(-5, 102.3), (24, 101.9), (34, 100.9), (40, 100.2), (41.8, WL_LOW), (58, WL_LOW)],
        gabion=[(34.3, 101.6), (36.7, 101.6), (36.7, 103.0), (36.2, 103.0), (36.2, 104.0), (35.7, 104.0),
                (35.7, 105.0), (34.3, 105.0)],
        toe=[(36.7, 102.0), (38.5, 102.0), (41.2, 100.2), (41.8, 99.8), (44.2, 99.0), (47.2, 99.0), (47.2, 98.7),
             (44.2, 98.7), (41.8, 99.4), (41.2, 99.8), (38.5, 101.5), (36.7, 101.5)],
        bench=(29.7, 34.3, 105.0), jet=(29.7, 36.7, 90.0), crest=21.5, edge=41.8,
        loads=[(0.0, 20.0, 10.0), (29.7, 34.3, 5.0)], xr=(18, 56), zr=(104, 142), exist=S.sec_GG_exist,
        exist_surf=gg)


_vv_gg()


def sec_design(key, param='design', kh=0.0, jet=True, dc=None, gw=None, wl=WL_LOW, extra_loads=(), name=None,
               jet_bottom=None, toe=True):
    d = DESIGN[key]
    regions = [('stone', d['gabion'])] + ([('stone', d['toe'])] if toe else [])
    reinf = []
    if jet:
        x1, x2, zb = d['jet']
        zb = jet_bottom if jet_bottom is not None else zb
        reinf = [([(x1, 112.0), (x2, 112.0), (x2, zb), (x1, zb)], jet_dc() if dc is None else dc, 0.0)]
    return Section(name or f'{key} проект', d['surf'], d['layers'], SOILS, water=gw or d['gw'], wl_ext=wl,
                   loads=list(d['loads']) + list(extra_loads), kh=kh, regions=regions, param=param, reinf=reinf)


def rapid_drawdown_gw(key):
    """быстрое снижение уровня после паводка: в береговой зоне вода на отм. РУВВ, внутри — дренированный УГВ"""
    d = DESIGN[key]
    e = d['edge']
    gw = [p for p in d['gw'] if p[0] < e - 14] + [(e - 10, 102.0), (e - 3, WL_FLOOD - 0.3), (e, WL_FLOOD - 0.5),
                                                   (e + 3, WL_LOW), (e + 20, WL_LOW)]
    return gw


def required_H(sec, xp, xc_rng, zc_rng, kst=KST, nx=16, nz=14, nr=16):
    """Максимальная требуемая удерживающая сила (кН/м) по окружностям, пересекающим x = xp."""
    best = dict(H=-1e9)
    xg = np.linspace(*xc_rng, nx); zg = np.linspace(*zc_rng, nz)
    zmax = sec.surface[:, 1].max()
    for refine in range(3):
        for xc in xg:
            for zc in zg:
                for R in np.linspace(max(zc - zmax + 1.0, 2.0), zc - (sec.surface[:, 1].min() - 12), nr):
                    xs, zs = circle_surface(sec, xc, zc, R)
                    if xs is None or not (xs[0] < xp < xs[-1]):
                        continue
                    zp = np.interp(xp, xs, zs)
                    Sl = sec.slices(xs, zs, 50)
                    if (Sl['zt'] - Sl['zb']).max() < 0.8:
                        continue
                    W = Sl['W'] + Sl['Q']; sa = np.sin(Sl['alpha']); ca = np.cos(Sl['alpha'])
                    tphi = np.tan(Sl['phi'])
                    num0 = Sl['c'] * Sl['b'] + np.maximum(W - Sl['u'] * Sl['b'], 0) * tphi
                    ma = np.maximum(ca + sa * tphi / kst, 0.2)
                    res = (num0 / ma).sum() * R
                    drive = ((W * sa).sum() + (sec.kh * Sl['W'] * (zc - Sl['zcg']) / R).sum()) * R
                    H = (kst * drive - res) / (zc - zp)
                    if H > best['H']:
                        best = dict(H=H, xc=xc, zc=zc, R=R, xs=xs, zs=zs, zp=zp, x_in=xs[0], x_out=xs[-1])
        if 'xc' not in best:
            return best
        dx = xg[1] - xg[0]; dz = zg[1] - zg[0]
        xg = np.linspace(best['xc'] - dx, best['xc'] + dx, 9); zg = np.linspace(best['zc'] - dz, best['zc'] + dz, 9)
    return best
