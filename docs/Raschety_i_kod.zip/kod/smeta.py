# -*- coding: utf-8 -*-
"""Ведомость объёмов и укрупнённый сметный расчёт (XLSX)."""
import json, os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side

HERE = os.path.dirname(os.path.abspath(__file__))
R = json.load(open(os.path.join(HERE, 'results', 'results.json'), encoding='utf-8'))
Z = {z['key']: z for z in R['quant']['zones']}
ZONES = {'I': ['А-А', 'Г-Г'], 'II': ['Б-Б'], 'III': ['В-В']}


def zsum(field, keys):
    return sum(Z[k][field] * Z[k]['L'] for k in keys)


q = {}
for zn, keys in ZONES.items():
    q[zn] = dict(L=sum(Z[k]['L'] for k in keys), cut=zsum('cut', keys), fill=zsum('fill', keys), gab=zsum('gabion', keys),
                 upper=zsum('upper_slope', keys), reno=zsum('reno_width', keys), ribs=sum(Z[k]['nribs'] for k in keys),
                 colm=sum(Z[k]['col_m'] for k in keys), pipe=sum(Z[k]['pipe_m'] for k in keys))
DRL = {'I': 42.0, 'II': 34.0, 'III': 26.0}
ONE_I = lambda z: 1.0 if z == 'I' else 0.0

import cost_rows
RF = cost_rows.rows(q, DRL)
ROWS = [r[:7] for r in RF]
CONT = cost_rows.CONT

thin = Side(style='thin', color='888888')
BRD = Border(left=thin, right=thin, top=thin, bottom=thin)
HB = Font(bold=True)
HF = PatternFill('solid', fgColor='DCE6E9')
wb = Workbook()

ws = wb.active
ws.title = 'Ведомость объёмов'
ws.append(['Ведомость объёмов работ. Шифр 2026-МОС40-ИЗ. Объёмы по расчётной модели; уточняются в РД.'])
ws.append([])
ws.append(['№', 'Раздел', 'Наименование работ', 'Ед.', 'Зона I (42 м)', 'Зона II (24 м)', 'Зона III (33 м)', 'Всего'])
for c in range(1, 9):
    ws.cell(3, c).font = HB; ws.cell(3, c).fill = HF; ws.cell(3, c).border = BRD
for i, (sec, nm, u, f, a, b, note) in enumerate(ROWS, 1):
    r = 3 + i
    ws.append([i, sec, nm, u, round(f('I'), 2), round(f('II'), 2), round(f('III'), 2), '=SUM(E%d:G%d)' % (r, r)])
    for c in range(1, 9):
        ws.cell(r, c).border = BRD
        if c >= 5:
            ws.cell(r, c).number_format = '#,##0.00'
for col, w in zip('ABCDEFGH', [5, 20, 70, 8, 14, 14, 14, 14]):
    ws.column_dimensions[col].width = w
ws.freeze_panes = 'A4'

ws2 = wb.create_sheet('Смета укрупнённая')
ws2.append(['Укрупнённый расчёт стоимости (ориентировочно), руб., цены IV кв. 2026 г., без НДС. Точность ±30 %.'])
ws2.append(['Расценки — по открытым рыночным данным 2025–2026 гг. и расчёту по материалоёмкости (см. «Обоснование стоимости»); перед договорами — КП подрядчиков.'])
ws2.append(['№', 'Раздел', 'Наименование', 'Ед.', 'Кол-во всего', 'Цена мин', 'Цена макс', 'Сумма мин', 'Сумма макс',
            'Зона I мин', 'Зона I макс', 'Примечание'])
for c in range(1, 13):
    ws2.cell(3, c).font = HB; ws2.cell(3, c).fill = HF; ws2.cell(3, c).border = BRD
first = 4
for i, (sec, nm, u, f, a, b, note) in enumerate(ROWS, 1):
    r = 3 + i
    ws2.append([i, sec, nm, u, "='Ведомость объёмов'!H%d" % r, a, b, '=E%d*F%d' % (r, r), '=E%d*G%d' % (r, r),
                "='Ведомость объёмов'!E%d*F%d" % (r, r), "='Ведомость объёмов'!E%d*G%d" % (r, r), note])
    for c in range(1, 13):
        ws2.cell(r, c).border = BRD
        if 5 <= c <= 11:
            ws2.cell(r, c).number_format = '#,##0'
last = 3 + len(ROWS)
r1, r2, r3 = last + 1, last + 2, last + 3
ws2.cell(r1, 3, 'Итого').font = HB
ws2.cell(r2, 3, 'Непредвиденные работы и затраты, %d %%' % round(CONT * 100))
ws2.cell(r3, 3, 'ВСЕГО без НДС').font = Font(bold=True, size=12)
for c, col in ((8, 'H'), (9, 'I'), (10, 'J'), (11, 'K')):
    ws2.cell(r1, c, '=SUM(%s%d:%s%d)' % (col, first, col, last)).number_format = '#,##0'
    ws2.cell(r2, c, '=%s%d*%s' % (col, r1, CONT)).number_format = '#,##0'
    ws2.cell(r3, c, '=%s%d+%s%d' % (col, r1, col, r2)).number_format = '#,##0'
    ws2.cell(r3, c).font = Font(bold=True, size=12)
ws2.cell(r3 + 1, 3, 'НДС — по ставке, действующей на дату договора')
for col, w in zip('ABCDEFGHIJKL', [5, 18, 62, 7, 12, 11, 11, 14, 14, 14, 14, 24]):
    ws2.column_dimensions[col].width = w
ws2.freeze_panes = 'A4'

tot_min = sum((f('I') + f('II') + f('III')) * a for _, _, _, f, a, b, _ in ROWS) * (1 + CONT)
tot_max = sum((f('I') + f('II') + f('III')) * b for _, _, _, f, a, b, _ in ROWS) * (1 + CONT)
z1_min = sum(f('I') * a for _, _, _, f, a, b, _ in ROWS) * (1 + CONT)
z1_max = sum(f('I') * b for _, _, _, f, a, b, _ in ROWS) * (1 + CONT)
jet_min = [(f('I') + f('II') + f('III')) * a for _, nm, _, f, a, b, _ in ROWS if 'Jet-2' in nm][0] * (1 + CONT)

ws3 = wb.create_sheet('Очерёдность')
for row in [['Рекомендуемая очерёдность финансирования (млн руб. без НДС, с непредвиденными %d %%, ориентировочно)' % round(CONT * 100)], [],
            ['Этап', 'Состав', 'Мин', 'Макс'],
            ['Этап 0 + 1 (зона I, ≈ 42 м)', 'Противоаварийные меры, доизыскания, РД, разрешения; демонтаж, дренаж, ГЦК зоны I, балка, габионы, Рено, откосы, лестница, мониторинг',
             round(z1_min / 1e6, 1), round(z1_max / 1e6, 1)],
            ['Этап 2 (зоны II–III, ≈ 57 м)', 'После доизысканий и 1 года мониторинга; возможна оптимизация ГЦК на 30–50 %',
             round((tot_min - z1_min) / 1e6, 1), round((tot_max - z1_max) / 1e6, 1)],
            ['Всего', '', round(tot_min / 1e6, 1), round(tot_max / 1e6, 1)]]:
    ws3.append(row)
ws3.column_dimensions['A'].width = 28; ws3.column_dimensions['B'].width = 110
ws4 = wb.create_sheet('Варианты')
ws4.append(['Варианты по бюджету (ориентировочно, млн руб. без НДС, с непредвиденными)']); ws4.append([])
ws4.append(['Вариант', 'Состав', 'Мин', 'Макс', 'Запас устойчивости', 'Что остаётся'])
SC = {}
for sc in cost_rows.SCEN:
    lo, hi = cost_rows.scen_cost(RF, sc); SC[sc['id']] = [lo, hi]
    ws4.append([sc['id'] + '. ' + sc['name'], sc['what'], round(lo / 1e6, 1), round(hi / 1e6, 1), sc['k'], sc['rest']])
for col, w in zip('ABCDEF', [36, 80, 8, 8, 40, 50]): ws4.column_dimensions[col].width = w
for w_ in (ws, ws2, ws3, ws4):
    w_['A1'].font = Font(bold=True, size=12)
wb.save(os.path.join(HERE, 'results', 'Smeta_ukrupn_2026-MOS40.xlsx'))
json.dump(dict(tot=[tot_min, tot_max], z1=[z1_min, z1_max], jet_share=jet_min / tot_min, cont=CONT, scen=SC,
               old=dict(tot=list(cost_rows.scen_cost(RF, cost_rows.SCEN[-1], 'old')), z1=list(cost_rows.scen_cost(RF, cost_rows.SCEN[-2], 'old')))),
          open(os.path.join(HERE, 'results', 'cost.json'), 'w'))
print('всего, млн руб. без НДС:', round(tot_min / 1e6, 1), '…', round(tot_max / 1e6, 1))
print('этап 0+1 (зона I):', round(z1_min / 1e6, 1), '…', round(z1_max / 1e6, 1))
print('доля Jet:', round(jet_min / tot_min * 100))
