# -*- coding: utf-8 -*-
"""Расчётные сечения: существующее положение и проект."""
import numpy as np
from data import (PROFILE_AA, PROFILE_BB, SOILS, WL_LOW, WL_FLOOD, RIVER_BED, line_xy, LINE_AA, LINE_BB)
from slope import Section

KH7 = 0.05   # сейсмика 7 баллов (карта А 6 баллов + 1 балл за III кат. грунтов), k_h = 0,5·A, A = 0,1g

# ---------------------------------------------------------------- А-А
AA_RIVER = [(50.1, WL_LOW), (52.9, RIVER_BED), (59.0, RIVER_BED), (61.0, WL_LOW), (65.0, 101.0)]
AA_SURF = PROFILE_AA + AA_RIVER
AA_305 = [(-8, 102.1), (29.2, 101.6), (38.0, 101.9), (43.0, 102.5), (47.0, 102.6), (65, 102.6)]
AA_406 = [(-8, 95.0), (20.0, 98.6), (29.2, 99.6), (65, 99.6)]
# ниже забоя скважин (≈94,5) принят ИГЭ-305 (по разрезу скв. С-1: под ИГЭ-406 вновь суглинок 305)
DEEP305 = [(-50, 94.5), (120, 94.5)]
AA_GW = [(-8, 102.1), (29.2, 101.6), (38.0, 101.2), (44.0, 100.5), (50.1, WL_LOW), (65, WL_LOW)]
# весенняя верховодка за стенами (барражный эффект): ~3 м ниже плато, выход на откос у стены W2
AA_PERCHED = [(-8, 105.5), (20.0, 106.5), (31.9, 107.6), (37.0, 107.2), (38.3, 104.4), (43.0, 102.0), (65, 99.0)]
# пригрузка от застройки/эксплуатации на плато (СП 116: не менее 10 кПа), до ПК 31
AA_LOADS = [(10.0, 30.0, 10.0)]


def sec_AA_exist(param='design', gw=AA_GW, perched=None, kh=0.0, wl=WL_LOW, loads=AA_LOADS, name='А-А сущ.'):
    return Section(name, AA_SURF, [('304', None), ('305', AA_305), ('406', AA_406), ('305', DEEP305)], SOILS,
                   water=gw, wl_ext=wl, loads=loads, kh=kh, perched=perched, param=param)


# ---------------------------------------------------------------- Б-Б
BB_RIVER = [(54.4, WL_LOW), (57.2, RIVER_BED), (63.0, RIVER_BED), (65.0, WL_LOW), (69.0, 101.0)]
BB_SURF = PROFILE_BB + BB_RIVER
BB_305 = [(-5, 102.5), (35.0, 102.4), (45.0, 102.3), (50.0, 102.0), (69, 102.0)]
BB_406 = [(-5, 100.5), (69, 100.4)]
BB_GW = [(-5, 102.5), (33.0, 102.4), (44.0, 101.3), (50.0, 100.6), (54.4, WL_LOW), (69, WL_LOW)]
BB_LOADS = [(5.0, 32.0, 10.0)]


def sec_BB_exist(param='design', kh=0.0, top301=False, gw=BB_GW, name='Б-Б сущ.'):
    layers = [('304', None), ('305', BB_305), ('406', BB_406), ('305', DEEP305)]
    if top301:
        layers = [('301', None), ('304', [(-5, 107.6), (30, 107.0), (40, 104.0), (69, 99.0)]), ('305', BB_305), ('406', BB_406), ('305', DEEP305)]
    return Section(name, BB_SURF, layers, SOILS, water=gw, wl_ext=WL_LOW, loads=BB_LOADS, kh=kh, param=param)


# ---------------------------------------------------------------- В-В и Г-Г (по ЦМР)
def _dem_profile(line, L):
    import dem
    d = np.load(dem.os.path.join(dem.HERE, 'dem_exist.npz'))
    pk, z = dem.profile(d['Z'], line, L, step=1.0)
    return [(float(p), round(float(v), 2)) for p, v in zip(pk, z)]


def sec_VV_exist(param='design', kh=0.0, name='В-В сущ.'):
    from data import LINE_VV
    surf = _dem_profile(LINE_VV, 62)
    L305 = [(-5, 102.8), (40, 102.6), (62, 102.4)]
    L406 = [(-5, 101.2), (62, 101.0)]
    gw = [(-5, 102.8), (24, 102.6), (36, 101.4), (44, 100.4), (47, WL_LOW), (62, WL_LOW)]
    return Section(name, surf, [('304', None), ('305', L305), ('406', L406), ('305', DEEP305)], SOILS, water=gw, wl_ext=WL_LOW,
                   loads=[(0, 22, 10.0)], kh=kh, param=param)


def sec_GG_exist(param='design', kh=0.0, name='Г-Г сущ.'):
    from data import LINE_GG
    surf = _dem_profile(LINE_GG, 58)
    L305 = [(-5, 102.5), (25, 102.5), (35, 102.8), (58, 102.8)]
    L406 = [(-5, 100.5), (58, 100.4)]
    gw = [(-5, 102.5), (24, 102.4), (34, 101.3), (40, 100.4), (42, WL_LOW), (58, WL_LOW)]
    return Section(name, surf, [('304', None), ('305', L305), ('406', L406), ('305', DEEP305)], SOILS, water=gw, wl_ext=WL_LOW,
                   loads=[(0, 20, 10.0)], kh=kh, param=param)
